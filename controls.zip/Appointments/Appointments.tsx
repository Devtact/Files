import * as React from 'react';
import {Stack,Separator,Icon,Link,DefaultButton} from '@fluentui/react';

export const AppointmentsComponent: React.FunctionComponent = () => {
    return (
        <div className='container-fluid-Custom'>
            <Stack>

            <div id="AppointmentsCarousel" className="carousel slide" data-ride="carousel">

                    <ul className="carousel-indicators">
                    <li data-target="#AppointmentsCarousel" data-slide-to="0" className="active"></li>
                    <li data-target="#AppointmentsCarousel" data-slide-to="1"></li>
                    <li data-target="#AppointmentsCarousel" data-slide-to="2"></li>
                    </ul>

                    <div className="carousel-inner">
                    <div className="carousel-item active">
                        
                    <Stack className='AppointmentsBox'>
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                        <h2>Account renewal discussion</h2>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <DefaultButton className='floatRight editIcon'></DefaultButton>
                    </Stack.Item>
                </Stack>
                
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                       <div>
                             <Icon iconName="Calendar" className='CalendarIcon floatLeft marginRight5px'/> 
                             <input className='startTime marginRight5px' type="time" id="startTime" name="startTime"></input>
                             <input className='EndTime' type="time" id="EndTime" name="EndTime"></input>
                        </div>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <Link className='JoinNowLink'>Join Now</Link>
                    </Stack.Item>
                </Stack>

                <Stack className='AppointmentsDetailsBox'>
                    <Stack horizontal horizontalAlign='space-between'>
                        <Stack.Item align='start'>
                            <div>
                            <Link className='LinkText'>Blue Star Infra Pvt.Limited</Link>
                            </div>
                        </Stack.Item>
                        <Stack.Item>
                            <img className='image-responsive' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAaCAYAAABozQZiAAAABHNCSVQICAgIfAhkiAAAAtlJREFUOE+VVFtIFGEUPuefbXRm1qBiZiyKqESi512VHqInpV6NCCkIKxBBCEQoMurFAvEhshCECCHwoeix24uQUey4RNCFIHyoSN21tHJnvOzufzozurbuxew87b/n+75zH4QCew+guqb+Qsh0R+RHOlboz39jofOtAfa8YbwBASpIuliX9AbLCRSRfaBjh8cBYS8RfVMo0xpJLj4rJVCSHLOMLhTY6xOQIBVNpKo2THZs/Rwg3mKqCkQuEvVFk97VQoGSkccsrZmEMsBg0ydw+tn6hBvyf8cBdGkZTyoysgVfh8HMqKpVN7PEjV42x6w8BEIZ5ug7lskwJ0Cezya8B2jr7xSiXSx4DcdMbZSEqEGQQ9HE/AUfHLP0NiHwBgFW5AQJYBSBPC6lKehFVp7BmK21IIib/K6UAD0NCfd6rNroRcCutTXSAgt85/93EtBXyFB7ULNjGxOc4nZOL8XqPTymU6x9YA2ZaJExQSbcwAkgeXyZbBmPQOCRleb8FIAhQgiXGs8KJqnKpaYVsn4bhGgPwEQep4dsWjkyY6YpS0cD8phtPCXExrLgQgfRJMhMa65m6cfaKDkAStmGr2ytXqB4zF3cslEycF2A8iFyszr5gnr4tTrTf4tILhtHMG7pd6WA08AK/2O8YXPoVIdHmHR4nc563A+92E/T6JjGMPfqBJUKTPCbl+EDj7GhuOG8vFzzSc74TnB+RQj4BNl0Jyihexx9c747SPslwNaQbXxkZ3B++YaU7QdQBiXCcx7P32lIjkryfjCymKl1oCL61kQn+iLJratagHRKM+Jc2p6cMEedAc+tXV0Mx9S7QcHLOQEGfPYSbo1hh5sJaSC3B0yYRTdVG5nzLyzP+PPTzRHOclK7+exmUdIlFtvHR9PJg53ka5sSrtvoE31a0UrGt6n7ZWjTFY4cRcJjm8kd/yX0IUWI/shUyh/rqpXdZ26kdhBgfr3F+QPvjSMwmEg+1QAAAABJRU5ErkJggg=='></img>
                        </Stack.Item>
                    </Stack>

                    <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Product</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Credit Card</div>  
                                </Stack.Item>
                    </Stack>

                     <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Lead Status</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Documents to be Picked up</div>  
                                </Stack.Item>
                    </Stack>    


                </Stack>

            </Stack>


                    </div>
                    <div className="carousel-item">
                       <Stack className='AppointmentsBox'>
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                        <h2>Account renewal discussion</h2>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <DefaultButton className='floatRight editIcon'></DefaultButton>
                    </Stack.Item>
                </Stack>
                
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                       <div>
                             <Icon iconName="Calendar" className='CalendarIcon floatLeft marginRight5px'/> 
                             <input className='startTime marginRight5px' type="time" id="startTime" name="startTime"></input>
                             <input className='EndTime' type="time" id="EndTime" name="EndTime"></input>
                        </div>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <Link className='JoinNowLink'>Join Now</Link>
                    </Stack.Item>
                </Stack>

                <Stack className='AppointmentsDetailsBox'>
                    <Stack horizontal horizontalAlign='space-between'>
                        <Stack.Item align='start'>
                            <div>
                            <Link className='LinkText'>Blue Star Infra Pvt.Limited</Link>
                            </div>
                        </Stack.Item>
                        <Stack.Item>
                            <img className='image-responsive' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAaCAYAAABozQZiAAAABHNCSVQICAgIfAhkiAAAAtlJREFUOE+VVFtIFGEUPuefbXRm1qBiZiyKqESi512VHqInpV6NCCkIKxBBCEQoMurFAvEhshCECCHwoeix24uQUey4RNCFIHyoSN21tHJnvOzufzozurbuxew87b/n+75zH4QCew+guqb+Qsh0R+RHOlboz39jofOtAfa8YbwBASpIuliX9AbLCRSRfaBjh8cBYS8RfVMo0xpJLj4rJVCSHLOMLhTY6xOQIBVNpKo2THZs/Rwg3mKqCkQuEvVFk97VQoGSkccsrZmEMsBg0ydw+tn6hBvyf8cBdGkZTyoysgVfh8HMqKpVN7PEjV42x6w8BEIZ5ug7lskwJ0Cezya8B2jr7xSiXSx4DcdMbZSEqEGQQ9HE/AUfHLP0NiHwBgFW5AQJYBSBPC6lKehFVp7BmK21IIib/K6UAD0NCfd6rNroRcCutTXSAgt85/93EtBXyFB7ULNjGxOc4nZOL8XqPTymU6x9YA2ZaJExQSbcwAkgeXyZbBmPQOCRleb8FIAhQgiXGs8KJqnKpaYVsn4bhGgPwEQep4dsWjkyY6YpS0cD8phtPCXExrLgQgfRJMhMa65m6cfaKDkAStmGr2ytXqB4zF3cslEycF2A8iFyszr5gnr4tTrTf4tILhtHMG7pd6WA08AK/2O8YXPoVIdHmHR4nc563A+92E/T6JjGMPfqBJUKTPCbl+EDj7GhuOG8vFzzSc74TnB+RQj4BNl0Jyihexx9c747SPslwNaQbXxkZ3B++YaU7QdQBiXCcx7P32lIjkryfjCymKl1oCL61kQn+iLJratagHRKM+Jc2p6cMEedAc+tXV0Mx9S7QcHLOQEGfPYSbo1hh5sJaSC3B0yYRTdVG5nzLyzP+PPTzRHOclK7+exmUdIlFtvHR9PJg53ka5sSrtvoE31a0UrGt6n7ZWjTFY4cRcJjm8kd/yX0IUWI/shUyh/rqpXdZ26kdhBgfr3F+QPvjSMwmEg+1QAAAABJRU5ErkJggg=='></img>
                        </Stack.Item>
                    </Stack>

                    <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Product</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Credit Card</div>  
                                </Stack.Item>
                    </Stack>

                     <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Lead Status</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Documents to be Picked up</div>  
                                </Stack.Item>
                    </Stack>    


                </Stack>

            </Stack>
                    </div>
                    <div className="carousel-item">
                    <Stack className='AppointmentsBox'>
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                        <h2>Account renewal discussion</h2>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <DefaultButton className='floatRight editIcon'></DefaultButton>
                    </Stack.Item>
                </Stack>
                
                <Stack horizontal horizontalAlign='space-between'>
                    <Stack.Item align='start'>
                       <div>
                             <Icon iconName="Calendar" className='CalendarIcon floatLeft marginRight5px'/> 
                             <input className='startTime marginRight5px' type="time" id="startTime" name="startTime"></input>
                             <input className='EndTime' type="time" id="EndTime" name="EndTime"></input>
                        </div>
                    </Stack.Item>
                    <Stack.Item align='end'>
                        <Link className='JoinNowLink'>Join Now</Link>
                    </Stack.Item>
                </Stack>

                <Stack className='AppointmentsDetailsBox'>
                    <Stack horizontal horizontalAlign='space-between'>
                        <Stack.Item align='start'>
                            <div>
                            <Link className='LinkText'>Blue Star Infra Pvt.Limited</Link>
                            </div>
                        </Stack.Item>
                        <Stack.Item>
                            <img className='image-responsive' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAaCAYAAABozQZiAAAABHNCSVQICAgIfAhkiAAAAtlJREFUOE+VVFtIFGEUPuefbXRm1qBiZiyKqESi512VHqInpV6NCCkIKxBBCEQoMurFAvEhshCECCHwoeix24uQUey4RNCFIHyoSN21tHJnvOzufzozurbuxew87b/n+75zH4QCew+guqb+Qsh0R+RHOlboz39jofOtAfa8YbwBASpIuliX9AbLCRSRfaBjh8cBYS8RfVMo0xpJLj4rJVCSHLOMLhTY6xOQIBVNpKo2THZs/Rwg3mKqCkQuEvVFk97VQoGSkccsrZmEMsBg0ydw+tn6hBvyf8cBdGkZTyoysgVfh8HMqKpVN7PEjV42x6w8BEIZ5ug7lskwJ0Cezya8B2jr7xSiXSx4DcdMbZSEqEGQQ9HE/AUfHLP0NiHwBgFW5AQJYBSBPC6lKehFVp7BmK21IIib/K6UAD0NCfd6rNroRcCutTXSAgt85/93EtBXyFB7ULNjGxOc4nZOL8XqPTymU6x9YA2ZaJExQSbcwAkgeXyZbBmPQOCRleb8FIAhQgiXGs8KJqnKpaYVsn4bhGgPwEQep4dsWjkyY6YpS0cD8phtPCXExrLgQgfRJMhMa65m6cfaKDkAStmGr2ytXqB4zF3cslEycF2A8iFyszr5gnr4tTrTf4tILhtHMG7pd6WA08AK/2O8YXPoVIdHmHR4nc563A+92E/T6JjGMPfqBJUKTPCbl+EDj7GhuOG8vFzzSc74TnB+RQj4BNl0Jyihexx9c747SPslwNaQbXxkZ3B++YaU7QdQBiXCcx7P32lIjkryfjCymKl1oCL61kQn+iLJratagHRKM+Jc2p6cMEedAc+tXV0Mx9S7QcHLOQEGfPYSbo1hh5sJaSC3B0yYRTdVG5nzLyzP+PPTzRHOclK7+exmUdIlFtvHR9PJg53ka5sSrtvoE31a0UrGt6n7ZWjTFY4cRcJjm8kd/yX0IUWI/shUyh/rqpXdZ26kdhBgfr3F+QPvjSMwmEg+1QAAAABJRU5ErkJggg=='></img>
                        </Stack.Item>
                    </Stack>

                    <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Product</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Credit Card</div>  
                                </Stack.Item>
                    </Stack>

                     <Stack horizontal className='marginTop5px'>
                                <Stack.Item>
                                <div className='labelText'>Lead Status</div> 
                                </Stack.Item>
                                <Stack.Item>
                                <div className='contentText'>Documents to be Picked up</div>  
                                </Stack.Item>
                    </Stack>    


                </Stack>

            </Stack>
                    </div>
                    </div>

            </div>

            <Stack horizontal horizontalAlign='space-between'>
                <Stack.Item>
                    <Link className='addMorebtn'><Icon iconName="Add" className='AddMoreIcon floatLeft marginRight5px'/> Add More</Link>
                </Stack.Item>
                <Stack.Item>
                    <Link className='viewallLink'>View all</Link>
                </Stack.Item>
            </Stack>
           

            
            </Stack>

            
        </div>
    );
};