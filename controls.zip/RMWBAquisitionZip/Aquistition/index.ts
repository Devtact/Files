import { IInputs, IOutputs } from "./generated/ManifestTypes";
import ReactDOM = require("react-dom");
import React = require("react");
import { CardControlComponent, cardParams } from "./htmlControl";
//import { stringify } from "node:querystring";
import * as moment from "moment";

export class AquistitionTest
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  /**
   * Empty constructor.
   */
  constructor() {}
  private PANno: string;
  private Mcap: string;
  private Shareprice: string;
  private Incoporationdate: string;
  private Promoteholding: string;
  private _container: HTMLDivElement;
  private _props: cardParams;
  private _context: ComponentFramework.Context<IInputs>;
  private _entityId: string;
  private OnboardingCount: number;
  private ObofCount: number;
  private LeadsCount: number;
  private DealsCount: number;
  private CRMurl: string;
  private _AllContacts: {
    FullName: string;
    Designation: string;
    imgurl: string;
    contactInitials: string;
    url: string;
    initia: boolean;
  }[];

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    // Add control initialization code
    this._container = container;
    this._context = context;
    this.CRMurl = this._context.parameters.CRMurl.raw! || "";

    var guidfetch = this._context.parameters.OrganizationGuid.raw!;

    if (guidfetch) {
      this._entityId = this._context.parameters.OrganizationGuid.raw!.replace(
        "{",
        ""
      ).replace("}", "");
    }

    this.fetchData(this);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    // Add code to update control view

    var guidfetch = this._context.parameters.OrganizationGuid.raw!;

    if (guidfetch) {
      this._entityId = this._context.parameters.OrganizationGuid.raw!.replace(
        "{",
        ""
      ).replace("}", "");
    }

    this.fetchData(this);
  }

  public getOutputs(): IOutputs {
    return {};
  }

  public destroy(): void {
    // Add code to cleanup control if necessary
  }

  //function for field mapping from table and display
  public fetchData(self: AquistitionTest) {
    //let _AllContacts : { FullName: string, Designation: string, imgurl:string, url: string}[]=[];
    self.ObofCount = 0;
    self.OnboardingCount = 0;
    self.LeadsCount = 0;
    self.DealsCount = 0;

    var _queryarray = [];

    if (self._entityId) {
      _queryarray.push(
        self._context.webAPI.retrieveRecord(
          "account",
          self._entityId,
          "?$select=icici_dateofincorporation,icici_mcap,icici_pannumber,icici_promoterholding,icici_shareprice"
        )
      );

      _queryarray.push(
        self._context.webAPI.retrieveMultipleRecords(
          "contact",
          "?$select=contactid,firstname,lastname,accountrolecode,entityimageid,fullname,statecode,_icici_designation_value&$filter=_accountid_value eq " +
            self._entityId
        )
      );

      _queryarray.push(
        self._context.webAPI.retrieveMultipleRecords(
          "opportunity",
          "?$select=_accountid_value,emailaddress,name&$filter=_accountid_value eq " +
            self._entityId
        )
      );

      _queryarray.push(
        self._context.webAPI.retrieveMultipleRecords(
          "icici_configuration",
          "?$select=icici_name,icici_value&$filter=icici_name eq 'RMWB_Organization_CorpOrgForm_CompanyInfo' or icici_name eq 'RMWB_Organization_CorpOrgForm_Contactstab' or  icici_name eq 'RMWB_Organization_CorpOrgForm_OnboardingsTab'"
        )
      );

      Promise.all(_queryarray)
        .then(
          (results) => {
            if (results[0]) {
              let currentResult = results[0];
              self.PANno = currentResult["icici_pannumber"];
              self.Shareprice =
                currentResult[
                  "icici_shareprice@OData.Community.Display.V1.FormattedValue"
                ];
              self.Mcap =
                currentResult[
                  "icici_mcap@OData.Community.Display.V1.FormattedValue"
                ];
              self.Promoteholding =
                currentResult[
                  "icici_promoterholding@OData.Community.Display.V1.FormattedValue"
                ];
              var incorporationdateVal =
                currentResult["icici_dateofincorporation"];
              self.Incoporationdate =
                moment(incorporationdateVal).format("DD/MM/YYYY");
            }

            self._AllContacts = [];
            var Crmurldata = Xrm.Page.context.getClientUrl().toString();

            if (results[1].entities.length > 0) {
              for (var i = 0; i < results[1].entities.length; i++) {
                var nameInitials = "";
                var contactid = results[1].entities[i]["contactid"];

                var fullname = results[1].entities[i]["fullname"];
                var _icici_designation_value =
                  results[1].entities[i]["_icici_designation_value"];
                var _icici_designation_value_formatted =
                  results[1].entities[i][
                    "_icici_designation_value@OData.Community.Display.V1.FormattedValue"
                  ];
                var _icici_designation_value_lookuplogicalname =
                  results[1].entities[i][
                    "_icici_designation_value@Microsoft.Dynamics.CRM.lookuplogicalname"
                  ];
                var statecode = results[1].entities[i]["statecode"];
                var statecode_formatted =
                  results[1].entities[i][
                    "statecode@OData.Community.Display.V1.FormattedValue"
                  ];
                var lastname = results[1].entities[i]["lastname"];
                var firstname = results[1].entities[i]["firstname"];
                var entityimageid = results[1].entities[i]["entityimageid"];
                var accountrolecode = results[1].entities[i]["accountrolecode"];
                var accountrolecode_formatted =
                  results[1].entities[i][
                    "accountrolecode@OData.Community.Display.V1.FormattedValue"
                  ];

                //pushing data to contacts array
                if (entityimageid != null) {
                  if (self._AllContacts.length < 5) {
                    self._AllContacts.push({
                      FullName: fullname,
                      Designation: accountrolecode_formatted,
                      imgurl: entityimageid,
                      contactInitials: nameInitials,
                      url:
                        Crmurldata +
                        "/main.aspx?pagetype=entityrecord&etn=contact&id=" +
                        contactid,
                      initia: false,
                    });
                  }
                } else {
                  nameInitials =
                    firstname.substring(0, 1) + lastname.substring(0, 1);
                  if (self._AllContacts.length < 5) {
                    self._AllContacts.push({
                      FullName: fullname,
                      Designation: accountrolecode_formatted,
                      imgurl: "",
                      contactInitials: nameInitials,
                      url:
                        Crmurldata +
                        "/main.aspx?pagetype=entityrecord&etn=contact&id=" +
                        contactid,
                      initia: true,
                    });
                  }
                }
              }
            }

            if (results[2].entities.length > 0) {
              self.OnboardingCount = results[2].entities.length;

              for (var i = 0; i < results[2].entities.length; i++) {
                var _accountid_value =
                  results[2].entities[i]["_accountid_value"];
                var _accountid_value_formatted =
                  results[2].entities[i][
                    "_accountid_value@OData.Community.Display.V1.FormattedValue"
                  ];
                var _accountid_value_lookuplogicalname =
                  results[2].entities[i][
                    "_accountid_value@Microsoft.Dynamics.CRM.lookuplogicalname"
                  ];
                var emailaddress = results[2].entities[i]["emailaddress"];
                var name = results[2].entities[i]["name"];
              }
            }

            var companysTabname = "";
            var contactTabname = "";
            var onboadingtabname = "";

            if (results[3].entities.length > 0) {
              for (var i = 0; i < results[3].entities.length; i++) {
                var icici_name1 = results[3].entities[i]["icici_name"];
                var icici_value1 = results[3].entities[i]["icici_value"];

                if (
                  icici_name1 == "RMWB_Organization_CorpOrgForm_CompanyInfo"
                ) {
                  companysTabname = icici_value1;
                }
                if (
                  icici_name1 == "RMWB_Organization_CorpOrgForm_Contactstab"
                ) {
                  contactTabname = icici_value1;
                }
                if (
                  icici_name1 == "RMWB_Organization_CorpOrgForm_OnboardingsTab"
                ) {
                  onboadingtabname = icici_value1;
                }
              }
            }

            //Rendering data
            self._props = {
              contextVar: self._context,
              entityID: self._entityId,
              PanNo: self.PANno,
              MCap: self.Mcap,
              SharePrice: self.Shareprice,
              IncorporateDate: self.Incoporationdate,
              PromoteHold: self.Promoteholding,
              AllContacts: self._AllContacts,
              contactsTab: contactTabname,
              companyInfotab: companysTabname,
              onboardingsTab: onboadingtabname,
              OnboardingCount: self.OnboardingCount,
              ObofCount: self.ObofCount,
              LeadsCount: self.LeadsCount,
              DealsCount: self.DealsCount,
            };
            ReactDOM.render(
              React.createElement(CardControlComponent, self._props),
              self._container
            );
          },
          (error) => {
            console.log(error);
          }
        )

        .catch((error) => {
          console.log(error);
        });
    } // ending if
    else {
      self._props = {
        contextVar: self._context,
        entityID: "",
        PanNo: "",
        MCap: "",
        SharePrice: "",
        IncorporateDate: "",
        PromoteHold: "",
        AllContacts: [],
        companyInfotab: "",
        contactsTab: "",
        onboardingsTab: "",
        OnboardingCount: 0,
        ObofCount: 0,
        LeadsCount: 0,
        DealsCount: 0,
      };
      ReactDOM.render(
        React.createElement(CardControlComponent, self._props),
        self._container
      );
    }
  }
}
