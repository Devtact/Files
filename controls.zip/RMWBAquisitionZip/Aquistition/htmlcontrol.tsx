import * as React from "react";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { Dialog, DialogType, DialogFooter } from "@fluentui/react/lib/Dialog";
import { Label } from "@fluentui/react/lib/Label";
import { Icon } from "@fluentui/react/lib/Icon";
import { Stack } from "@fluentui/react/lib/Stack";
import { DefaultButton } from "@fluentui/react/lib/Button";
import { Link } from "@fluentui/react/lib/Link";
import { useState } from "react";
//@ts-ignore

export interface cardParams {
  contextVar: ComponentFramework.Context<IInputs>;
  entityID: string;
  PanNo: string;
  MCap: string;
  SharePrice: string;
  IncorporateDate: string;
  PromoteHold: string;
  AllContacts: {
    FullName: string;
    Designation: string;
    imgurl: string;
    url: string;
    contactInitials: string;
    initia: boolean;
  }[];
  OnboardingCount: number;
  ObofCount: number;
  LeadsCount: number;
  DealsCount: number;
  companyInfotab: string;
  contactsTab: string;
  onboardingsTab: string;
}

const dialogContentProps = {
  type: DialogType.normal,
  title: "Alerts",
  subText: "Under development",
};

export const CardControlComponent: React.FunctionComponent<cardParams> = (
  cardParam
) => {
  //hide and show dialog const variable
  const [hideDialog, setHideDialog] = useState(true);

  //variable for notification visibility
  var notifyObof = true;
  var notifyLeads = true;
  var notifyOnboardings = true;
  var notifyPipeline = true;

  if (cardParam.OnboardingCount > 0) {
    notifyOnboardings = false;
  }

  var lengthContacts = cardParam.AllContacts.length;

  function OnboardingCall() {
    let control: any = Xrm.Page.ui["controls"].get(cardParam.onboardingsTab);
    control.setFocus();
  }

  //function for Company Info
  function CompanyTab() {
    Xrm.Page.ui.tabs.get(cardParam.companyInfotab).setFocus();
  }

  //function for Contact Info
  function ContactTab() {
    let control1: any = Xrm.Page.ui["controls"].get(cardParam.contactsTab);
    control1.setFocus();
  }

  return (
    <div className="mr-15">
      <div>
        <div className="Aquisition">
          <Stack className="Aquisition__body">
            <Stack className="Aquisitioncarousel__Items_Main">
              <div>
                <Label className="fl fontB">Company Info</Label>
                <Label
                  className="fr fontB tablabel2"
                  style={{ marginRight: 5 }}
                  onClick={() => {
                    CompanyTab();
                  }}
                >
                  View Details
                </Label>
              </div>
              <div className="clear"></div>
              <Stack className="Aquisitioncarousel__Items_Card">
                <Stack className="row">
                  <Stack className="column">
                    <Label className="tal labelh">PAN</Label>
                    <Label className="tal fontB">{cardParam.PanNo}</Label>
                  </Stack>
                  <Stack className="column">
                    <Label className="tal labelh">M CAP (in Million)</Label>
                    <Label className="tal fontB">{cardParam.MCap}</Label>
                  </Stack>
                </Stack>
                <Stack className="row">
                  <Stack className="column">
                    <Label className="tal labelh">Share Price</Label>
                    <Label className="tal fontB">{cardParam.SharePrice}</Label>
                  </Stack>
                  <Stack className="column">
                    <Label className="tal labelh">Incorporate Date</Label>
                    <Label className="tal fontB">
                      {cardParam.IncorporateDate}
                    </Label>
                  </Stack>
                </Stack>
                <Stack className="row">
                  <Stack className="column">
                    <Label className="tal labelh">Promoter Holding %</Label>
                    <Label className="tal fontB">{cardParam.PromoteHold}</Label>
                  </Stack>
                </Stack>
              </Stack>
            </Stack>
          </Stack>

          <Stack className="Aquisition__body mt10">
            <Stack className="Aquisitioncarousel__Items_Main">
              <div>
                <Label className="fl fontB">Contact</Label>
                <Label
                  className="fr fontB mr5 tablabel2"
                  onClick={() => {
                    ContactTab();
                  }}
                >
                  View All
                </Label>
              </div>
              <div className="clear"></div>

              <section className="Aquisitioncarousel" aria-label="alert">
                {lengthContacts > 0 && (
                  <ol className="Aquisitioncarousel__viewport">
                    {cardParam.AllContacts.map((currentContact, i) => {
                      return (
                        <li
                          id={"Aquisitioncarousel__slide1" + (i + 1)}
                          tabIndex={0}
                          className="Aquisitioncarousel__slide"
                        >
                          <a href={currentContact.url}>
                            <div className="Aquisitioncarousel__snapper"></div>

                            <Stack className="Aquisitioncarousel__Items">
                              <Stack className="row">
                                <Stack className="fl">
                                  {currentContact.initia == true ? (
                                    <div className="contactInitial">
                                      <p>{currentContact.contactInitials}</p>
                                    </div>
                                  ) : (
                                    <img
                                      src={currentContact.imgurl}
                                      className="imageWrapper"
                                    />
                                  )}
                                </Stack>

                                <Stack className="fl ml10">
                                  <Label className="tal">
                                    {currentContact.FullName}
                                  </Label>
                                  <Label className="tal -mt10 fontB resize">
                                    {currentContact.Designation}
                                  </Label>
                                </Stack>
                              </Stack>
                            </Stack>
                          </a>
                          <div className="carouseldot_main">
                            <div className="carouseldot_container">
                              <div
                                className="carouseldot_activeCarousel"
                                style={{ marginLeft: 14 * i + 5 }}
                              ></div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ol>
                )}
                {lengthContacts > 0 && (
                  <aside className="Aquisitioncarousel__navigation">
                    <ol className="Aquisitioncarousel__navigation-list">
                      {cardParam.AllContacts.map((currentContact, i) => {
                        return (
                          <li className="Aquisitioncarousel__navigation-item">
                            <span className="Aquisitioncarousel__navigation-button"></span>
                          </li>
                        );
                      })}
                    </ol>
                  </aside>
                )}
                {lengthContacts == 0 && (
                  <ol className="Aquisitioncarousel__viewport">
                    <li
                      id="Aquisitioncarousel__slide1"
                      className="Aquisitioncarousel__slide"
                    >
                      <a href="#">
                        <div className="Aquisitioncarousel__snapper"></div>

                        <Stack className="Aquisitioncarousel__Items">
                          <Stack className="row">
                            <Stack className="fl ml10">
                              <Label className="tal"></Label>
                              <Label className="tal -mt10 fontB">
                                <strong>no records available</strong>
                              </Label>
                            </Stack>
                          </Stack>
                        </Stack>
                      </a>
                      <div className="carouseldot_main">
                        <div className="carouseldot_container">
                          <div
                            className="carouseldot_activeCarousel"
                            style={{ marginLeft: 5 }}
                          ></div>
                        </div>
                      </div>
                    </li>
                  </ol>
                )}
              </section>
            </Stack>
          </Stack>

          <Stack className="circularicons">
            <div className="rows">
              <Stack className="col-4 border-right border-bottom">
                <Stack
                  className="iconWrapper"
                  onClick={() => {
                    setHideDialog(false);
                  }}
                >
                  <Icon iconName="Bank" className="iconfontsize"></Icon>
                  <p className="notification" hidden={notifyObof}>
                    <span>{cardParam.ObofCount}</span>
                  </p>
                </Stack>
                <Label className="iconLbel">OBOF</Label>
              </Stack>
              <Stack className="col-4 border-right border-bottom">
                <Stack
                  className="iconWrapper"
                  onClick={() => {
                    setHideDialog(false);
                  }}
                >
                  <Icon iconName="PartyLeader" className="iconfontsize"></Icon>
                  <p className="notification" hidden={notifyLeads}>
                    <span>{cardParam.LeadsCount}</span>
                  </p>
                </Stack>
                <Label className="iconLbel">Leads</Label>
              </Stack>
              <Stack className="col-4 border-right border-bottom">
                <Stack
                  className="iconWrapper"
                  onClick={() => {
                    OnboardingCall();
                  }}
                >
                  <Icon iconName="Onboarding" className="iconfontsize"></Icon>
                  <p className="notification" hidden={notifyOnboardings}>
                    <span>{cardParam.OnboardingCount}</span>
                  </p>
                </Stack>
                <Label className="iconLbel">Onboardings</Label>
              </Stack>
            </div>
            <div className="rows">
              <Stack className="col-4 border-right border-bottom">
                <Stack
                  className="iconWrapper"
                  onClick={() => {
                    setHideDialog(false);
                  }}
                >
                  <Icon iconName="More" className="iconfontsize"></Icon>
                  <p className="notification" hidden={notifyPipeline}>
                    <span>{cardParam.DealsCount}</span>
                  </p>
                </Stack>
                <Label className="iconLbel">Deals in Pipeline</Label>
              </Stack>
              <Stack className="col-4 border-right border-bottom"></Stack>
              <Stack className="col-4 border-right border-bottom"></Stack>
            </div>
          </Stack>
        </div>
        <div>
          <Dialog
            hidden={hideDialog}
            onDismiss={() => {
              setHideDialog(true);
            }}
            dialogContentProps={dialogContentProps}
          >
            <DialogFooter>
              <DefaultButton
                onClick={() => {
                  setHideDialog(true);
                }}
                text="OK"
              />
            </DialogFooter>
          </Dialog>
        </div>
      </div>
    </div>
  );
};
