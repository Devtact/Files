import * as React from "react";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { IRenderFunction } from "@fluentui/react/lib/Utilities";

import { FontIcon } from "@fluentui/react/lib/Icon";

import { mergeStyles } from "@fluentui/react/lib/Styling";
interface EmailParameters {
  [to: string]: any;
}
interface actionItem {
  [statecode: number]: any;
}
import { Panel, IPanelProps } from "@fluentui/react/lib/Panel";
import { useBoolean } from "@fluentui/react-hooks";
import {
  Icon,
  IStyleSet,
  Label,
  ILabelStyles,
  Pivot,
  PivotItem,
  Stack,
  DefaultButton,
  Link,
  PrimaryButton,
} from "@fluentui/react";
import {
  DefaultPalette,
  IStackStyles,
  IStackTokens,
  IStackItemStyles,
} from "@fluentui/react";
import { Separator } from "@fluentui/react/lib/Separator";
import { Image, IImageProps } from "@fluentui/react/lib/Image";
export interface cardParams {
  multiData: {
    heading: string;
    startTime: string;
    endTime: string;
    accountName: string;
    joiningLink: string;
    id: string;
    modeOfMeeting: string;
    location: string;
    editLink: string;
    date: string;
    appointmentID: string;
  }[];
  value: number;
  status: boolean;
  birthDayArray: { name: string; id: string; justName: string }[];
  birthdayStatus: boolean;
  context: ComponentFramework.Context<IInputs>;
  birthdayView: string;
  appointmentView: string;
}
export interface IProps {
  multiData: {
    heading: string;
    startTime: string;
    endTime: string;
    accountName: string;
    joiningLink: string;
    recordID: string;
  }[];
  value: string;
  onChange: (value: string) => void;
}
export interface IState {
  value: string;
}
const labelStyles: Partial<IStyleSet<ILabelStyles>> = {
  root: { marginTop: 10 },
};
let birthdayImgData =
  "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMACgcHCAcGCggICAsKCgsOGBAODQ0OHRUWERgjHyUkIh8iISYrNy8mKTQpISIwQTE0OTs+Pj4lLkRJQzxINz0+O//bAEMBCgsLDg0OHBAQHDsoIig7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O//AABEIAO0BZAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAAAQIDBAUGB//EAEkQAAEDAwIEAgcEBgUKBwAAAAEAAgMEBRESIQYTMUFRYRQiMlJxgZEHQqHBFRYjJGKxM3JzgrIlNDZDdLPR4fDxNURTVWN1wv/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACYRAQEAAgICAgEEAwEAAAAAAAABAhEhMQMSQVETBBQiYVJxgbH/2gAMAwEAAhEDEQA/APqAKkqwVIFaZTQllCAQhCAQhCgEk0kAhJCBoSQgEkIQMHCNSihNgJyoppIFhaqCEOeXkez0WZbbe4aXN75yitirniEsLmkdtlYq55BHC5x8NlFriEYKFM7pYRNEmjCeECSyphhKToyFdIhlBTxulhRUSkp4S0oBgyVbgAKDMAqwrcZqmRncKghanHZZ3dVnJqKy1QLVahrS9wAGSVlVBaUsLpC3ks9Z2HeCxyRuieWuGCFbjYksqgtUdCtKiVGlehCmhB2443SODWjdaHUTg3LXZPgrqWMMjz3KvWmXJOQcHqE9StrGhs2R3CoVRPKFXlPKCaagHJ6lBJIoyhAkIQoEhNJUCEIRQkmkgSEIUCTY90bw5pwQkkitguBxvHv5FZ56h859bYDsFWkgSE0kAgdUIQX42SKQdkIJAW2FTxhyim46jlJYrYQhCBEo5hSKiU2aDnEqsqRUSgS0ULQZiT2GyzqUUpikDx80l1S8x1lkr4g6HX3b/JXMqInjIePgVTVVMZidGDqJ8F2y1pyku3MKSkkuDsihNCD1ML26AMqT5GMGXOC5wcR0KCSeq1wylM/myF30VRCkhVEEKeEaUEE8plqWkoHlCWEKB5RlJCCSEkIBCWUZRTSRlbqenaGB7xknffsgwpLquiY8Yc0H5LBUQcl2Ru09FBQhBQikhCECQmkgEk0kC6IJJ6oSUAhCYRV9PTGcOPTCoc0tJB6jZdWibppm+eSsNazTUO891FZioFTKiVURKiVIqJRESoqRUUUkJpKBFRU1EhUJCEIOumkhaZNCEIGhCERZEwOOT0CuwOmFXCRpI7q1biVTLGANQCpWiU4YVmWascqy3Sa5VF1jlbG0UVc+nZoB3aACCfPdKz3Wa4XO8UsrGNZQVLYoy0HJBaDv55WLhP8Az7iP/wC3l/wtRwwc33iX/b2/7sLEvTrZOU+J+JHcP11kpw2Mi4VfLkLwTiMYBI365cF6J7dLScdBlfP+PIjX3OucwZdaLUKhv8LjM13+FhXv2SCejbK05EkQcD4gjKs7rOckxleItXF15FtobveaOk/RlcQBNS6g6nJcWjWHE5bnuF07/drvTXm2WyzsojLWtmeXVQcW+oAceqds5XIpBEPsS/bY0/o2TGfey7T+OFrkbJ+tXCfN/pBQ1GvPvctmfxWXTU3br7bKbiCsrrNcuVRtp7xb2OElLKdTdenLcEYy13Yr1NhuTLxYqG4x4AqYGvIH3SRuPkcheTphn7Ra/l4LRbIudj39btOfPTlQ4euw4bt1+o5T+ytE8kjGn/0njWz+ZHyV2zZPh6SyXqou92u7AyMUVDOKeF4B1PeGgvyc42JC6VYRyiD2Xn+CozbOFKRk5PpM4NROSNy+Q6jn6rpT1BlOB0Wp1usZ63qIA5TUAnlQPKMqJSygmko5RqQSSS1I1IBCWpLUopqQ6qOUwUHYpv8AN2fBYbh/T/ILZSuHo0eT16LFcXYqPkFF+ayFRKC5RJVQyolBKiSgColBKiUDyhJCgRK3UtqknaHyO0NPQdystMwSVMbD0Lt16YbDC1EcaaykP/ZvOnzQuyhVHJBTUMqQcoJISyhA00kIGHFpyFZzzjoFUkrvRpJzy87qKEIPEWiySXO7cQTMvV0odN0kbopJgxp2buQWnfdbeC6Z1HW8QU7qiapMdeBzZ3Bz3+oNyQBur+Eh+98RHxvE38mo4ZOLzxKT/wC4D/dtWJ8O2VvM/wBOJVXyyxXni+G5XCGF9RHHSxsedyGxHOP7zz9F6jhSr9M4Ntcuck0bGE+bRp/JYuCAJbLLcSATXVs9RnHUay0f4UcFjkWmsoN/3CvnpxnwDtTfwcFYmetWfThcK2O43rhO0RXCviFpY1sgpYYyHy4cSGvcT0z4LpcSsr38ZWEWySCKo5NVpdOwuYBpZnYeS28B/wCg1o/sPzKVz/07sHlBV/4Wqa4X2vvf+tdjshtQqZ6mqdWV1Y8PqKgt06sDAaB2aB0C85xfa56jii301OQKe9gU9YPFsThJ+LQR8B5r3K8/fCP1s4ZH/wA9R/uHK2cM45X227ulLSppKuaOEJoRUSolTRjOyCpGVbyjjooFmE0m0coUtKWlRSSUtKuhpXS79AqdM+UwVsdQ4G2Vkewxu0lLNJLtKqqhDT0LtWCKlrfjqOn81ZXP11BI8AsdXR+mU7WOyBHKyUHza4H8lc4lzslcscdZWuty3jIrKSsDC4gDutLKdjRvuV1k25W6YSColbn04xlqyvbgq2aJdqilhWFqWAstK8IwpJIBpLHhw6g5Xfpa2OeMesA7uCvPoyR0KSpp6jWz3gheX5jveKFeDVdFATIVlMzVUNB6DdETZSSuGcY+JUHxvj9ppC6iTmhww4ZCDloUpo+VKW9uyhlA0KqepgpmcyonjhZ70jw0fUqUcsc0Ykie2RjujmkEH5hFSQjKERxuHrfVUE13dUsDRVXKWeLDgdTHYwduiz01uuNH+ss0UIMtZI6SjHMb655QA77esO69AmGkppr2rm8PW91p4eoLe8APp4GseBv62PW/HKz223VdHfb1IWAUlaY5Ynahu/Rpft1HQLtFpSTR7Xn+3H4ToKm18K26hrYxHUQQ6ZGBwdg5J6jbulXW+qm4ttFfHGDTU0NQyZ+oDSXBunbqckLk3vjoUtwnt9mpWV01JG6Wqme/TFC1oyRkZye3x2Xq6eR01NFK5mhz2BxafukjOFOLw1fafyvysXIudBU1PENjrIow6GjkmdM7UBpDonNG3fcjouuhViXRJKl9fRsrG0TquBtU8amwGQayPHT1V6IihNIopK2IernxVSsjd2VnaVYq5RtlWZVUr87BavTMnKpCELm6ADJwutG0Nja0dguTnddKnna9gz17haxYyXYWCuaA9p8VudIxoyThcyol50pd26BW9JO1rmmO37jLicgZWPOVrYDJb5Wl5B3AIO427LG0aWgLlr+W3Xf8dLIccwZWsHIWHODkK5tQMetnK643TnY0FYZSC848VbJUZGG/VZymV2YwioFSKisNEkU1EopJFMqJQCEkIOurKZ4ZO0np0VSFUdhYKK+Wu41dXSUdbFNPRO01DGneM+f0KrjqZIxgHI8CvB2n7OnUdyr5qm6ySUlZJqfBCNBlbkkNe7rjfcDqpdtYzGy7rfxbx0aSiqqqzQx1MdOeW6rlOIQ/ONDe73fDYY6rFw9xTeK+wUxmiiqLrcJHmmYG6WsiBwZH46NBz5noF5Tj26w3a/Q2GjxFbLWMSNiGBqGzsAbbbNHmT4r09oudFYaV0cEJuV+qWtDqOj9cQNaMMjLujGtHXzysb3Xe4SYTjlfxG208M2WW43bRdLnK0sifVNDi95HRrTsxo64HbuVf9ldirqLhFslVqjFTKZYo3dWswAD5ZxlKzcEVN5vIvfF8rKmobvDQxnMMI7A+OPDp8V7o3ChbXCgNXAKot1CDmDXjx09VqTnbnll/H1nLLLBJEMkbeIVWV13NDmlp6Fch7dLy3wK24mDurHyMiidJI4MYxpc5xOAAOpWWedtNA+d7XubG3URGwvcfgBufkvn/ANoXGTaq1ssdriqxVVrgJGSU0kbzH4AOAJ1HbbwKntJG8MLndR7bh7iWg4mpp6i38zlwTGIl7catgcjyIK4n2h8UO4ftQpaN3+UK3LItPVje7vj2HmfJT4JFusnDzaJsdVE+KMz1U1RSSRNLvvHLmgbdB5BeHt7rnxzxzPdaeMtihOmGaQZZTtB9U47uxkgeJz0WcsrqfbphhPe34jtcNcOiKOOwtbqkD2VN6m8x60dPnue5+fivo6xWu201ooWUlK06Gkuc95y6Rx6uce5PitmVZNOeeXtdmvPcacUR8L2V07dL6ubLKeM9z3cfIdfoF6AuDQXOIAAySey+NVl0/W3jp1a+M1FFRuDKanHWYg4Y3H8Ttz4NB8FMrpvxYe13eo9BwZZJv05DV15dLXsiNXWSv3c18gxHH8mlzj8QF9EXPsttdbKEtnkEtXO8zVMo+/IeuPIdB5Bb8qyajOeXtdhCWUKsBJNJAajjqs1fXU1toZq2rkEcELS57j/11WlfNuL6yo4v4og4Utrz6NA/VVSt6ZHU/Bo/ErNum8Mfavb2K903EFrZcKRkrInuLcSNwcgroqihoqe3UMNFSs0QwMDGN8h+avVS63wSYJHQ4SQiGXOd1JKimkiNEbtNE86SfXAGBnBO2VkaCBuSfMrbTDMD8+zlYmSMlyY3BwBwp8m50kkmkqEkU0iioFJMpFEJRKaRRSKiUyolAISQg66EJKoa4XGXEA4c4cnq2uAqH/s6cfxnv8hk/Jd1fI/tBuLr3xlDaYwZYaD1OWP9ZK7GR8zpb5brOV1HXxYe2XKf2bcOGuuPp9W0ujgImeXfekO7G/IHWfMtXZ4zs9Bwhb23+wsfQVrahodolcWSg5JDmkkYXsLBaW2Wzw0eQ6Xd87x9+Q7uP12HkAvC/arWSXGvtfDVH688knMe0e8fVYPxcfos2axdJlc/J/T6DQXqn/QsF6neIKeSmbO8uOzGloJ+mV5zhik4d4x4un4xoX1rKimkDXRSgBpdo0hw7+z2XJ4/bUx2my8HWwF8tSGMwD1ZGABnyzuf6q71tgo+A7BT26nDqmsnd6kbPbqZT1+DR4nYAK73eWNeuO53f/GT7RbhWUfEtpzWS0tHoDonsk0MdPzWg6z0wGEnfzXWg4v4drrm2gprtBNUyHDGsyQ4+AdjB+q8vxJfJrDEK6/xUtbe6hhjpKJgL4KePO7sHcknqe+MdlHgngR1HOOIL4GsqsmWKnADWw99TgNgfLoP5N3eo164+m8nu6yqgoKKasqX6IYGF73eAC+f8C0c/E3EdZxhcGeo15jpWHo0+X9Vu3xJVPHHEFdf5aSwWuJopLjIAyU51T6Xe0P4M/XST06+5ibbuFOH4YS/RTUzAxuBl0jvIDq5x7ead1nXph/deb+0+8y09rgslJl1Vc3aS1vXQCNvmcD5FdGmloOBuHqW2hpnqxGXmCLGuV2MvefBo947ABeCt95qeJftDNzZR86ojGKKmd7DCNg557Bu7j59F2OOXOstujtUEj6u83lw9JqCPXezONDfdaXbAeAKm+66emtYPW8JcTt4qtb60UjqUxymNzC/WOgOQcDx8FuvF9t1hpPSrlUthYdmjq558AO641BFBwJwpS0Rbz614cWxMO80p3d/dHc9gF5PhiKbjfiCo4jv5i9DoAA2PpEDjON+w6nzIV3evlz9Jbcvh1OKuOjLwpUej2240orRyYaieINY8H2sHPu5V/2b8KQ2u2RXipaXVlUzVGHdImHpjzI7+BwuJxfVVHFfEtktrYTFb55Mwuds6RpIDpMdhgHHlv3X0C83ii4dthqZwdLBpihZ7TyBs0D4fQKTvdby4wmOPy3VddTUFM+prJ44IWe0+R2AFxqTiea8NdJZLVJVU7TgVNRJyI3f1diXfQLwtvNbx9XPvHEEzKay2/cxtJbGSN8bn6nr0A6rpM4wuNdxhbrLZqUUdva5pLHRgOfFjJJH3W6eg69FfZn8WuPl7Oy3SuuLaltwtMlulp5dADn62yj3mnAyFopbtb66rqKSlrIpp6Y4mja7dnxXOv1+Ntjkgoo21Fc2F0xY72YowCS9+Og22HUrxH2cltupLnxNcXuxM4QxADLpXk6nBo7knSB803zpmYbxuT2nGXEreGbI6pYGvqpXcuBjuhd3J8gPyUOB6+7XThuOvu8gklne50REYYdHQbDA6g/LC+f32muXFXHNPbqyXQ4MBlia71KSP2iM9MhuMnxOOy+lWev9Mk0W+BjLRTx8uKUg5lcNvU/hGMZPU9El3WssZjhJ8qOM+Ihw5YZKiMj0qX9nTt/iPf5Df6LJwFwybDaTUVbT+kK315i7q0dQ38z5/BY/0dU8ScfSVlfTyMttmPLp2SNIEsnvDPUZ3z5NXtMp3ds2+uPrP+mhLKMrTmEIyhoL3ADO6IACTgbkq59I9pY3q534LK2shppmmYlnraWgjO56LrNdGGBxOT11FSWXpyy8mrqOCb3FS8QutUo0AR4yfvE4OVkqHC2ve6A6g45A64C6N4tVrujmST62zM2bKw4cPmuPJZHB3/ijnsHQPj3+ufyWbt4P5zK23fKdJxBHJLy52ad9nD811wQ4Aggg9CF5yS2VDMOMzZGZx0Gf+K201f6KwQua4geJ3CmNvy9fj8t6ydZIlVR1DJhlp+RUiV0emXfQJUSmkikSokplRKCJKiSmQoFAZQkhB3OW/wAFEgjqtahK0Fue4WrizKzjqvm9is1LaftMmN3qBLcKp8k1ExgLgAdR1OPY4BwP+S+kLjXThijud2prsKippK6maWsnp3NyQQRghzSDsT27rFm3XDLW59reIeIqLhygNRUu1yu2gp2n15XdgB+a8/wbwxWfpKfiniBv+U6okxxEf0AO2/njAA7Bd6g4YttDWmvc2Ssrj/5qreZZB8M7N+QC7Ca32e0k1HFudinqb5TXmhrIqaqgp3U/7WDmt0k5yBqGD1381ottlhoJn1ckslXXSjEtVNjUR4ADZrfILopK6Z9rrTxd64crnceU/ELKFtyp44gGwc0MLJACAfW2I3z8V1ja7lenA3x8UFGDn0CneXCT+0ftqH8IwPHK7yFNLc7w8xcbFXM4wpb7Q09PUthpTAyKSUxiJ241DAORgkYW+nsj5qj067VAqqsNLYgwaY6cEb6G+P8AEd/h0XXQrpPauDwrwhQcKU8raZ7pppj680gAJaOjR4BY73w3X1HGNHxBRNpqgwU/KEVQ8tEb8uw/YHI9bp4r1SFNTpffLe3Io7C1nPqLjUGtr6mMxST6dIYw/cY37o/E91ybJwHHa6T0GruL6yhbMZm0wiEbXO2wX7kvxgbbDbovWpJqHvk89fbBV1d9tt6t0lOKiiD2GOo1BrmuBHVoJyMlEvC5raSrdcaz0ivq4HQicMw2Brh7Mbc7DxPU9yvQKUbdcgb4q6PeyPMWLgsUNFTUtdUenR0m8MLY9ETXZzrIydTvMnHgFRLwrdaXi6tvFvnpmCuiDDJO0ufARgEtb0dnT3K961oaMAYCz3CrpbfQTVlbII6eFup7j2H/ABWvSaZnky3/ALeeHDtNFZa2gikeJK2N4mqpDqe9zhjU4/l0XlKWps3CNvDnVEt8qLawtYYIwIabJ33zpDiTuSS7sPBegNHWX5jqu8yPoLYBqZQtfoc9nXVM4eX3RsO64ENOzji6R01FAKbhe2v9mNmhtU8dgPD8vMrnXbH+7wq4M4TlujZr/epHkXF5kNMNhK0nILj10k/d6HAyvdXGnnmtVRTUMwpZ3xFkMgG0ZxgFa2saxoYxoa1owABsB4JiNzzsrJrhzzzuV3XJ4fo7hb7NDTXSt9MqmZ1S5J2zsMnc4XSyrXU729sqrBV1pne7s8oRhTjidI7DR8URHUxr2h7gM/yVzYHv3Z6w8jsqK6gkkZrj3cBghZbPU1bNVPUxOY6J2lpPRzexBWO+K8Hk82Uz1Zw6dbRNqoiJqUSkjctdpP1BC5slb6HFyX0lS1rdgXNJ/Fdfmuxus09XpOMrWnPK7+Xn33CnmcRHUAHwdsoa5j6zC2Ro7tcCF0pm0tQ/MlPE5w+8WDP1XFrOG6cuMtHUTUkmc6o3Y/7qcuOr97WSVj4xmSJ+PJuf5LObnA4DffzCg6O5QDEVZHUY7TtGT8xhZm11W6sjgrLexrXnGtsn5EYPyKy3HXp6uN4y0jbuCujTzF/qu38CuHVUxgjM9Ll7Bu5oG+Fdaq/Mo7t7g9kl09GGdmU27qSl1GQoldHvIpwwmaUMCiVrthHpBB642VnaXiNcdDG1uCFjuNGyKMSM8cFddYrq4Ckwe5C6Xpyl5cXCEIXJ2ehBBGQoSPAbjO5WRsrmjGThGslauTMiaagCnlZaTQo5TygaSEkAhCEQISQgaSEIBCEIpKUb9EjXeCihEdIEEZG4XB4qp6ueGgkp6M1sVPVtmnp2vDTIGg6dzts7Sfkt7JXs2a7bwSfK9/tOJW7lLEksu3k620XviubF6ey3WvVqNDTya5Jf67+mPIL0tLSwUVNHTU0TYYYm6WMYMBoVqFjTdyt4LuujHGGMA7rnjYroxvD2AgreLnkZaD1CwVLOXLgd910CQOq59S8PmOOg2Vy6THtVldKhjb6MHdySSuYtVHUOYeV1a4/Rc2r02uAafNZJ4dy5oB8ui5dTfXQVjqZzOeS7YxDdo8StdHUOqJg0HIKx+TDK+svLyZ4Z69tXVBlLOocPiFlmdG4nUAT33Wi93+02NrW1k2JHezGxhe4+eB0Xg+IOJYsNqaZvPEhIjY3LT887hTLyY491P2/ktnG3qzSxzO2DmHycQslwgpoWujkuropPdyMj8F4R1/v07TyyyJvhufzWf9MXVmebHFOe+rLSVx/c+P7dr+h8munentFayTm09zmladxq0kH6BUwXo0lYyguZa5s3snp0/NZmcS1DLeKelomwvLiXanag34dF5i7Wy53CqbWumc+Vm7MbBvyU/Nhvtcf0Xk1uzT6XBPqnkphNplj3B99uMgpUlAyWqDopMaz6+6zWithnsMM0+hlS2PS9ruoIXasIpn0fNhe2R5J1EAjT5YK645S/Llj4Mt8ziOpjAAHbZRKZUSuz2EURyOikD29QolRKDsxXGJ7RlwB8CsFwqhPJpactashUStXLcZmMlCEkLDTpYTCaEAnlCEDymHKCaCeUKCeUDQo5RlBJCjlPKBoSTQCEIQCSaFQkJoQJCaSBKTJXx+ydvBJJNosdUSOGM4+CpTQluwki4NyScYTWC4SPgeDg6XDIyvP+ozuHjtjv+nwmeequbHDGTy2NaD1wEn8sncDZcmS4kDO6qddGg7nYr4lr7E8boT0tJICXRMye+OqwTW6llaHCJo7dFW66tAGd1Sbs3OQe6izx0qmiiaQAwD5dFjnoIBH7Az44Vk92Gogj5rHU3lgJbtuEi/jc6ek5Ux09PBaYXMhjIcAQBtlZKi6sLw44VMt1jI2A2XSbZvjl4dNtRgh2A3JxhdSx3JtJW6HbRzENPkex/FeQdcea1uMZB+i6FrnbNcadkjwG8xuryGV28ftMpY5eTx4+tlfTCoFMPa9oc0gtO4ISK+0+MiVEplRKBFRJUiolAkIQg7/ICXICuwU8IijkhHJCvwjCgo5IRyVfhPCKo5IRyR4K/CMIKOQEckeCvwjCCjkjwRygr8Iwgo5QRygrsIwgp5YRywrsIwEFPLCOWFbgIwgp5YRywrsBGAgp5YRy1bhLCCoxo5YV2EsIKeWE+WFbhLCCrlBayxk0A1sa7bBBGVThXU59pnjuFOycME9ooJXZdSRZOrcDByQsL+G7bIGjkubmMtGHnY77/Hdd2QYB8lRIMDI7Oz8iuGXjwvcd55c51XnH8L28NgfrmLWAh7dXt9Nz+PRUv4QosTRCpnD2kva846Z6Y+BXoZm+o8eBB/6+qrO84PvQ/wD5/wCSx+Hx/Tp+fy/5PNTcIW1/LkdUVIil9UsDhlpzuQcfgsUvAVvdzI3V9VzYTnWMYeM9Mdl6eQfusH9ofyVcnt1Tv+uqfiw+j8/k+3k5OALW7P75WBszcNGoZjPiDjdVjgK1sOfSKl+BoILxgn3l6s+1EPBuVV2aPHdX0x+k/Ln9uBDwXaIWgcuSTDdJLn+0fE47+a61JaaKmd+wpo2kns1ac9/mtVDHrnHg3dakjNyt7rY2nDWBvgEjCFoIUSF3cWcwBRNOFpUSiM5pwomnC04RhBl9HQtOEIrq5RlLJRk+C0weUZKW/gjdA8oS3RlQSyjKimqHlLKEIoQjCFAJJowgSMowjCBITwjCBITwjCBJJ4RhAkJ4RhFRQpYRhBFON2l4KNKNKGml7d/isz25jPjgj6LUz14mnuNiqy3DnA+IP5LNhKxvGqMn3o8/T/sqGDMkB8WOH81qjZ+zY09QXMKzwD1qY/xOCw2xSj90h/tT+Sol/o6g+LgFpmb+6RDvzj+Szy7wy/xSBZVTJs8+TFUdvk1Wye3IfgFS4+sfN2PooozgrqW1mIXP944+QXIB1HbuvQwxcqFjPdC1ilMpFMtSwujCJKRUiAkQgjlGUYSKAyhLIQg6eQjKpNQ3VjlynzEZWlunQMtzvkq7ZRGXEAdSo6xzCzO46qiR88VQ58URkyfHAVjGyyuyYxGT1OrKm10se4RtDnHAJwEagoVDmMiDZJMYWKmq66omP7u1kWdnFw3+hTbUx3NuiMnokHg5AOcdVF7nCra9oIYBjZZ5S6la6Qes074DSSm0mO+mvKMrLSVRqgS6CWLHQvZjPwWoYBBWmbNXVGQnlVzanVIfjIA7K1rQW5JAPgpKtLKSgJSZSwxvAH3sbFT2VQE4AJ2B6JtaXHA6qMw5kbWg+ypRuLTvtt2KioNeHZx2OCmo6NMErG4Ad0wq2mZrGtaxpwN9RUlvytn0uQqw6bAyGfIlTz4qoaFCUOdMJG42GMFMau+Pkgm0FxwBkqMbxJ7O++E2u0lVMY6N5LXNwTndqnyfC3UOY5ndpwVLCocx2su1kE+ACm046kn4qz+yrMeSkG/BZpzK52YpNA+Csje9oAc7UfFNo0RODXmNxGSM4VjgDv5YWNwzLzM4OMdFEMx7cr3+R6Kbq8Li3SXY98OWcsETmsJGpspcB5KJp6YnOhwP8LiP5FKqY2c+05vbLSQfqN1m7WWMU4JgYO5mcf5LJKcN0nu/K7UL2QsY0jVp2Dnbn6rLXN9IJDQ3SfHOVnTW3He8Zdv1cszpMu69ifqtn6u287yCcu/2h/8AxT/V+153gLse84n+amqu4hTU0vLZVhoMZOWnPXCvddJvFq1ztbFQwwU7Dpi6BZ3xxikaxlOdWSXEjdy10jObpN7zPqsr+IWNdpM7MraKKnP+rePiEv0XRHcwg/3VdVNqJ6u4iljqIgND/WB8W+ICPTpnB/7TGBloI3K6E0TZYo484bG3SBjsswt0DdsDHgGqcrtkdXVAxpeDkZUfTarxC3iggGMBS9Ehx7KptzvTatC6Po0XghU27mU8qAKeVtySyjKWUZQPOUZSQgeUZSyjKB6vJGo+CEZQPUfBGpLKMop6k9SjlGUEs7JaksoygedkZUcoygeUZSykSgllLKWUZQPKMpZSyUDyU8qBJSJUE8phV5KNRQXfNRPXqqy8paioqZKiSolxUclRTJUCfJBcVAuKiglRJQSVEuKBkpZSyUaiqGkUtRS1FAEpZQSkThAZUS5Bcol2EDyhQLkIP//Z";
const buttonStyles = { root: { marginRight: 8 } };

const imageProps: Partial<IImageProps> = {
  src: "../images/bulb.png",
};

// Styles definition
const stackStyles: IStackStyles = {
  root: {
    background: DefaultPalette.themeTertiary,
  },
};
const stackItemStyles: IStackItemStyles = {
  root: {
    background: DefaultPalette.themePrimary,
    color: DefaultPalette.white,
    padding: 5,
  },
};
const itemAlignmentsStackStyles: IStackStyles = {
  root: {
    background: DefaultPalette.themeTertiary,
    height: 100,
  },
};

// Tokens definition
const containerStackTokens: IStackTokens = { childrenGap: 5 };
const horizontalGapStackTokens: IStackTokens = {
  childrenGap: 10,
  padding: 10,
};
const itemAlignmentsStackTokens: IStackTokens = {
  childrenGap: 5,
  padding: 10,
};
const clickableStackTokens: IStackTokens = {
  padding: 10,
};
export const ReactSampleTextBox: React.FunctionComponent<cardParams> = (
  cardParam
) => {
  const [selectedMeetingName, setselectedMeetingName] = React.useState("");
  const [selectedMeetingtime, setselectedMeetingtime] = React.useState("");
  const [selectedMeetingComp, setselectedMeetingComp] = React.useState("");
  const [selectedMeetingAG, setselectedMeetingAG] = React.useState("");
  const [selectedMeetingMM, setselectedMeetingMM] = React.useState("");
  const [selectedMeetingCA, setselectedMeetingCA] = React.useState("");
  const [selectedMeetingBA, setselectedMeetingBA] = React.useState("");
  const [selectedMeetingMD, setselectedMeetingMD] = React.useState("");
  const [selectedMeetingMT, setselectedMeetingMT] = React.useState("");
  const [selectedMeetingAP, setselectedMeetingAP] = React.useState("");
  const [selectedMeetingFPR, setselectedMeetingFPR] = React.useState("");
  const [selectedMeetingTD, setselectedMeetingTD] = React.useState("");
  const [selectedMeetingMMID, setselectedMeetingMMID] = React.useState("");
  const [selectedMeetingACID, setselectedMeetingACID] = React.useState("");
  const [selectedMeetingAPID, setselectedMeetingAPID] = React.useState("");

  const [isOpen, { setTrue: openPanel, setFalse: dismissPanel }] =
    useBoolean(false);

  const underDevelopmentalertDialog = () => {
    const alertStrings = {
      confirmButtonLabel: "Ok",
      text: "Under Development.",
      title: "Alert",
    };
    const alertOptions = { height: 120, width: 260 };
    // this.props._context.navigation.openAlertDialog(alertStrings, alertOptions)
  };

  function openEmail(
    context: ComponentFramework.Context<IInputs>,
    name: string,
    id: string,
    img: string
  ) {
    let contactid = id;
    let activityParameters: EmailParameters = {}; // Set the to field -- this IS working!
    let lookupValue = [
      {
        id: contactid,
        name: name,
        entityType: "contact",
      },
    ];
    activityParameters["to"] = lookupValue;
    activityParameters[
      "description"
    ] = `Dear ${name}, <br><br>Wish you a very Happy Birthday! May this year bring you more success and fill your life with joy, good health and happiness.<br><br>Warm Regards,<br><br>${context.userSettings.userName} <br>
    <img src=${img} style="height: '100%'; width: '100%'" ></img>`;
    activityParameters["subject"] = "Happy Birthday";
    activityParameters["regardingobjectid"] = lookupValue;

    Xrm.Navigation.navigateTo(
      {
        pageType: "entityrecord",
        entityName: "email",
        data: activityParameters,
      },
      { target: 1 } // Open in modal
    );
  }

  function openViews(id: number, viewId: string) {
    switch (id) {
      case 1 /*add new appointment */:
        Xrm.Navigation.navigateTo(
          {
            pageType: "entityrecord",
            entityName: "appointment",
          },
          { target: 1 }
        );

        break;
      case 2 /* open today's birthdays */:
        Xrm.Navigation.navigateTo(
          {
            pageType: "entitylist",
            entityName: "contact",
            viewId: viewId,
          },
          { target: 1 } // Open in modal
        );

        break;
      case 3 /* open appointment list*/:
        Xrm.Navigation.navigateTo(
          {
            pageType: "entitylist",
            entityName: "appointment",
            viewId: viewId,
          },
          { target: 1 } // Open in modal
        );

        break;

      case 4 /* Edit current appointment */:
        Xrm.Navigation.navigateTo(
          {
            pageType: "entityrecord",
            entityName: "appointment",
            entityId: viewId,
          },
          { target: 1 }
        );

        break;

      default:
        break;
    }
  }

  function getSelectedMeetingDetails(
    name: string,
    time: string,
    comp: string,
    appointmentID: string
  ) {
    Xrm.WebApi.retrieveMultipleRecords(
      "activityparty",
      "?$select=addressused,_partyid_value&$filter=_activityid_value eq " +
        appointmentID
    ).then(
      function success(results) {
        var contactString: string = "";
        var systemUserString: string = "";
        for (var i = 0; i < results.entities.length; i++) {
          var addressused = results.entities[i]["addressused"];
          var _partyid_value = results.entities[i]["_partyid_value"];
          var _partyid_value_formatted =
            results.entities[i][
              "_partyid_value@OData.Community.Display.V1.FormattedValue"
            ];
          var _partyid_value_lookuplogicalname =
            results.entities[i][
              "_partyid_value@Microsoft.Dynamics.CRM.lookuplogicalname"
            ];
          if (addressused) {
            switch (_partyid_value_lookuplogicalname) {
              case "contact":
                contactString += _partyid_value_formatted + " , ";
                break;
              case "systemuser":
                systemUserString += _partyid_value_formatted + " , ";
                break;
              default:
                contactString += addressused + " , ";
                break;
            }
          }
        }

        setselectedMeetingBA(systemUserString.slice(0, -2));
        setselectedMeetingCA(contactString.slice(0, -2));
        Xrm.WebApi.retrieveMultipleRecords(
          "icici_meetingminutes",
          "?$select=activityid,createdon,icici_meetingdate,icici_meetingtype,icici_modeofmeeting,scheduleddurationminutes,scheduledend,scheduledstart,statecode,subject&$filter=(statecode eq 0 or statecode eq 3) and _icici_appointment_value eq " +
            appointmentID +
            "&$orderby=createdon desc&$top=1"
        ).then(
          function success(results) {
            for (var i = 0; i < results.entities.length; i++) {
              var activityid = results.entities[i]["activityid"];
              var createdon = results.entities[i]["createdon"];
              var icici_meetingdate =
                results.entities[i]["icici_meetingdate"] + "";
              var icici_meetingdate_formatted =
                icici_meetingdate.charAt(8) +
                icici_meetingdate.charAt(9) +
                "/" +
                icici_meetingdate.charAt(5) +
                icici_meetingdate.charAt(6) +
                "/" +
                icici_meetingdate.charAt(0) +
                icici_meetingdate.charAt(1) +
                icici_meetingdate.charAt(2) +
                icici_meetingdate.charAt(3);
              var icici_meetingtype = results.entities[i]["icici_meetingtype"];
              var icici_meetingtype_formatted =
                results.entities[i][
                  "icici_meetingtype@OData.Community.Display.V1.FormattedValue"
                ];
              var icici_modeofmeeting =
                results.entities[i]["icici_modeofmeeting"];
              var icici_modeofmeeting_formatted =
                results.entities[i][
                  "icici_modeofmeeting@OData.Community.Display.V1.FormattedValue"
                ];
              var scheduleddurationminutes =
                results.entities[i]["scheduleddurationminutes"];
              var scheduleddurationminutes_formatted =
                results.entities[i][
                  "scheduleddurationminutes@OData.Community.Display.V1.FormattedValue"
                ];
              var scheduledend = results.entities[i]["scheduledend"];
              var scheduledstart = results.entities[i]["scheduledstart"];
              var statecode = results.entities[i]["statecode"];
              var statecode_formatted =
                results.entities[i][
                  "statecode@OData.Community.Display.V1.FormattedValue"
                ];
              var subject = results.entities[i]["subject"];

              Xrm.WebApi.retrieveMultipleRecords(
                "task",
                "?$select=activityid,description,icici_discussiontype,icici_fpr,scheduledend&$filter=statecode eq 0 and _icici_meetingminutestasknewid_value eq " +
                  activityid +
                  "&$top=1"
              ).then(
                function success(results) {
                  for (var i = 0; i < results.entities.length; i++) {
                    var description = results.entities[i]["description"];
                    var activityidTask = results.entities[i]["activityid"];
                    var icici_discussiontype =
                      results.entities[i]["icici_discussiontype"];
                    var icici_discussiontype_formatted =
                      results.entities[i][
                        "icici_discussiontype@OData.Community.Display.V1.FormattedValue"
                      ];
                    var icici_fpr = results.entities[i]["icici_fpr"];
                    var scheduledend = results.entities[i]["scheduledend"];
                    var scheduledend_formatted =
                      scheduledend.charAt(8) +
                      scheduledend.charAt(9) +
                      "/" +
                      scheduledend.charAt(5) +
                      scheduledend.charAt(6) +
                      "/" +
                      scheduledend.charAt(0) +
                      scheduledend.charAt(1) +
                      scheduledend.charAt(2) +
                      scheduledend.charAt(3);
                    setselectedMeetingMD(icici_meetingdate_formatted);
                    setselectedMeetingMT(icici_meetingtype_formatted);
                    setselectedMeetingAP(description);
                    setselectedMeetingFPR(icici_fpr);
                    setselectedMeetingTD(scheduledend_formatted);
                    setselectedMeetingAG(subject);
                    setselectedMeetingMM(icici_modeofmeeting_formatted);
                    setselectedMeetingMMID(activityid);
                    setselectedMeetingACID(activityidTask);
                  }
                },
                function (error) {}
              );
            }
          },
          function (error) {}
        );
      },
      function (error) {}
    );

    setselectedMeetingName(name);
    setselectedMeetingtime(time);
    setselectedMeetingComp(comp);
    setselectedMeetingAPID(appointmentID);

    openPanel();
  }

  function meetingPopupNav(
    id: number,
    guid: string,
    name: string,
    time: string,
    comp: string,
    appointmentID: string
  ) {
    switch (id) {
      case 0 /* Close action item */:
        var entity: EmailParameters = {};
        entity.statecode = 1;
        dismissPanel();
        Xrm.WebApi.online
          .updateRecord("task", guid, entity)
          .then(
            function success(result) {
              var updatedEntityId = result.id;
            },
            function (error) {}
          )
          .then(function (success) {
            getSelectedMeetingDetails(name, time, comp, appointmentID);
          });
        break;
      case 1 /*Edit action item*/:
        dismissPanel();
        Xrm.Navigation.navigateTo(
          { pageType: "entityrecord", entityName: "task", entityId: guid },
          { target: 2, position: 2 }
        ).then(function (success) {
          getSelectedMeetingDetails(name, time, comp, appointmentID);
        });
        break;

      case 2 /*Edit meeting minute*/:
        dismissPanel();
        Xrm.Navigation.navigateTo(
          {
            pageType: "entityrecord",
            entityName: "icici_meetingminutes",
            entityId: guid,
          },
          { target: 2, position: 2 }
        ).then(function (success) {
          getSelectedMeetingDetails(name, time, comp, appointmentID);
        });
        break;

      case 3 /*Create new meeting minute */:
        dismissPanel();
        var parameters: EmailParameters = {};

        parameters["appointment"] = [{ id: guid, entityType: "appointment" }];

        Xrm.Navigation.navigateTo(
          {
            pageType: "entityrecord",
            entityName: "icici_meetingminutes",
            data: parameters,
          },
          { target: 2, position: 2 } // Open in modal
        ).then(function (success) {
          getSelectedMeetingDetails(name, time, comp, appointmentID);
        });

        break;

      default:
        break;
    }
  }

  const iconClass = mergeStyles({
    fontSize: 16,

    height: 16,

    width: 16,

    margin: "15px 5px",
  });

  const onRenderNavigationContent: IRenderFunction<IPanelProps> =
    React.useCallback(
      (props, defaultRender) => (
        <>
          <a style={{ paddingTop: 11, fontSize: 20 }}>Meeting Details</a>
          <DefaultButton
            style={{ borderWidth: 0, marginTop: 4, paddingLeft: 41 }}
            onClick={() => {
              meetingPopupNav(
                3,
                selectedMeetingAPID,
                selectedMeetingName,
                selectedMeetingtime,
                selectedMeetingComp,
                selectedMeetingAPID
              );
            }}
          >
            <FontIcon aria-label="Add" iconName="Add" className={iconClass} />
          </DefaultButton>
          {
            // This custom navigation still renders the close button (defaultRender).

            // If you don't use defaultRender, be sure to provide some other way to close the panel.

            defaultRender!(props)
          }
        </>
      ),

      []
    );

  return (
    <div className="RMWBFrontControl">
      <div className="meetingDetails">
        <Panel
          className="panelmeetingDetails"
          onRenderNavigationContent={onRenderNavigationContent}
          isOpen={isOpen}
          onDismiss={dismissPanel}
          headerText="&nbsp;"
          closeButtonAriaLabel="Close"
          // Stretch panel content to fill the available height so the footer is positioned
          // at the bottom of the page
          isFooterAtBottom={false}
        >
          <div className="bordergraybg">
            <Stack>
              <Stack
                className="padding0px"
                horizontal
                disableShrink
                tokens={horizontalGapStackTokens}
              >
                <span>
                  <p className="font-weight-bold font-size11">
                    <Icon iconName="Calendar" className="iconfontsize"></Icon>
                    &nbsp;&nbsp;
                    <a style={{ marginTop: 4, float: "right" }}>
                      {selectedMeetingtime}
                    </a>
                  </p>
                </span>
              </Stack>
            </Stack>

            <Stack
              className="row padding0px"
              style={{ marginLeft: 0, marginTop: 12 }}
            >
              <Stack className="padding0px" tokens={horizontalGapStackTokens}>
                <h1 className="padding0px">Meeting Subject</h1>
                <span className="padding0px" style={{ marginTop: -2 }}>
                  {selectedMeetingName}
                </span>
              </Stack>
            </Stack>

            <Stack className="mt10px">
              <h1 className="mt10px">Meeting Details</h1>
              <Stack className="bordered">
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Company Name</span>
                  <span className="font-weight-bold fontsize11 col-6">
                    {selectedMeetingComp}
                  </span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Agenda</span>
                  <span className="fontsize11 col-6">{selectedMeetingAG}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Meeting Mode</span>
                  <span className="fontsize11 col-6">{selectedMeetingMM}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Client Attendees</span>
                  <span className="font-weight-bold fontsize11 col-6 wordwrap-breakword">
                    {selectedMeetingCA}
                  </span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Bank Attendees</span>
                  <span className="fontsize11 col-6 wordwrap-breakword">
                    {selectedMeetingBA}
                  </span>
                </Stack>
              </Stack>
            </Stack>

            <Stack className="mt10px">
              <h1 className="mt10px">Previous MOM Actionable</h1>
              <Stack className="bordered">
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Meeting Date</span>
                  <span className="fontsize11 col-6">{selectedMeetingMD}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Meeting Type</span>
                  <span className="fontsize11 col-6">{selectedMeetingMT}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Actionable Point</span>
                  <span className="fontsize11 col-6">{selectedMeetingAP}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">FPR</span>
                  <span className="fontsize11 col-6">{selectedMeetingFPR}</span>
                </Stack>
                <Stack
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6">Target Date</span>
                  <span className="fontsize11 col-6">{selectedMeetingTD}</span>
                </Stack>

                <Separator className="padding0px" />
                <Stack
                  className="padding0px"
                  horizontal
                  disableShrink
                  tokens={horizontalGapStackTokens}
                >
                  <span className="fontsize11 col-6 textcenter padding0px">
                    <DefaultButton
                      className="textcenter padding0px"
                      style={{
                        fontWeight: "bolder",
                        color: "#446e92",
                        borderWidth: 0,
                      }}
                      onClick={() => {
                        meetingPopupNav(
                          0,
                          selectedMeetingACID,
                          selectedMeetingName,
                          selectedMeetingtime,
                          selectedMeetingComp,
                          selectedMeetingAPID
                        );
                      }}
                    >
                      Close
                    </DefaultButton>
                  </span>
                  <Separator vertical className="padding0px" />
                  <span className="fontsize11 col-6 textcenter padding0px">
                    <DefaultButton
                      className="textcenter padding0px"
                      style={{
                        fontWeight: "bolder",
                        color: "#446e92",
                        borderWidth: 0,
                      }}
                      onClick={() => {
                        meetingPopupNav(
                          1,
                          selectedMeetingACID,
                          selectedMeetingName,
                          selectedMeetingtime,
                          selectedMeetingComp,
                          selectedMeetingAPID
                        );
                      }}
                    >
                      Edit
                    </DefaultButton>
                  </span>
                </Stack>
              </Stack>
            </Stack>

            <Stack className="centercontent mt10px">
              <h1 className="mt10px">Other Pending Items</h1>
              <div className="rows">
                <Stack className="col-4 border-right border-bottom">
                  <Stack className="iconWrapper">
                    <Icon
                      iconName="BufferTimeBoth"
                      className="iconfontsize"
                    ></Icon>
                    {
                      <p className="notification">
                        <span style={{ marginTop: 0 }}>1</span>
                      </p>
                    }
                  </Stack>
                  <Label className="iconLbel">Pending SR</Label>
                </Stack>
                <Stack className="col-4 border-right border-bottom">
                  <Stack className="iconWrapper">
                    <Icon iconName="Onboarding" className="iconfontsize"></Icon>
                    {
                      <p className="notification">
                        <span style={{ marginTop: 0 }}>3</span>
                      </p>
                    }
                  </Stack>
                  <Label className="iconLbel">Onboardings</Label>
                </Stack>
                <Stack className="col-4 border-bottom">
                  <Stack className="iconWrapper">
                    <Icon iconName="AlertSolid" className="iconfontsize"></Icon>
                    {
                      <p className="notification">
                        <span style={{ marginTop: 0 }}>3</span>
                      </p>
                    }
                  </Stack>
                  <Label className="iconLbel">Compliance Alert</Label>
                </Stack>
              </div>
              <div className="row">
                <Stack className="col-4 border-right">
                  <Stack className="iconWrapper">
                    <Icon iconName="NotePinned" className="iconfontsize"></Icon>
                    {
                      <p className="notification">
                        <span style={{ marginTop: 0 }}>5</span>
                      </p>
                    }
                  </Stack>
                  <Label className="iconLbel">Briefing note</Label>
                </Stack>
              </div>
            </Stack>

            <Stack className="row plpr10px">
              <Stack tokens={horizontalGapStackTokens}>
                <h1 className="">Offers</h1>
              </Stack>

              <Stack
                className="offerbox"
                horizontal
                disableShrink
                tokens={horizontalGapStackTokens}
              >
                <span>
                  <Image
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAMAAABOo35HAAAANlBMVEVHcEznehbqfBrmeRbnehbzgx7nehboexfoehfnehf////zvo331rjrlkjvqWrphy776dn99e56Ua6mAAAACnRSTlMA3Sn/7wzCS3SZog4aowAAC2dJREFUeAHsleuWqjgUhHMliQEC7/+yB+WgXJVbdgXb+jFretplV76pqs2SkBbGWOtclnHOlVJSNv9o/jXLnLPWGKHRDlOQMNZlvIHzSYpnzhqB9guSvmNaQWnE7I7sb8VMWMflAXFn/0TGmkBtz9N8xr48YuIkUD1gX5owc6x6y5U06JedT+rUSI0C9k28opL6Kl4iPqlW3F18v7TJaEi1yi58H8lC9ZK6aLxoQ9WPF/rlW0Xcv6H4pXBpy3GoHrjsVcZLW/KpmkpdAlcSqC6CC13AvrhF03grkxCqB650p14AL+CSMoGmMivt0GDm5RKcrlR2fSqV2nSl2MCXkupiqg18KZ0upnYD55TIXUw/Vq1SCNcVYtUKHi5t0Qi2CHsW0z6CUyHPolHo12+VQlXxKss+FGbnr1bBTogqXq+CneireKkrOBbtVbzmXL1EOVz6onP1UkZGS3D0W4+LE838dae9L5qZN+hnXojWpc/gUNGP4hexik7rq1hFpuXQrztb7scqBVpfyCoara9kFYnWl237SxFW/mtZRaD1xaxOp2XQ74kr82OFoSUU+jGxpcRZrDRHvyW+uD6JVYZ+CYWyc2g59Dto5M5gZdGvoJI9zurrD+FLh0/i9x/Cl46exL8x7p0OjvwfGfdO7jdYG2R+g7VeB2brTw1Wq2wvK4t2jpD9DdYG7ZotzdG2MeJ6ByyHdo2S+5Vwg8yvhOu1uYh/toR3bSyiQPvFSmwqYYa2ixXfAsuCzRZVXRVIA3ZDsBSWVbjdhaSl9GXW3T9geaQFd5l1zx+wcqiHtRsPX/cUYGXrWBk0qyRgSbMKFkezSgMWX8PKolElAkvaz6w0PliJwOL6CsFKBNbnaGmFtpgOLKUvEKxUYH2KVhLBSgbWh2glEaxkYH2IVgKnUCYEi79jZdDuWiUDS5rkg5UQrCz5YMnyAatE27hrOVoZ2lqnPJFgvYmWiPlXfVX59Z8ufBHrqzdKLMByMVnFW6HHwkWj5RZgqWiopLzF2uzQXoNbLONKk897uMWi9Z/VLcSybujnvYpEq2NVRXOekc+7LG5RaHWsbkU864J43huVMWg9WZURnc9NPI8LKwYtElaS0857JFo0rOYmPnIL7zqZFhWrmR6q+LBetPzyZ0JRep/f5X1ZhOUPeipWUtG3cEBrHkIo8+o2VJWXC58lYzXtIUEL+7RmXhj8GNQTmA+bvul0OUALe2+cvL7IF0j9X7liwpaO1biHNC180hpvVlm9RfWI1xiLJ2M17iFRC+8qfD564odULaWrzH1B5HnYQ04Ha6J1qB64UBZ5n5XAoSqq1ayaLlJFaSzRg2VhrPwMkTxfBugxNm0PVoZiNa5gN0NFYlXMXqy0wqAKwwTVPjx/5ZerGABOlX7CMimwqgY3srylRcuAJ2vIaoDqLSwILYudrAGrfPz+tzcSQOs1WpDJ6m17PYqVLPJ3rBArrzpWAsGqt+B10fvvofR5ffskT+5XACert0l1r1SfIrU0cfHVjZajZxXquQHy1UpUQ8Ikcv9hcXpY+QyrYj0qwGzxlpWmZ1XM7JXfgqpRQexZP2AZeljVZHtCtZHVrSL2bED7Xk7KtJ0V+cZb0L5X43TsYUUdrXbhM2pWxSQce1hRr1b2gKWoYeXjbOS7WFEfxDsrQc0qjINV7mN1qwOpb4E4huUoWKHeCYt44g3iGOajt/q9rIh7aBHHsAtS3f64P1jdNxDJAY7h8xb69uf9wSK+h/dzyIlhlaOX7g8W8WjdYSliWH7YofIAqy6cNFKMaWJWz33Ph+x2iXbhNRPUsKphKqojsCpS54IZalj1YG/CEVbE59DQw+oe2u57cQjWjRiWjfG15bBctZ+BFdpPngUr+OFZrc6/lDYKrCmB1xKH4Tv9WbDyye9Op2WZiwBrZrTD85dxYM1s3+nr76LAqqfOi8iwZrbv9PV3LIsAK39nvB5k7Ris+t3/oPzsZ2VRYIVJD8vosCY7WYXzYfEIsBrrvq+y77sDWcy/cZP6sxRGf/P8R/FIsN4oH8AqDsE6vWmpweqK59sf6yOwPDEsRQ2rHKYiPwIrQtfeSNHD6or3f5wPLXzx7bBk99J29Q8tPK1xxchZPc9h26EjyaqInQNgdXjqe7TCkYGn3fcGFn0Nn8WryqI8dAxp9x2yWfIQoJ5qYt8QWPlJsHJyWJweVnkSLOIWSo6AdVIPqVsIguVPgUV9CxtYGQBWOAVWoLadQWCdMvHU836H5RCwzogWebCkw8A6IVr0wWpgWQisw9Gq6YMlLQjW4YNIfgofsAwGlqwOsaoQlg0MVnEIVoGBJUCwDhURUUIpBdMoWKHezarGONaMKRStcjesEuJXMcY4CtbuImJKKHkDK4PBCvsuIuQSNsoaWA4Ga+dFhFzCRq6BZXGwdhURVEIpbQPLAGHJ6jIllNI0sAQSVtjKqkaVUErRwGIKSctfpYRS3VkBz+Fd1UVK+DiG0HMot15EXAkfxxB7DuW2IuJK2B5D8DlsNr5ev+4B6PN+DBnTWFgbooUMltQPWIyDaa2NVo00yVtW4IVfHy1osNp9hy+8DCthIRfr/74zJsCwZL6KVQ71KP7DYgoMq1wFq0RaVB0rloFhhfRbmD1hoUdLVitYVVCH3WQxZtCw8uQnyzxhafRo+RWwPNKg0iyZ0Uper8lKYLRS12uyGBNoM6lL9GAxjnaTtnifFXNoO2nLDWAZtJ20ZQawmIKaCf6zAs6eGrIC97C4fVaBszdsIbqHicMatRDcw7RhjVsI7mHasMYtBPcwJA1r0kJsD5NO1rSF6HuYsOwMLIE2larEDCyWoV2lqWyOFXbi05WZhaWRE5+slJ6F9Zv4Obl5VsCJD/6zAsaaWICFm/ji9lkFxFm2xAo38enCMouwYNFKFtZysHDRCitgQTbrTbCY5iBa9UdWNcIWf8OKMQuC5T/C8ghb9i0srUC0qg+sKoQppVmS0Sre06og8/4+WMBoSb+8W/WuDv4rr1x3U9lhKGzn5ObTVt28/8vugdGUYVNEZnJZTvIJIcSv+NPycvbnXbBw0Vr4urF3dln/Ar3nXbCAB3Hjgj6BG/w2WNBo6ZL1PlgL4GhpkcUprihgZe3P4h/gO0KSLPJQWR87WZgreMOnuSIDlbU/h9+4Z5hEWSRQWx8agiWprshZFbaArqxLlkURKuu/78/L/5fPL+ALYrordMfD8UdcOWzHwzFHZKE7Howcc0WO0S/Gwe6gLAroJ+MIR11NvIhy3NW0i3h8CSdexBNLeCWi340gnnNFzqNf3h5/0hWRsei3t8aa07Lmq61w3hWRoF/fFslxNVlteZcla6rayims6Wor5LoiiugZWhHzXU1T8lLC1SQln1vuP7YYPUl9uJCrGU5i/iHc2UIPU9tVgUN4J6DHqUtRV0QRPU9NYllXQ9sq7mpgWxVcEQl6qjpIDVeD2qrkakhb1VwNaKuiq+Favkq3D2qrsquhbFV3RRTQM5Yi1He12LLoMUtgm7giMoyeNB82bVwROY+eNRfvWrlabAl62jykoSvq/Cg2OIOP9Fvzrap9j+m0uHyzat/TZ3E1rqs7/a0iYgU3eltFzAr+0NVVbH4F/yUwWkEqDFzBjV56Htbsj/QQLg2xWtEfLiWxWtF9Fhl7BJ9w0aKVvMLCj2A/u6hqA+9o3EWvbAN3aLuLem7gr0RFulhhWT2ipult1FlWCnX1oWrVBV5G7kbVjQC8jF53rWvS1aGqK0aal5cVg576NK5tvHzoqqqeaRavnkO1I9T3ZaXPpmrvayhTmy+uYYrHM7Vioi8aMOvjED31ChcKCVtE9X770jAxbyVZxk7UE0vE5ETGvEwSqF8wV2Wc4MzyVdNceXqBMyHEKOI9M1u7yFu+lp/ei8QYgtERpr+n6ATYBTzGhAAAAABJRU5ErkJggg=="
                    width={32}
                  />
                </span>
                <span className="textwhite fontsize11" style={{ marginTop: 6 }}>
                  Get personal loan up to 10 Lac
                </span>
              </Stack>
            </Stack>

            <div>
              {/* <PrimaryButton onClick={dismissPanel} styles={buttonStyles}>
           Join Now
        </PrimaryButton> */}
              <div className="clear"></div>
              <div className="clear"></div>
              <DefaultButton
                style={{ marginTop: 22 }}
                onClick={() => {
                  meetingPopupNav(
                    2,
                    selectedMeetingMMID,
                    selectedMeetingName,
                    selectedMeetingtime,
                    selectedMeetingComp,
                    selectedMeetingAPID
                  );
                }}
              >
                Edit
              </DefaultButton>
            </div>
          </div>
        </Panel>
      </div>
      <div>
        <div>
          <Pivot
            aria-label="CRM Tabs"
            linkFormat="tabs"
            className="pivotControl "
          >
            <PivotItem headerText="Numbers" itemIcon="Coupon">
              <div className="Summary">
                <Stack className="pivotControlItems">
                  <div className="pivot__Items">
                    <div className="incomheader">
                      <Label className="fontB col6">
                        Header-Dailt Activity (In Million)
                      </Label>
                      <Label
                        className="fontB fl col3"
                        style={{ fontSize: "10px", paddingTop: "10px" }}
                      >
                        07/02/2022
                      </Label>
                      <Link href="#" className="viewdetails col3 linkcolor">
                        View Details
                      </Link>
                    </div>
                    <div className="clear"></div>
                    <Stack className="carousel__Items_Card_numbers">
                      <Stack className="row">
                        <Stack className="column4 textcenter">
                          <Label className="fontB normalFont">
                            CA Balances
                          </Label>
                          <Label className="normalFont">20.7</Label>
                        </Stack>
                        <Stack className="column4 borderLeft textcenter">
                          <Label className="fontB normalFont">
                            FD Balances
                          </Label>
                          <Label className="normalFont">45</Label>
                        </Stack>
                        <Stack className="column4 borderLeft textcenter">
                          <Label className="fontB normalFont">
                            CC Utilisation
                          </Label>
                          <Label className="normalFont">45.1</Label>
                        </Stack>
                      </Stack>

                      <div className="clear"></div>
                      <br></br>
                      <Stack className="row">
                        <Stack className="column4 textcenter">
                          <Label className="fontB normalFont">
                            LC Issyance
                          </Label>
                          <Label className="normalFont">43</Label>
                        </Stack>
                        <Stack className="column4 borderLeft textcenter">
                          <Label className="fontB normalFont">
                            LC Outstanding
                          </Label>
                          <Label className="normalFont">45</Label>
                        </Stack>
                        <Stack className="column4 borderLeft textcenter">
                          <Label className="fontB normalFont">
                            OD Utilisation
                          </Label>
                          <Label className="normalFont">111.1</Label>
                        </Stack>
                      </Stack>
                    </Stack>
                  </div>
                </Stack>
              </div>
            </PivotItem>
            <PivotItem
              headerText="Appointments"
              itemCount={cardParam.status ? cardParam.value : 0}
              itemIcon="CalendarWorkWeek"
            >
              <div>
                <section className="carousel" aria-label="Appointment">
                  <ol className="carousel__viewport">
                    {cardParam.multiData.map((result, i) => {
                      return (
                        <li
                          id={result.id}
                          tabIndex={0}
                          className="carousel__slide"
                        >
                          <div className="carousel__snapper"></div>

                          <Stack className="carousel__Items">
                            <Stack className="carousel__Items_Main">
                              <div>
                                <Label className="fl fontB">
                                  {result.heading}
                                </Label>
                                <DefaultButton
                                  className="fr carousel__Items_Card_button_edit"
                                  style={{
                                    visibility: cardParam.status
                                      ? "visible"
                                      : "hidden",
                                  }}
                                  onClick={() =>
                                    openViews(4, result.appointmentID)
                                  }
                                >
                                  <Icon iconName="Edit"></Icon>
                                </DefaultButton>
                              </div>
                              <div>
                                <Label className="fl fontB">
                                  <Icon
                                    iconName="calendar"
                                    style={{
                                      visibility: cardParam.status
                                        ? "visible"
                                        : "hidden",
                                    }}
                                  ></Icon>
                                  &nbsp;
                                  {result.startTime.length > 0
                                    ? result.startTime + " - " + result.endTime
                                    : ""}
                                </Label>
                              </div>
                              <div className="clear"></div>

                              <Stack className="carousel__Items_Card">
                                <div>
                                  <DefaultButton
                                    onClick={() => {
                                      getSelectedMeetingDetails(
                                        result.heading,
                                        result.date +
                                          " | " +
                                          result.startTime +
                                          " - " +
                                          result.endTime,
                                        result.accountName,
                                        result.appointmentID
                                      );
                                    }}
                                    style={{
                                      color: "#466f93",
                                      fontSize: 13.5,
                                      textAlign: "left",
                                      height: 25,
                                      width: 250,
                                      background: "transparent",
                                    }}
                                    className="fl fontB"
                                  >
                                    {result.accountName}
                                  </DefaultButton>
                                  <img
                                    className="fr"
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAaCAMAAABfE/ZQAAABdFBMVEVHcEzKFwvKFwvKFwvJFwvLFwzMDQDKGAvJGAvKFwvKGAvGAADKFgvLFQnJDQDKFQvKGAzJFwvJFwvJFQnLGAvKFQjJFwvKFwvJGAvJFgrKGAvKFwrVAADJFgvKFQrMFgfTCwDJFwvKFwzKGAzKGAvKFgvLGAzLFgnMEwXKFgrLFgrKGArMFgrKGAvKFQrKFwvKFgrKGAvLFgrKFwzKFAfJFwvJGAzKFwrMEwbJFwzMGAzLFwzJFwvKFwvKFwzJFwvJFgrYFADKFgrKFgvKFwu/AADKFQvJFgrKFwvIFgDLFwnKFwzVDgDGAADJFwvLGAvKFgvKFwvKFwvHFwnKFQfLFwrJGAzKGAvLFwnKEgbIFwvIAADMAADLFwvKFgvKGAvJFwrJFArLFQjLFwvJFwvJGAvJFwzKFwvKFwvJGAvLFQrKFgvLFgnODADLFQnPFQXJFArKFgrJFwnREgnKGAzKGArJFwvLFgzKFgvKFwzLGAzMFgmE4mB6AAAAfHRSTlMA9er08vMU+e7m6hJcqhOnv+32bfg+vuWKaNVlBnXKRhfk3ert5+5TN2aArZ/4fPHHzmfxTfzufCjyQSzv+Nre3A1pjKcEMK7hF5JXEgng4HN4/jdIYsL3iCt5Dgq5wrjiNIXl6eLz5+zjYrY7FcMwTJVaHP//////////p0z24gAAAAFiS0dEAIgFHUgAAAAJcEhZcwAADsQAAA7EAZUrDhsAAADzSURBVBiVVZBVW0JhEISH5lio2AU2BnYX2ILdgiJ2t4P55/34OD6uc7E77z57sTuAUlVNAFL+xoaWf4M61vokV5MOyZUu2loFN9eT/cDB4SvuY4qLS8nh7f2j7xM8XO4B5UUkd5LkDV6ubHGUKeTuNc+fAIMX6xVpHidP74BbcszBjM4egWfSUmiy9RhI8E/GFrAh+KsHm27Bn21YCwpOlaA9JZh25JvOomsWPO/a9Hbp9oYclzYTfZ2Z/Wyr5ujogKofuYA3vbAQWQqpVpCnnu9Qg5XZRXVHk1OnM7hK99Q0jW6nGdfQTHhucn5EBLj8a34AiBZiEPLSVLsAAAAASUVORK5CYII="
                                    style={{
                                      visibility: cardParam.status
                                        ? "visible"
                                        : "hidden",
                                      height: 20,
                                    }}
                                  ></img>
                                </div>
                                <div
                                  style={{
                                    visibility: cardParam.status
                                      ? "visible"
                                      : "hidden",
                                    marginTop: -13,
                                  }}
                                >
                                  <Stack
                                    horizontal
                                    disableShrink
                                    tokens={horizontalGapStackTokens}
                                  >
                                    <span className="fontsize11">
                                      <DefaultButton
                                        onClick={() => {
                                          getSelectedMeetingDetails(
                                            result.heading,
                                            result.startTime +
                                              " - " +
                                              result.endTime,
                                            result.accountName,
                                            result.appointmentID
                                          );
                                        }}
                                        style={{
                                          width: 115,
                                          textAlign: "left",
                                          fontSize: 11,
                                          color: "#949393ec",
                                          background: "transparent",
                                        }}
                                        className="fl "
                                      >
                                        Mode of Meeting
                                      </DefaultButton>
                                    </span>
                                    <span className="fontsize11 font-weight-bold mt10px">
                                      {result.modeOfMeeting}
                                    </span>
                                  </Stack>

                                  <Stack
                                    horizontal
                                    disableShrink
                                    tokens={horizontalGapStackTokens}
                                    style={{ paddingTop: 0, marginTop: -22 }}
                                  >
                                    <span className="fontsize11">
                                      <DefaultButton
                                        onClick={() => {
                                          getSelectedMeetingDetails(
                                            result.heading,
                                            result.startTime +
                                              " - " +
                                              result.endTime,
                                            result.accountName,
                                            result.appointmentID
                                          );
                                        }}
                                        style={{
                                          width: 115,
                                          textAlign: "left",
                                          fontSize: 11,
                                          color: "#949393ec",
                                          background: "transparent",
                                        }}
                                        className="fl "
                                      >
                                        Location
                                      </DefaultButton>
                                    </span>
                                    <span className="fontsize11 font-weight-bold mt10px">
                                      {result.location}
                                    </span>
                                  </Stack>
                                </div>
                              </Stack>
                            </Stack>
                          </Stack>
                          <div className="carouseldot_main">
                            <div className="carouseldot_container">
                              <div
                                className="carouseldot_activeCarousel"
                                style={{ marginLeft: 6 + 14 * i }}
                              ></div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ol>

                  <aside className="carousel__navigation">
                    <ol className="carousel__navigation-list">
                      {cardParam.multiData.map((result) => {
                        return (
                          <li className="carousel__navigation-item">
                            <span className="carousel__navigation-button"></span>
                          </li>
                        );
                      })}
                    </ol>
                  </aside>
                </section>
                <Stack>
                  <div className="viewAllcontainer">
                    <a
                      onClick={() => openViews(1, "")}
                      className="fl fontB "
                      style={{
                        fontSize: 12,
                        color: "#053c6d",
                        opacity: 1,
                        textDecoration: "none",
                      }}
                    >
                      + Add New
                    </a>

                    <a
                      onClick={() => openViews(3, cardParam.appointmentView)}
                      className="fr fontB"
                      style={{
                        fontSize: 12,
                        color: "#053c6d",
                        opacity: 1,
                        textDecoration: "none",
                      }}
                    >
                      View all
                    </a>
                  </div>
                </Stack>
              </div>
            </PivotItem>

            <PivotItem headerText="Leads" itemIcon="PartyLeader">
              <Stack className="pivotControlItems offerSize">
                <p>Leads</p>
              </Stack>
            </PivotItem>
            <PivotItem headerText="Deals" itemIcon="Ringer" itemCount={1}>
              <Stack className="pivotControlItems offerSize">
                <p>Deals</p>
              </Stack>
            </PivotItem>
            <PivotItem
              headerText=" &nbsp;&nbsp;&nbsp;&nbsp;Birthday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
              itemIcon="BirthdayCake"
            >
              <div>
                <section className="carousel" aria-label="Appointment">
                  <ol className="carousel__viewport">
                    {cardParam.birthDayArray.map((result, i) => {
                      return (
                        <li
                          id={result.id}
                          tabIndex={0}
                          className="carousel__slide"
                        >
                          <div className="carousel__snapper"></div>

                          <Stack
                            className="carousel__Items"
                            style={{ display: "flex" }}
                          >
                            <Stack className="carousel__Items_Main">
                              <div style={{ height: 25 }}>
                                <Label className="fl fontB">
                                  {result.name}
                                </Label>
                              </div>
                              <div>
                                <Label className="fl fontN">
                                  Click below image to send Birthday wishes
                                </Label>
                              </div>
                              <div className="clear"></div>

                              <Stack>
                                <div>
                                  {/* <DefaultButton
                                    style={{
                                      height: 100,
                                      width: 145,
                                      borderRadius: 0,
                                    }}
                                  >
                                    <img
                                      src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/4QBPRXhpZgAASUkqAAgAAAABAA4BAgAtAAAAGgAAAAAAAABCaXJ0aGRheSBjYWtlIHdpdGggZ29sZCBoYXBweSBiaXJ0aGRheSBiYW5uZXL/4QVOaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pgo8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIj4KCTxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CgkJPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczpJcHRjNHhtcENvcmU9Imh0dHA6Ly9pcHRjLm9yZy9zdGQvSXB0YzR4bXBDb3JlLzEuMC94bWxucy8iICAgeG1sbnM6R2V0dHlJbWFnZXNHSUZUPSJodHRwOi8veG1wLmdldHR5aW1hZ2VzLmNvbS9naWZ0LzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGx1cz0iaHR0cDovL25zLnVzZXBsdXMub3JnL2xkZi94bXAvMS4wLyIgIHhtbG5zOmlwdGNFeHQ9Imh0dHA6Ly9pcHRjLm9yZy9zdGQvSXB0YzR4bXBFeHQvMjAwOC0wMi0yOS8iIHhtbG5zOnhtcFJpZ2h0cz0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3JpZ2h0cy8iIHBob3Rvc2hvcDpDcmVkaXQ9IkdldHR5IEltYWdlcy9pU3RvY2twaG90byIgR2V0dHlJbWFnZXNHSUZUOkFzc2V0SUQ9IjEyMDEyMDIzMTIiIHhtcFJpZ2h0czpXZWJTdGF0ZW1lbnQ9Imh0dHBzOi8vd3d3LmlzdG9ja3Bob3RvLmNvbS9sZWdhbC9saWNlbnNlLWFncmVlbWVudD91dG1fbWVkaXVtPW9yZ2FuaWMmYW1wO3V0bV9zb3VyY2U9Z29vZ2xlJmFtcDt1dG1fY2FtcGFpZ249aXB0Y3VybCIgPgo8ZGM6Y3JlYXRvcj48cmRmOlNlcT48cmRmOmxpPlJ1dGhCbGFjazwvcmRmOmxpPjwvcmRmOlNlcT48L2RjOmNyZWF0b3I+PGRjOmRlc2NyaXB0aW9uPjxyZGY6QWx0PjxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+QmlydGhkYXkgY2FrZSB3aXRoIGdvbGQgaGFwcHkgYmlydGhkYXkgYmFubmVyPC9yZGY6bGk+PC9yZGY6QWx0PjwvZGM6ZGVzY3JpcHRpb24+CjxwbHVzOkxpY2Vuc29yPjxyZGY6U2VxPjxyZGY6bGkgcmRmOnBhcnNlVHlwZT0nUmVzb3VyY2UnPjxwbHVzOkxpY2Vuc29yVVJMPmh0dHBzOi8vd3d3LmlzdG9ja3Bob3RvLmNvbS9waG90by9saWNlbnNlLWdtMTIwMTIwMjMxMi0/dXRtX21lZGl1bT1vcmdhbmljJmFtcDt1dG1fc291cmNlPWdvb2dsZSZhbXA7dXRtX2NhbXBhaWduPWlwdGN1cmw8L3BsdXM6TGljZW5zb3JVUkw+PC9yZGY6bGk+PC9yZGY6U2VxPjwvcGx1czpMaWNlbnNvcj4KCQk8L3JkZjpEZXNjcmlwdGlvbj4KCTwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9InciPz4K/+0AelBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAABdHAJQAAlSdXRoQmxhY2scAngALUJpcnRoZGF5IGNha2Ugd2l0aCBnb2xkIGhhcHB5IGJpcnRoZGF5IGJhbm5lchwCbgAYR2V0dHkgSW1hZ2VzL2lTdG9ja3Bob3RvAP/bAEMACgcHCAcGCggICAsKCgsOGBAODQ0OHRUWERgjHyUkIh8iISYrNy8mKTQpISIwQTE0OTs+Pj4lLkRJQzxINz0+O//bAEMBCgsLDg0OHBAQHDsoIig7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O//CABEIAZgCZAMBEQACEQEDEQH/xAAaAAEBAAMBAQAAAAAAAAAAAAAAAQIDBAUG/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAAH1unlqgWUUALYFC0AAFAAAAAKAQAAAAEAQSgABEAAAlgAEIgEqBBAQzlqgWUUALYFWgAAFAABQAAAAAQAAAgCCUABEAAAlgAEIgEBKJAQzlqhFUUALYFWgAAoAAKAAAAAAAAQAgCCAUAQCACkioAQEQQVCIIDOaoBZRQChUUqgACgAFBSCVZSAAAAAEAAILBAAAggApCyAAhEEBKiCAzlLSiUUAoWwKoAFAABZVgAAAAAAAAgAIKBIAAkAFICiQEBEEJRICAzlLSiUUAoloKoAoAAKACkBQCFBCkAABAASiCAAIBBSCKgBARBKiCAgM5qgFgtAKFsUKQpKAoAoBSFAAAAABAACACoAkAAQQACiQEBEEJRIAQzmqAWUUAoloKAUAKKAAUACW1EAAAAAgAICUCCAIBBSAsEIAkIKgSAgM5qgFgtAKJaCgoCgUAAoAAKpAIAAAAsQAQEpIoQBCklIUSAECQgJRICAzmqAWC0FAlpQCgKKAACgAoUAlllggACghYEEAqSKEAQCAUCQEIggqBICAzlqgWUUFALLQCnJjp1XOWp5/Hr27xnvPFjeHm7+h6/NbOHn0vHrNTs7ctGNYY1lqdfXkoYRjNbNYpFBCgQIIASiCABAJQJAQESCoEgIDOUtBZRQUAstANMvneL2el6OO3tx8jxez0enPo9Pn8Dy+n2csemen0cfH8np7dvP53firN25gujLdHo+vzePx7dmN9/r80sEQFAEQQAVAggCASgSAhEEBLBAQGc0KCxVFALFUAal4vD6+zvz6O/Dw/H6/V6Y5+3KeXvz512J3e7y+R4/T6G3P15PN1pu6Z4tNHPe3F3WZazt26vR5wAIAARBBQgQCBAJQJAQJCCoEgIRNk1VAstBQWC0ApivmeD2U0L1XPX2x5MvqnJZu476fRx8/h26bJDTDF3ahGrw7zv476OmervxayAAIACBIBQiAQAJKBICBIQVEEBCJsm6AWWgoLKKAVR5Pi9e+yd+XN5+3TuYYvQaY6dTCNMu/eW89nTHleXv2+nhr59O3rzvTHj+L0+jub/T55QAAgABEEFCIAIEEoELEhEEFRBCAlmzOi0FlpQCyigS5EryvH6u7U2ejh5nk9O+ujU4d4Vp5dOuM8Xq7c93o4VfJ8fo7u3Po7ck21jzPJ36Wuv1eeWQAAEABAglARAIAggFRICJBUQQgImybFBZaUFEop5Pn77PP2x06evLx89O8283Dq9UYx6O8SuRdXLd659Ttx5s62p4/Ht6dz0d8bunJZ5vn7OXRHX35Z9+XF5e/b3557wAIACIFQEQCAIJSFRIEhBUQQgJZszugsFpQCy0Hk+L1dmnlL041ujnl7941dcaufTTmw9jedHTpeGO718NOs8fh9OysdTz7fR1XKdvt83g+b0dUujlrsueTrn0a2bxt7cgBACAIqCFRAIECpCokBEgqIIQJK2Z3QUS0oKqKDyfF6+utEXRz1zy+hrLecV6NznznozvDrzw8/Xp9XLTZp8vbr1G5t9HDyOXbq8++U6NTZZ53Hp3dMdfTOm3q78JYAUkAIEEAqIBAgEFRICJBUQQgSGyboLKKULYFB5Xi9fScS9EuMYL37xzy9FnV6eHBw6dWd6emNnPfn51jHfvOrnrr7Y3enhieZ4/TtOnrnyuW/a9HDk4ddu50ejgoQABICBFIgqIBAEgJRICJCUSAgSGyboKJaVUUFB5Xj9Xb0nHrO3j1583ZL0azy6dOHZ6ePHy31TWrpznDr1ejlxS3h01Zvf2xt9PDjxrVx7dNmvF419FnzeXT1PRz2+jgBKABICAJKQoRBAkFIlEgIkJRICBIZzdKCy0qiwKDxvJ6ujOuiHScWLbco9L1efy/N39DeOeOqa19eePm7d/s8/HLq8vbnmvR6Y1mWWu3ZrPnqN2bpxr1O/Lb34hUAASAgQQChEECQChEhAkJRICESVtzsUsopVRQULxZ1q576V6+nPzprfz3dZ6+nPRNb7OHOt3Pefbnx+ft6fo485zeftq05ue9tz6CcC+n0xu68pNeJx65Z16vXls6cwJQAJACBJSFCIIEEFRBCBISiQESCs86q0sooWlgtBQUA043vsagogtAAAWhIa8626yWJSAAVAAkBAEEFQIIAkBLBCBISogEJZDZnVWiWlC0sCqKCgGjG+imsiwUUhLnKaAFANed7NYixayABKABICAJAKgQQEQKgSEIiokBARJWzOqopZRVoiqKChbA051vVrAqgpI1hWzObaSWZSguGNZ7wIAACUACQECCAVEEASUBCIIkqBICESUNmdFpSyirRFC0FlkuzPXWwnaTOqV159eLq6c7nEvVnWEzyejhlfZx173nzx3ljn07evkwxevO85qrj054oAIKBIAQIJSJRBARFCBICJCVEAhElQ250WlLKKFsCrQcs1xvT6XPHLefo2+Rjn249vdrjpvO668N16F8vkdufo8/o7ePFqY88dG+nNvfdjGhryO/wAv1PP9PmeTqx7tnbjU1awBKAEQQBIASiQAiKgCQgSEqJAQWQhtzotKJaCrRFKtOLOvF7+nPz419/P6HDvjOmV3n149nmmjtz2Zx1Y9Onp33NdXHz+b14+jjrrmZ03q498ujb5/Pq9vgw8ns7515e96Jz19eMBKAiAQBJSFQJAQIqBICESCokBElCG3Oi0oloKFsUq2PP1OCb6fPrzfR6M849Tnnmvqx69eucvNz87o35e3yfQ6OvTRnHbveGMb+vXbjlrlxnbXHTyy9nmnP16OHLL0dsnCdONIKAiCAERSJQJAQJKEQQESEsEIglQJszuqKWUUoWwMlR5mpx49HZMeR236fNMXRz9G7tjovl8jXk2dc+54/o4Trqxy9HpvTrtrnfdjxdWsbM6wky112axOdnJh2zn0cuuOVigIEEASCoAkBAglCIICJCWCECSoRNud1RSiWgqixVyjwek1cu/RiY98uescObn7PSvm39enLjl1L3774HmzXZvj2c9ePn0elPNsNmro15dt9h5q79PPGq6wuJ14xMpcbIAggIgVARAIElAkIAkJUQYgJKgNmdCrQWUUoWxVseHv28fPj6Webpvl302cvPpnTPr37M8+/wAx1MTC+nbnz+F39nvOPNyxl0x0u/VjjLy5evHo4+vLnnOXH0cdXL0u3mxRQgCCAiCUCQECCVEAgIkJRIQBJUIm3OxVoLKKCrYq0+f304me3DP1c8uHoy5cdmfXz+rz+v5e2UvNnzen3zhx9XP6PB1+b3YYeT7PZ6HPl509Htvm53LHTaYXbPHGzHeteuaVUQpBAEgJQiCAlgEQQEQSoRBELElRBtzsFpQWUUpZatPnL118/X6F8/O5eleW3XPjdNj16te/u83ycWevfVe015+nHTHLnu9ktZ275aue+nSTWE47p11a1lmc3bgqBCkgBEAlCIIElCIBARIKhEEILIRIbc7oKooWxQVcoq88vDy7Om110Y82eWrWtfX17cz0seYc/Tj2Y7YrLvdnljcaJ269SyajoEuuytcGfR6N83J05QIBAAkBKAiQERUCCAgSEokIglCESG3OxQtBQWWlWxV4Z18rX0/Q4/M3sZJLveYpiz0zq04O/hzufV4e+Te5ka9YZZtZLkCGjHTdrONvNvhAkAKXNw1lUhQgSERUBEAgSCoRISwCEIg252KFoBSyimUtXzcb5+ns7OPiyS2Y79PVjlnbkZLhdWZ078/J38nseb6O6ajVTJBViULjmyzk33t8qZxsAzl13IVIEoEhAioEgIEgJRIRJQgIkBszugqigoLLSrY4Oe6ZTI2W5NZG+7xTctKQqZ1nLFyMgI1b5bc9aAmqzm1zNRkCBBKCJRICIJRICBIKgIglkIARIDZnYoKooKWWlWxzy8mem7POmxc1tubXD26+ty55FMjIoBkVRObLo1rsZA1WcuuYAgQCUIEgIElCIICIFQESEsEBAkBszsClUCgstMlpz5c/O5GRsXJdluy6wN67AZGS1AMiqKAmE1ncpdWs8uuYEAQShAkAIkoCIIRAJQiCJKEBEEIbc7AoKooKskzappy5sM1yNi5Lm1ttxNq7CmRVqClKooBiZA1XPLrmBTEJBQgSAgSUIggIikShEESUIEgIQ252BQULQVbFKujLlxNi5rmua5rsuhsXYUyWhNa7TJKFoAANNxz6xiCkQDGgIEhDBc7mIIAkFIlRBAkqAJCAhuzsAChaCllpV0ycWG2M12NZrmuSjbbsXMq0IMigq0AAGm45tYiCWWWGN7ZTnLkkBAkFCIIEgpEoRAIkpEBKJDEhiYkIFgBSwqZY8um2Nq7F2NZrnaXYZLsM1BBkUFUUAAwTBlLNSIIcW+/ZnnlMYXWcmJUA0au2TKCApIKShYgKCUkKCHm9eEMUxNGrtXGYwztrGK4S4LkmJeO9xsOma2LsazUbrrIhsMlIMigoWgFJHLOOWOue5jvOmc82tjeFkuc87xXXnpZjPeF1WYVYgBCy2y1nHNusliY3ecyAABza5wlYJx9G+XbzksxJWJinLfRnnj5979c1wdfn+hw79Wdb5dzRcl6WiQyrIpRFqghhc04Ne/ux4ufXnmemmenO8pddMxhvlux0xNV6yyefLpcu3n243p1ndjasLdeue7Grz26Z061G92eXO3tZyarENLrunO2BAGrWQBAAZS42DZNYJhZza6789tjy4prEsXF03c3Xua01k3xi9GezKXOa5AqliaM9ejXLTrnlNRaslyuEaddNTds3Y4TPoz3y869rwm31ce3lJZgVrIMgAAABAAAVqsAJFJVAAGqZ3XSC0CFZCXCbzszSIWJktBrayMXPY3SBBAkAABDXq7JBE1nNendMRK1Gac969E5kAAAARagABqsAIUAAAYIu8oyZsAtImShKKAUKBQAACIBBRCgEAAAAAAAAAApCkAUg1WAAAAAWFYlKAWCigFCooAKFAAIBBQICggAAAAAAAAAoABAFA//EADAQAAIBAwIEBQQCAgMBAAAAAAECAwAREgQTECEiMSAjMjNQFDA0QUBEJEJDYHCQ/9oACAEBAAEFAv8A4c/7f+O/r5o6qIEG4r6q5RxItaifarOWM8JNRjLlPW9ItK6urahAfqDS6hfAzKgSRJPl5uUOmSyQfjt6dJa+n9NL/k6llySBrx1a+olYqE1D5N0jSpiZptqlmEilzGeuGlYMryGXUyKsbnv8rL7OmrT+xWjPXD6tW+MWlQLFHM4kPlz1HzlX8nVKm2nPSw8pIxepo44WljZFglFmWSOtPBtVD5jfLNzXSmpERD5NQbWcfvP/AJGpkGTalAkgG5p4mzjg9cqRtSwxMJWBET5yNGSdgNTnceeEwtDLepudABR8vpfVtCc/Qw1Em3LM7IdIlldQzNEHWEKi3EMum7ujTUmnxoKFqDk0g3KjhkFBQvAqI5f7PzEPKaH1GRFpSGmmF29KnRPf6J6MZhl1HXpNN6ou3BOUqctRxnHnE9R7/JzOz6hoIVCxpST0J2Eju6LBGCjK8c7ozpE/V11aStSkjR7doYk1EbxjCP6mjPYmUxyLIWdJMuOqYLLmNsbklROXV3WNBNKwRxIvx/8AZkUyuUeGScZ6bTd37IcdPJpFkWHJZfp5Q+DxMx6CWCH8WpPaiA2UW0uoozzJUcolFzC3agPqp5dOI9PDKakO20zNPKAunihBWL48fksZFeSOSatSMdPpfU/dBeDOeo4TvQ9Taj1H1ant/W3YzUsqbUDZQE9ae8QCJofp6i60mdvp4E24YpRMDEwkjNj0xrGC7fIL+RO5Sk1Llp+qPS939UXtRzMTIbuAFGo9R9eqqL23miVhPESCp04PmD8imF10huTHuM3VJFlE2SqZLGZl3J/kV/IUqJdXt4m/0mlqT1XtpZYtqT3Io33E1HrPuaqv622lapBtL7H/ACf2K1L2TSJtxw+m8iNMsruVvDp6X8j5HILqGk070gixXzpIumWdrVuqdPIgkiglCPp+aT+73l1Xp/rmtT7PbTnlM+V/ONLEBTtutKcRnqK3dRUM7GtLSe98jNpUmb6IUmnROEuk3JSiqsWnji4bSZ1qIDLUUWFSx7scUEgo1NHuxRadguqVkk3pqVtSSqOw/wAhJo1K8ZUaGZNPMGjTbHy0v8GP2vm5e32Mhl409vgCGHzEvp8ZIAVlY/vh++Ke38w3IREOuB3JupXGLQlnVlm3qmcRrC+STFUoY2cKgylmR+cGn10jT9CqkucsGpLyZ0JRYWJKqK5CrfKTsy1HKXYTQRIQd+U+UZN+Z5Qrj0qVkRtuySkslmjYNFUZMiftnRKjHXdWZIo1lFioU2giaKh0sZNzULHaiwEpX5PVNjHkKnQFlmkWnkMgtsGIuAdVIaswTJkKsc8OiVAywq1uwlsxWNUXmlJyqRvpdPFqN2OPpEbFaiiVpMheeYRvcOnyWsC7I04FPGAspyTTXKdLLOathEuawZ5SKwpQyt0uU1ByB6pQA6y0aIuDEJ4oUENfprhowBUg2zLAktZYi9/ktXIgMWSDISU7kyho4YS/ko+cjc5JJWiUF92BW+oFlURAiHFqYdMq8nvtwP1MbV3q1qHc8GW9Nesatz+R1xtqI5RYKMFhLODE0ka3hFyFQAShbGO9DTIWMV6QF6l0rqbmOMdQ1ocPEvlixRVIbbfcyLF5cayN7gkMHMhs/AfIa3qlh9hHG3I+NQEx1O4ij0sYFLnqagRjGEVachKDNjBJIxk8ygJ8or455PKyNQjIXuByq5dlW9FrUrcsPMZbk8vktc/n5AvDFiUHVEq4yLepY7xxxvG1jHEtCdZTD6WUXWTzMBdmxHNdRIGZdGJhJcOcRkB1V/ttrShlBzt8lqU86KC1SMECjckFSKrLFcUxxbOVXkRqigCN2XmaCJcditw2nikKqiA3uEAYnNv0uWMdyKaRVYfJyqCGjGbjKjFeJQbXId4wxZPMLLNIWu1JMktDsw6UBphkFQIG6XFiCbCPmOABp+2qi3H/AF8lPL0HNVUUOF6xumNRRiNcbrTw1FqChBBBvxYkU+WIHK3EC1SXJosPsH4tsHpY2PHvS91PTQJ4EVaniDV5mnKnNauBQ8duf7kyz8Itb4x02wrXTgDbibWvVrcbVjQAAq1AW8DKS1wPA/p+Sm7R8h4BTXtdpZ7W+3bgyKx4v6fkpe3hTkxq1qH3i4DcJPT8eRfjL28I4j7xUMOEnp4kW+Pl9PhFX4DxEtYdvsyenlbwnl9gZfx7Vb7kvtj7Cn+DJ249+LP1fxbVY1arVY1Y1Y1Y1audc6uauauauayNZGsjWRrI1kayNFjYUKHiXt2/gNwtwtxeKRpQOVZDKv3xeaOMggj+JjWNY1jTtgMDjjWBJxq1Ne18RkL5Gg1XoNQ8K9q7UPvSSYkcxRNqaZFKur8CLhQRw7mwRV5rX7q3Ht4x345L9i1Wq1WNTRPII0axUVhWArbrarap9MWZtKcTp2jM8DLBmqhdRGaEimr8QbHiDf7FwK3FpXuEkyk7h4oyTPGtCS9HsLVyxV8jwMiAh706FqjqV7CmbnwZgo3K/XB5BGElWThJMsZByTnw5UQ5cXt93la3AircrGpIXcIhFYrfbU0dLCaGmiFDSpTxiKgnLlYq1ypLLAYyylq50A1MGtblYVYeARRhqMaE4LiAAbCmW44BSAM9zmJCBRIQ5mvTIk6zrCjo3DnRvV+X81JUf7Qe5AJrtxsPA74KrZLax+8EAHF0DpBpU05rtwtwUSZ/zQirTOqAMGH/AEuwNdvn/wD/xAAvEQACAgEDAgUEAgICAwAAAAAAAQIRAxIhMRBBEyAiMlAEMEJRQGEUI2BxcIGQ/9oACAEDAQE/Af8A4crn/wAPdvm1jbGmukcdolFx6QjbNEWcPpCFmiB4a7EotEcbZ4X9jxMrqlY4NfLrkexl56S4MvHSKpHDMq79I+0oo52ZLYSKKvcpS2JKmQVKxOx8/LImZej4MntIK2P9FHujXT8T8SDdn5EibpEJNie9DRtLkf8ARL0r5iRZYyftIKkf2Y5W6OGZFTPxE2OTF+2Pgv8AZf6FtuRn2Y0R/ZJ2/mH7STpHiF3GyrSGI2/QyS1RJcHtR4g5WPgc6dI1kpX0i7ifj8tTKfT8DJ7RRbEqgLhH9jyHiEZahckzJx1/EcVV9JPpi4F3H8pjj3NXSePuhKo0Vew3Re3T/s0xKj+iMUnt0ckTdnhkYMS2orah4/11xFcmyMka36KC7ko6fkIewvSrIyUhfomfkPkeSmXasvYTTFyPT2F7iXIh8jEUVQ0pdIrShO2NC3VMUNJyZH8hD2FJqhRjEX7Ji5O5oizZKkS2RiF3MfuPyJRYoSHz0l7SyE+zHsxxWqx80VQ5JDN2SdKvkY+wRRH9E+Bcj5KF+yUrMXcXcx+4fJbNzuPgft6yLOFZ7kNMXAtlfyUfYT9qohqs/IlwI/IT3oWzJxpmLuLhmP3H5DkyEnZ+R2Px6RVslvsSGkxJRE9yQ/b8lD2G5bH6UJ3EXY7knue5GTgxcM7Mh7j8iXJj9x+QuBf2VA1foSrcRsbDRLgl7fkoyo8Q8QcrIzo1amObvopNDdkJaRz2E6dniIYnTPEIT7DNjUkWmib/AF07EJWhyVEpX8vDklz9yy+suj+ahyS5+xe9fYl1lFxdP5mPJPny1t0UXLgnj0PfnyWrryS+ZplbHh07IQTkNLk0CnFPTKJ6LolSswy1oySil6jFt7ODM9+NxZJ3TR9PljGROWqYo9kjJ9Pmx5NXZiw+iyU6emKoyZIqVWJIor5WJkjopLk3MmeWnTQpcE9U5eH27kUu5LS+xjcJPVQl6rQ8MILZkPWtzD9PN5tJmx6X6SUZN7sxxV0jw5RlyWSbfJwOuxLFkTexj0uJLN/t8N8FpKkOcU9L5HXya3ZK26iK6ZiwvK6ZGHhN2Y4R0MdWomfFNTWlCj6j6nVq1R4MWTWKkY3UtbMk12H+zx44Jaq3Y5ue76xXiz9Rlw6HsMxSljlpZl+mx6lJo0urIfT+J6v0Sg06+TYtnsQlTMbrdE5WxOjDG92Osk9iUILIkfV53H/WjHkjBcGOdrUa9J9RLS1JcEnfB4Mcq3Hh0qkcEGavDl6SeWOT/tC33JqWtSiZGYcUtXof/ohllDZEm7+T7kn+I1p5MElp1Ci5sUbekyQljjRjy6I0jJklfFmeCluZFq2Pp8brSjLCM9mf4ywukQpMxypka1bmWS10ihFQsfAjYUiSlp9I3fya96JQqVolvtIgvDg4IdxRjdMnnU40L9mCOoljg5PWjHpj2PEpVEyNRjSI5U4pMlB5Mloa0n08k2ZIR8VtCi73G1ppE8dzUkzZIyy8NaiNSjZTqz2kvaPolfyH08I1qYm03qLtmPkljbVs77nLpHjY8b0SMMtFjk2Ri2xck8cUtjjcTjHdGRpn0+pxbfKI/URx5NzxU9yzUroueV7bIdcDlRLY8Na9aLWlJj5+Sx5ZQdIz+I1YlUdjVuLJKKtjnGUjGu5ni8suKruY4rgnSPEUuDE9tyMpJUj/ACHrpl9ISWii1wzK4eHURZPVSHjTlq69jw47mOMo7XZkbcXpFdb/ACWGS8dDnVtGPG5sy4nGRkuirISlRghPK9+ESxY3HVHsZXke0SGLSKNs2THginq6xySjwObk7Y5GiOrV0RJq9iDk1UukYtptD+TWztEZvTRilpHl/wBl9iVXsKiM6VH02VRjpJZkvQusc0W6L6Xs0SVqiGNQ4ErH5ZbsRhnpUk/lMMNc6Z4UHskSdMbvpp2vrjhpW/XJgreJizuO0hSUlaE136yclwid6diN1v5EqI/vokx+d18XFuLsn9R2iN9ZexC8kZUOjJhUj14WQlqjfRKxqvPe3SDVE+fLt8bHd7j28l/YqxJLZdb8k4NtNFeSXHTt8ijJ7vKukairf3lJrjyS4+ZX8FRvrLj5Bq/sr+CnXWXHka+eX25cffent89LyJ31hjc9yUdL+LT3/lMoa6V1x5dKonLU+mh1fSvJVlfxaKKKKsca6LjqitRpZt/KyZo4y7VrpKSStjzQi9yGSE/b0e6ohHSt+iJS1FVv0v7NjronXk0/ZoorrRpNJpKNJikkmmNdz6fF4sqM+FQ9pG7EWX57+xZqRGWocKiSW5kx45e4xzjKWiI8TRKNcnh7bHtIzb7dKFjm0Shp3HCRpaMzcVsJ7GTWqpdUrdE5aXVdHXSEdTJ4nHfpCGruSVC09YSjVSG9/wCC0V0xTeOVmTNr2opGlGlGk0EK4NNLo0bCxVK0ycHLuU138lFdUa51z0eODdtEfTwc7ssTob6PJfYuLXJKUdPO/RevglsatUabJ4EkrIqlvLyWjl/zlJP7TjSsVV9iKtjVM076vvt6ufJwam+errt1U0o/2N3/ADaRGLk6RKLi6f8Aw2/n/wD/xAAvEQACAgAFAgUEAgIDAQAAAAAAAQIRAxASITFBUCAiMjNREzBAQgRDYXAjUoGQ/9oACAECAQE/Af8A4cv/AGy5pOhNPjKWKouiM1LKcqQsWXU5WWJPSj6s/gWN8ikmTxYx5ProWKmXebdCkn3dm0rZhcZR9bRg7ZYjt0NWqMGVqsp+5RONIexbjwRet2XvSGvk1OKrqa5RIy1KzG38o4aaF3fD6mDxlXnMP1Mk6Vi4tl0y9E7yfuMu50TrSVcDDVMw0m2Yq22NKlE/wxNwIfLI+Z94jtJlNbH/AKLkh62Yr3oriJjR8toe8TBlcT92NCgWvSiL8zKa4FBvll3sieHYn0JfBFUu8L3GQjcjQ/kltiUXUmId3aZ5vkjsQeidEN5srVI+imRgkf2MUEz6VkYJZYu2Ij9+7Wi8n7ph+pjkkTd4pLlnSkLDPpmJHSrGuGYPJg9c3tisU3q05LL+R0Y+YvuuNLoin8lyRh4vRkqlLUhS0+YUdTspHA3XpNWJ8mrE+SU5VUjUuaFB8xMONI+sronjRQ05S1I1ea6I4mrP+Qrgak6Ncm7XBhYmrbJ4zvbghNS7hi+4OOqVE46VZW6ZhcsftkfQQw9itMtJs5E1Q+EYtaB19Mhxkt8NkFuS5pG5B8o1uEi7JyuVIk6oXlY9naJYmrY9KMKNLuGJ7gp6ZNksSUuh8IwvUx+hn6UfVklSRHU3ciG7s/kdB8xMb22f1EZKhziJVBoj0I+t5The65F540YeI9IlSs9XlIJy8ovhiio7kU5O33HE9wfND2JcpkPWyXpYvTZZJ76SMaP5HQfMTH9sivKaU+hpS6H6sXrF7meGqkad2NX5SS0zNUSfuD3lp7lP3SHqdk3GqK8hH3CXDP0JR8tkt1ZhT1Ix+g+YmN7Z/URgqJxSVkfbP3R/ZlOaiiHyRFOUeg5a+USjcCPuC9x9yxV/yWUKMOovMySrEHG7P1ogtitD3MFUY/Q/ZGL7bP6iPBiehkfbMTaSHdpoc8R8IWHe82OWrZEvhG5uKW5H3CHrfcpKz6Z9JCVEo2adKFG8nGxKiUdSI4dO8vpCy+kYmHqQim+p9NvljhT2MNPrniQ3sUG2QjXd58EePuV4I98nwR4/Aj3yXBHj7D2HeV+GPebNxyfQjcuTfgckpVZW1j1EU2YuqPBC2Tf/AGIR1cM0pOxtRdslCOjUuTcTJSUd2bckIurLLL+e6sa+DcUG5blEuaHFMVxFJ0KZqUkSengtS2GlEU9R6tir5OR3VZUhYsJbD1Jtvg02rjyR3XnQov1d0asTl0HifJt0NfU2okoxkaY/JTqkYailROOli4piteYlJM60Qg5cFUXXI+BTsmvLaIbIxIrEgQbi6QseLlpFPoaqe/c0rNTqjFja2MO9eknDTsciw7dsaUjSro8y2NMsUclh4ulnp4FLVuVvYpyjOkNDSZONoUFESxL34MZVUV8iqqY4ksOLd5Uu5r5LOtCw16nyeorcvU+RSpEafLEiC0qx4evF1E2hasoz3MXE0pkNlTLVkk2qQtajVjhdXlKL33NEtKb6EH5t+6R4JbM4lZKeolFrJQ0skrI4alyanHyxHctrLpUia20kFFbM03cRwK33NjTaI7RpmG2lUjYirlWTp7CVEJ+Zw7muDTY7XJFXwYm+5HT1JVexpqJr+Ct7IroSTexBS07nUw5pPcm0LCU7sWC9NovfcZTo2gv8j6Mlq6EL6mry0JVLV3NcGDWqzGlb2F6VRO9Q4siRfltnLKE9yQ42fSVWaFdjlpRhNPDobrY5NPU1bV4kle/c5JuGxGWkSs1SWxF7lk9KqhRKVbDEsupqlVZOKZWduqFvmrPNlG+5tlEJUalqyt3lCW1DfTNwa3zu1npt+NFi7ny6HBeCs0iStZRxOjJYd8DVeBJdfHKn5WKlt9lX2tSV7E5Xx4HwvHGbieWZKNP7Wne8o9zUFH7zd+K1wJ9PCu5slz4mJKMbf3Jw1b+Jdzf5S7m/yl3N/lLub/KXjS7Y+Py7FK/CpJLOuviUW/tX9y/BFWx5PwL8zS5CXRiVCV+Fu83JpEZPr95xt3+BCWlk5J8Flll5WWXZViS1ElsUV+DQ1RW2Sch3lTKeTjXXwNCxsKXls0UQVvfKK+SsqFEZFy65JWONePp+HeSdFlllsbLL/wAEJqfg1WqItIf2XjU9OSnJDd53neXQohhlCk6I/UXUk012296/KvwX47/PSsar/Rn/xAA/EAABAwIDBQUFBwIEBwAAAAABAAIRITEDEkEQIlFhcSAyUHKBEzBAQqEjM2KCkbHBUmBwkpPRBHODkKLw8f/aAAgBAQAGPwL/ALHI/wAWbk8wpFtm4wuaDErM22xrRc68AgXnMw7fZtFdSdFZq38Kn4VmaZCgS6OCphOW+Czr2JcYW66fF3x/SU5v4aJiKbzCeODtmbT+EWrKbtpsJ/GiGzI4LKb8CIXtcMwHXRatFvAR+y9kycouszXF7dQVmFihlsKD+SsMjvT4u/ylHyBDrsa3ULF6rILvoi86oy6gNkD8rqbPzlO6LORvCycepQ8oT5/qWYUzXCH/ABDeG8F+D9kfZ2d9E5x6Dojin08XIQ8qq545BWxD6LdbDuaxVyt6JmDpcoYmjt1yjVqB11Q9VOIuIXs2VGsIO4hEteWzwW9vdU3DbYGqOLhDd+YID5Tbkm4Q+a6yiw8Yb0KdmJ3ToV3fqss2esYtvAWb0Cn2mU8isrsYkdVlDsydPdNU3onQ8tgrexHOVAgOoRaNFvvEcGhUGxwbQSCm82+Mx+MhYo5qrgPVFwtnWL0CZhs1X3jP9ML7xv8AphBjj3rOiyzG6HlT/Nt/OU/p2OrFgv8AFfZ/IFLqdV9hiweRRbi0cNeKLiw1dIhOIGU4tuSqERhmhOoRLMW53kN4k2zQu/8ARd/6KsUMyt7M8fsmjKCOKre5U5Dk4qGb3FO9oMpJkI4jGzu05qC0tPPbhE81htBs5E+0IIW93hdFzjACzBgj+nVZh4g7zBOZmLQOCDXVae67ghiar8qwupTj1Vzmjisr790807DYRl5qDeJBCA1csphs8Sj+iCd0TwhzaoaC49EC7P8ARVgjiuOGfpsk2/hH2VJuVOrboYzbaoBtvl/3UXJ+q3rk+IHz/wAJzmNDsyE7sWXsm8E3yrD8xRHFdxqOK4p+JobIeUrCQ8yPVfeN/VOhwNNCnuWH5ViKq9rh935mosPohh84J5LOdVEESNVLLi69mfRZjSF7V46DxE+f+FDJnpKym/AiF7RuoTOiHnKlbwETCGFMAqBZDylYSZ516lEZcP8AzKAxh/MnZRAiyZ/7onc27CDqhyCc3TOhhiwqUWuNcM/RDmgW8Qgw2AnxI/8AMWJJiyzCM4XNxosNf9ROWf5cS/JT87UHL8hWEmedO6ld0KQIqsVdCEObdmRved9OaOI6nDosx+YyjDM2bms7cOtjVZeATfMn9PEn8nSt5TSFmsxtll/pennQPCc0Ga0WTiFDzBsQnO4lR+BYXRDzp3XZ6hYnVYnKEHMuFo1Sa80GN7v7rKwEu5Lu4v8A4ru4n6Bb1dDyTPMsXxLNUFfeYn+Zau8xnZnDy2bwsujjWVRo2Z8ozbA5jsrggXOLnAIsOqIxHyOGwsmF9piSvbMEg0cFRuJ+gX3bz1IC+1PoFGTMJpCc53edtdlYXNfwUs3GzMFGsk+Lt83wLfHB5h7nLr7gbZHjPqPcSVIv2I7DfGZ2ZuSsi8mQG2UuEFUeGtGl1GqJVlDgYcgAZCc7DG9Eog7r+CFTMo4eUZGqaNF0ThvDx+yexzIYLFQdLnggwETqozVXH1XdjxVuW2qhx3EBmjqs4IyngVIusunzJoDep4KpkLM2h1Kl9cq3WQzRfaVRIJHDms89VLbLJF1R4jkjHqjiAV2OFE7dmVqZ1TmD5VdBs1OinxP1RLwSPlqmZW0FypBzABNPEKM1DDk55IlBoI6gLddMregiE0EUeFBFFkGig0UBNBvqVuiizaIgm9VLNDqrIrK6bpzzxQCbuS79kDND4nLjEFAC/NQAi1po2iqKcUwO1kTwUC+qaCyptyU8FSsXQEy/TkEJNAr2QOiB0QkK0BWUa6KMQIsHd2BwrxGwEncJ/RBzjZClPE24bm5pQxNOClrqBBrRQ6Ix/wDVI0IK3yQdF/VArVRCzAVcshIEI5q1/VEun0Rczum4Ki8VCbyCACLKy1BSFzdsnbTxTDPJFp6Ldosx0RYBMfVHCmsEfymuom4XzOq7ogDxotww5McLi/NS7SwCl1IRcDQplZbot4JkdzWFmPeiq5okmmiLpVlGuzLqiBoUPE7WCvBms7BvZUQWgE6qW0zI4r+62qD4E8QpeZgrMAv9k4kbvFb4iUcOanVezdJy2KANFleJ4r2RccM8VSpOuzKsooFUKgUrOCnOr08TgcFkb3NOak6pxdVUBBH1WQi69gD1KyybWQqDHAKdEQwbAeFlUKdkrO28L7QO6lFvBZkXcdp5qJngnR4mZ1W98y5oPtxGzmiSLnVUnOVGJXMsuGPVczcolCVI02VWZzarK3jszLKqLeMlHNsa0mrreKVCDtQhyV6qqFKIEk0ssyFe6uSlQDsKbyEKJhUQMFTGyeO0bMJzZMO8U3brNmPTsjsyyiy4ioqbRlbmRy3QnsxpqoCg+JkBS7bzRRHZrspVqDtlfcTsntc/Dd3Xtz24HbDhcKp8XHbosraNZf3wJFreLj4cA6+LD4eD/Yu7f4qv9ixr8bZW7d1dXV1dXV1fwGaRty69qHGFI+JEipQPHZ3gB2BKurfFRtlQSqHbB2WXNTPvp7F/d6IQBI5rf7YqQu8hvEBZ2mmqbAPMrvhXHwUwq2VVLqQozCVVynMSu9s7hHXZdXqit1/orrd2Nj12yVRrirbZIPoqT67IIcegQcBfj2JBgQq++59jns+VDMZ2VC+7b+iMCJVHPH5kIc90lCsxso4qmJCJz3X3nojUqriqOPbmK7JLVlyiFQR2bl3qjubq7sNWtVdUCqwht5mi3c1EZqNtIVPj91wPuiINFpHYt2Jyk9EDELNU+/g169gtNitzMZ47Kdh2aMunx1GgKXGFI/wM/8QALRABAAICAQMDAwQCAwEBAAAAAQARITFBEFFhcZGxUIGhIMHR8DDhQGDxcID/2gAIAQEAAT8h/wDwDxf/AEt3/wDbTZxzHf8A9YVKhdIWEAktZHpVMuA/aBWtfjpqEzq4uYFLuYpIl89KgzW9Dw9Z/ff5m/dyVqfxJkRgmD2s7gi2kfHHv+jGAmgqcc/V0r2PghcIW8Nx396cDtDo77/Ew6ZyOVv7de8Bjkjcx26Uey4e3/kIR9pce9I5xm5ga9v5lONlWfdZfAX63Msrwp8iXUvKxyY0QKubFftAS3ogNkj28f8AhCIpHXaCl9WFh3+CZvl+5PZL56aUlo3MB9czhXsjlgt18TiIZuSzR3n3aumS+X5iu7VCHQd6MMIhpo94PUNCTF/6kMHS5xesezNPa3PV2z+9Rw5nq9u5CdMo9AT2OPY+rjygzZ7ztK9xjyfKXNtmPuJq+kVoa4+jb7ygP4JAOBiPiZI3YX6S0NMeqZJ3v+ZRUDwrUU1XPnEpU8ns7SoSrKPuSwDLRQBm8spQizLl3R/Z8waTfunaW9beiCfrAYn2D8kutWkFIDtL5TOYMRiuJsZCeLgt3+wRsH6BFChwwO78t5YFHQ5Qe/8AkiJwEIEdY/s0H4hVEQ+C+aWKd+TMd6e4XVXQdKAnaafwfVrDmU9Ps3zph67GKe7MKLaFP4lRJNV6/jG26A4UlBZUt4ldESk8wRb3fpBdTNP75gpdw/o4valwOf4mz6puDAIcrW/eaAu6qWrQ/J+I2AFvsE11URfEVdwr5mEqjUJgWslEOM5EHbiNwmWUHxKfA9I7J+8BqPEGyWoSu9GXzKeRpsWt7KQDTtf3iEh37HBNuIQShIRRxBvGd1p7xx0XCnD4lphSPsf6loH1lYPGI6Oz/nKAytZ55Jaf7gG04R2P1Df97EBAEzD9/cimJtMzKvcfvFZ7/nniN+TLRQxmyX6Shob+iqxlyW2p8qFhXpncxI4TMujo7Ir8L+GI69E/N/EEIANexLTrh9omqI4Cv5lYSOMkbgY4fuSuFsSoLXBm5Zln+Dr33AkX9Qzcdo9ybA/kJWehx7vK8ENAeFypTuU+okJgUsWpdmcDtBHMln0Ce6U0O37M80n5YaH1LhyWvzF3Jr7J/a+J+b+09yZ8/wCWVisHhMnZdFkIDT/BAw937TT8EoQE7MsU/ElM2Ku3aAyKYC5KnKvHBFt7YHKHDyUPHDLgcOnbuSnEAR/S4biOfqH5eAMg7qTHR7wy5u1Q+kfv/wBofs/EShc4F+WVu4Vjh8xv344BOhP7vxPn/E/r9GC3euT1YvLPJILScUWMVUjCqn4gnHpAakKZWjkH8TtYF+0uyobfiZJP6H97RQNByjYvQ76lxOM7sc/UfznxKX0uzLBeW7HjzACVWE9WP8q/EOfj9kEo3b8s311DujZcn8zuJydnoHzviaej8MGqv7McHwTDCg1zMPU/Yg1/ZwE10xXTFV9nMUMo6PHCXxMo5bTstdoEoUo5EzzcMjyn2x+pZjvG+0VtF+RuDphYvEu8A9/4/wCsB7fgYBwnAeZaGvZlBw27mpQLBhJlXtVRSj3P4mL9hLx9v95w9Jv/ALZnu/2EaN7nsEKpKOYuP1ql4uW1O4DmFUkL0v8AMD37SnY+/wDzxEtRfIpkf20zNPQ+pAW06U5nZL74/ebyxxRghWZpXlD5Lp7rllnO1Jdxe/zE6K6h+pNVEWkJpXccMrjtKBFbNtDp7MpDZWAYIJST+RCoKnAN+WfhCr8S3AeeJRErPAqFbJ1asghwZf4TwPiZHa2v1fT0Jz/wDQb/AOi8wOQv/Bj01ouGND9Y5mv+2Y/rQJQSyBh96maduYlczzLNhfVjv0uuPqy3jxKbtrdQHs6DBsRkfzF7gJmZg0RRCDQyl24B2QaN5qjcEV31buAndI4mH3DUBI5GMwFWbGlwIgcTWpduSubPMdnsOJwVGtRq8ldssZAo1QdWOnafgcENtv1QVIBRRs+qFUZOZuOwnKzcwKHVpQMh3rlYU8GUBxsu9SsBnBn2TahxRzkMIZ9GVM6G7llpCFwx3cRoFvkCIKC9AlNRulZNRQsvSu8tTQuQcwK5VCkcKtfiLaGWSC74nZJrvTOCZto1DAY5fMtrbPLxNEpcVWu+Pqdeutu8BNagUjxQOy+MTQDM8X2ll8LQPPM1wSC90w5hYFIj4FhSiCv3FByQP5ggl+UGyxkuA94JeGYe8XQY0Ezsu4u0oREUl/8AxKhZUg8RMMmiMncfwwUWsyqNXh6QDOdeZQ3mUWG06pADoFx3j6k8O0qLuN5a5yJj48GpaPfUrcVfAWvmRp0x8oZPmaFpmFRplTl8omOq5MzkNGBF8igsCv4gooFF9IHicLBEIbZcxpZHtCo8XcFjtXmdkAuvxDzgu6uVuHZzqAAqsw3ANfuQRAql3CecGDEEzEZhC9ddoDI+pOdWe6qNFbdxdRr7lfnxLpm1G2DFTg8uZe6qyvnH7kNllgBuVttpvYm1Y5y4mEvFWiZNDp5l27w8tSjOBdcoBNWJmSZZBA8kVzNkZ5nGavPE2l8jpmtc8S+ws9pR0ISps64g1aiNupRL42PMN6YesRVL+YVv9SJmPIinmZA1bH0hLfoHeMBJT1cyvMP3Bh+0oij2vcAGc92gVgrTLUOgiOAYSBL9FvGiKT2nEDXVb68wZtTFtsYWTszN2zkswABSlgMIdzBjGBMJGseZyq/SY5p5EOV7SxywvUORGrPMuDk5Jhya6C4/Tw0ndsoiiCVDw4St/fMsUApx3hSIZDdkTZSrOZxsLXx4mPAc2U1ct4CVfL3lBmBmMjTXEDQlbo23MAiLLLuahAfZKkzx4KmyAcs074IJ5YaZqBGb7IngZ91G73x7ZSvJ5hBcnpBbpXQXsj5wcNoYbUFH1Jgaq3LmogS88DiaPycMVW1N6hanXS5odz+1Dx7zsO7KCkwg70w3cxoDmtx1Vl0SB+w8y7HkiajsSriYI5gubnmfPHKO7qX8jD7dDKZ2L3lxgtm26n3tiyF0Xv6kpzrIrxAdIvLHBBQF1siWVDYQGGoBgPi8UZ9DnWWZaDPrhjXE7t1McuBWZ1qORk8yw3vLH9zCo7rhqyMD4gq8vRYOTmPAZYmJQO5TbRrHiEfcNR1CkfeZzKu1kJ5jv6kToY3T7HMNaYW3KMMubv2hCbcyoZ8mAx8F4mC7SpQycdetyorza5lYTxLbWazFpUWoss4lp5q1cdQrckcFs7VmSp6EYrC+5M1Nxh7u01HU5TUDUO5E54FcH9Jgyxf1MxGRe0oE+cphuXkpgAoKOhZqURMiUq7XK9410eY41KnMvE4yOmXJWQurVDXTnyc5qpkBrj1iVZtZlAwS5uAKIB524MAOKoV5e0f10qz6WLAoeIZtDiBXTAr/ANQOTvKkfboDGKgpYaYt2QvAaJDN9JPMWejuKiHTfS+mLrqxKzwGBjvMrF/oDdtfTV458BlB+iAQ3GexKNVzEKiVK6AJSWSlFE4iHZA0K681HFDuckWABevPXmfN04+pAYarqdNpwAxygjLu9palw/xNm+elipd+H6Pm+onWEIQ6KhmULLMRLvqfo5/Xiy4PTvPk+oMQGs31/OhAgQJUM46zofoP11BsgUV0+T9C7fT9frCEIQiSU/XZclPVLUvf+L5J5M9VXqFU/obrHVusNSpzE8f8e3aW7SntKe0p7SmUynt+rdFCEIQ6ekwQ6H+bX6zPUws711Giyoif4qZT2lPaU9pTKe0p7Mp7Mp7Mp7Mp7Mt2Z4GW7Mt2Z4GeBngfaeR7S3dLi48jPM+887POzyveeV7zyveed7zzveef7zz/AHjGKYoughCEYZ2hD/NpKxcYqUNEqZ7EIGum5VtfS1Ww4gDOBX3/AEALJzqAksdSutXK6VK/TX6qldFpaK7Qt6KAlCSjToNeXnMVLQWBuXrVVrESoi+0GsaeekSd1cUIQjFfpiXMwh/zCJypcqdYxKxBCnUwuNXDLu6MgNX4h9l0dM0NDvB5Fe7iXvq3oFK9Mdyi5J9qqbxAyrnppusxuUhu4eSPNQJm/HXiDNYZrPf/ABt4iK4a2MDIjHBOylZmrpxKIziodziEqX4xMjQ63MjuncQy+DiGYih84mIG+8DBlzmISpWYKrF9KlS/0O4hEOb9C5swiOrxplSF2t2tTBQpi4wtzyalHE/GYmGXpc8C+I9T5Y6P2TQKO0HtVOwHhH3vW5R5WsvF1FqzFyDpzcXLQeI5V9kxMtn7Jx0ugei5qA9FdBVkL3R6ipYQb3XvM347TDiONADcAAre/wCqpUqVKlSpUDadCsn8Q6xWO0Ll12RbSe0LghGxzDRQrId4tgEdZftEspFGwlOYRwXqgFjoyXUb01bhfaFK8EzIDtjE9jCoR9tuJVVamykqts3jU/0BLSy/aFha+89b3nigVC+W4hrMpP3Oj4CvM2idlTSF41M2MZvEBjA96upqio6lKfURRYTi3ay1FaMNEQmR4S5ZLolhdnpG9JMth6x7WjrGLgC3gUJiujcyDcHJUWXbfT/GFa/4aaVO6/Wh2IYK6AZ5CYiNwTo3MVI9ul9LHd6NzIK3DsmbkPF/rv8AW5JYCr64Y+3T1lqddJEXmba6aKLvzC6zueEW4pnZxYFH/NYVh3RMbiEXseel4r9GeH/olMqogpB9YAKCj6//AP/aAAwDAQACAAMAAAAQ4F2QMfcAFsJtsttpJ09lsC2bgAAv2yVpAX7Epr3FqyJj8AAEgFtoJJJIBMt2S2bpAF2/yttE/fULSIv2QsfgAEgAtpJNqJJJJJ+W3f4AJf2jNpi7wleQEuyFI/AkkNtpJuptttJtN+SxNkAL/wBEbAB/1KcjKdkKY+BJAAJMbbbbbbW2381oDYAf9MgYIu9LRkZTshTnxJABJABTaSaTTf8A0/pQmwBl+ZmgRdy2rICX5GmIiykySAQ0kks8lm/t/IQGUJv7IEGLtQxJAS7KQ5c2kmQASEmkX+0kkntvKQmxt6bEyJ/CGrICV5SHbOkyQASEm2glW0slr9rKcmBpzQ2hP5S0ZASvKC7JU2QCyQ20gA8m+2Rrd5D0wNv6A0LvCGjIi1ZQS5Kk4Mx62gBHMAimTpLd5KUyZtyGmJ4Q0ZGC7KCXL35AG+iS7ERZoYC3ZLv9CETNuA0zvK2jIQXpCVrX3gk16ioloNBiSATJLvkSkbtyGmN4Q0bkC5QR5asLRnEGjXJcaUSQATJZ/wAFJmTkNMbwpg3gFygqy3kmnp31r6xTP7kkAlyXfgtIzchBneFMipguQNWWbh2ilAsX3r1cBklIsyzcAtMxewMTwJs3Et2BOyvlcrV0dBgrBJqN4pJmS7AFpmLmFjeFNyoFexty7/Eb8eTYNWu10VWtpNm2ZuFo1ZwtX4JGZhp3NGf0P9Sgbv2y1gVrpCtoMSzfwtGreBg/BIz4NWhi76tToHfe1e22OkstAkAMW5eFo0e0NT8NGfAJ0GXfMouSoRLTfOcajcSUkBi2dwFGvmhiahoz8puoj75Ay0pJ/WHCWnJ0OQkgNW7+Aox+gMzUNG8EK9Gfe/CbblvGEwFjpxk2UkBiWdwFOLwpuahobFhXMjywhNPkHyS20C9a72yEgNWzfEp0f1MzUtCMoORgbUFJtsr2WO2ybry/2UkBi2fwhGHwhG4NMTJEK8HWVMWNtEkZPtbDb/8A0pIDFm/hTM6AKGIaN7TAVwO8qvrngy0bY6Xo2R+loDQs3VCcuBDQ1KUnccCsYvlbnVheBbf1Q9x3X0oAKtn+oblxITGhfsRnAcvB2iFcrxhf2B6TnPzGlALVk6hDVmIaZ8Ll6MUDlzO0z25J3pCA2Itkr8VoBRsvVAas5Lcvqd2c+pdm4+OWLD5ngkKJEaCYtoBKNnzIaN3BTE9WswH1Cc/J8xrsHHTrkFpxf1kYpJRl2YLVnATo2C9nYn4bszPuYl/W0kAkMQZktggJCsu7DVmxasvoVsyu+BVnwsRjObGMUQ9jf/FCELCNn1BTtYKcu5OuvOm5DVmUhmJPUdjRbbp2jNMIQdl2oKM6LTl8J1sQ93xTErGIGsA4daLroSUWiISdk+4BcuITFmoV3Sn13JDcx8+V9jKFoyTR28SDDdk2cBCuZLVnxPrTN0m8JSvWpHucCD7QUWVvrgPcn+epC9yDVnlCnTR8s+oKamPk/KQRAvLCtMdiBMlu4VDU3DTnxBUTIn1svIKUx4326+KSTbRPL/RMlu3BDVnJXF+IPqYI8lt1ILuBNm+bwbQbaIJ3UMls3BLSnIKN2oKnRBSslnxBYpFwTUaKTCTRAMRAkqnwIYs4KcuVB06AaRks+QJHZuBJAQbIdqYBJJbsm/IAdqLZnwhXnYDaU/8A8wS6yx0S7mmCmmxCSS7vPTQ0Z6CnP1QdJ15Q2hY0SQOeb2UyggU02QCSQoW/wsDZaJvP3Q/kw9vwbPX2Js+RUNgiikmmAQb7xJEoYeVzXdACNe6AABsYJvwJdMrd9LsWn0mUakdDE8Scps3tI7Vs1uzLttr1P2rDTdZocvRGrAUTERHqPs5f3c0UgSQL9pmSGUACTH5LgoYOME0SCUx3pJaCXgE20yASSTCAkyQgACSQMtocnZbtSEi0DpaWSUkmkCy222yUQ0gmSSAAAMpm1rC0zJftbbNvSEgEkkkgkEW22kkG2Qf/xAAtEQEAAgICAAUDBAEFAQAAAAABABEhMRBBIFBRYXEwQIGRobHB8GBw0eHxgP/aAAgBAwEBPxD/AOAer/0W1f8AvbUyjv7R/wBiTzsVZHaeFsWOU8bLUcYiNDxsup70X2mxgNk98A03FDTyiom7PNzYiuBxE0JMg82OSVte+MDDsyrqASAFEsLZY1KMRHKFRaniDBuCl5tsTpDmUxXOjhHaCISVYpVQwY6QJqXQisiBUuBlcO4jQeiMcQ8Hm5MghbNS3RLpmZGZlg0Klwu4P5ZnTuOAQGuAEgapKJQuJNKgoqHcO+Da85TMMo58IU4oJj6IqKSWNRdmg2TCkUC5hqPGRY/YShE4Nlht8+akPSiGzgyJkZoiMA8AyqgDwKx3HSOOrgF1DJnunUNwHXCyJoJt5oVXluiLeyAkMxiJrgSzlBtqqiYqPZ41lim6uNww1iDS7zFXbUAq6iKpihauezxukEKgFklqmoF4lPLMdeYapS13GKIsvAQLJLgqUrRwrCWoMvaJU5M08WxMDHhmJbKOoZKgvvERqZHubiXFyiSLJmX7QHB5hoiWmahzFljWfwxavFlrFgHh9J2mkf2wlbYSwYmmOmaZaIsLXREHcFZQC2eolpUGpHPmGqCy2UZTK4NHxOiOGIcMI+DSNv5jijuWu5mtzZMuJHZMAfaDY4JaRTcvvFEqt+Y6oGAizqDtMp6/ECxL7YsHrNVqacghBmo4jHSP94ZXzw8lYE2qBhdQihuUXmswPmWQgiK4lEuUbHWUDeIXI4Ej0eAcGa8WidZlLASGTTAlG25llnwnwmHi0eZLxXrEaGNQqEIiKrbAKibS1BaESCzMVtyoYjZCVUAdSx1HQhMGgi2WdswKXqYSFgeb6Zv+pb1ludCBbUFPCr5xphz+gmnb6A1wFtecgLmubfCBTwZ2Yun/AChVNyqb2RGdhnkF1OvnAXEmoHaBVNwi3EKpiCkf3Pe9f9xNnMY0ynUPIVChprH9y5KX6j+4rlb4zUV/f8fEyHO/fMtqMQL9RCz+D0xKTa30i+qA91/VwQxEagZkNZiJ5pS4Qedl7+CDsSsQ3v8A6hbO/TceRw/wRgq+D1jwaSkctZ3j4iGguP1itCzqFp7wJdB79pTibPzctdHtVwN7O6/uZrEc1Vfu5gtenDEVmEBCI2sr4hRTk9dvxKQGmU3/AOesBjo/n8w5uahpjzMlDKrI911GivLqNMdWxgZJDUGW2II6gA6e7HadQUNgZgC3EuYjbCXbVwdo3i+D/wBiF1xM2S7pIVfYgZ1n7wW1AAu8fEfmFH6zIEKyx6qvcYvrzNVmEdFEC1jF2MzDtiZT2ZEAeDf/ABPXBPS228b/AD1Hja/SPje00OvWK4HvX8ymbHtGoGSBcaluUy0y+TMosKYHEBkDSe3rEaVgU4abWb+Io4VhEu4+ZWIGWqMvrHuGGYyEw3vMzqABqOpZjQ2+HUorJezuEitNxR+ZhgQhCzMJrYxC9Je4wxtMWe6rlqshFtgTU3v3ltCMbKgDcAWu4gLpHviLfmXqK1/MRyf+5ncl/wBwlVi3cEj3djLzMy4M3V6I6YOvmZi5a+ID1rbLNXDByOPiDcNbjOxla795UP2mA0lWee4FUHcDcmnYuIgJR6MRpaNnXUwDB2ch8vtdziKAxl/eOlCNWJpFVtEgIB3Zb7f+x27w6+PSbmVIaiMLvMfrtIZCh3rS8ruAZpE+ZQzk9dfrLZbH/M9JHJbmwPq9vxGi2SVapZ6kqsU9xX9S7hDDzKm93LtGbgAcAnolUhhf8S9FGHu9g7lgJc6DC8PMTDaIuyDEKNVvMFVR9WIkC1WRIQx6Qx7iAe/LgEUy73lg6qLxe6gIKT17/wA1KgbeZfgH7z2gxPaECvUsqdRqE3Lq34ly9xCGGFAd9vULNbXuFR6y0hqGqU7gWWRZvdcecFE6DMcRF5ibGiLBpGvk6ZiBBg3KeZp7CCW4w733DLD0S59IKXEchT+sQasDVt7/ADLjKiaSKdwcwPvI7hq+4Wls7tuNAprwEtccQ7gRLwcXjzEA0RtA+YlB1EVvCwLuBiUx2ta7g1mJcf8AgRKyz9yXAshLpfJhm/NS1d6x8wAm1Z8ACiYkXeWOyQUp48AnlZ8y4/cljwXcx/PF4NB1LnEyen1n4n7MMh3wukTbwWXXJSkuBrcQtIFl+AEe/wB6/YUAeIbV4LJTDxVECkxDaKOBTUU75qbAz+IJ0eIaBW/MVSMYpOTkQbMuvqDXAKLfnYcbfYoFOvIB+xOEFeC+T7Mis8Yhvy95IcDL4PFS8xq8fTsVyt8om/AVeeRO419uplMplSpXFeJ5IQhyfY6+ALV1zbjREofp1K5qUymUymUymUymUymUymUymWy2Wy2Wy5bLZbLZbLZbE5EIQ5PsgmUSoA0cZhMiBcalR0+IHrNL8B0RQ0yuauVywF14g+kFVjEcXxW11+eVTcLHNQQslCk5uDCEOD7FQEt3+CBJtxb3ESSuOvwy1vfAUHcwivhA5luuv87lFTjIpI1KzHOZjU1jju+HAJpqL6R/AUV7xPHXJaUwHTErKc62WgMH5LuIKIl/AQRU49Ybrx+YmEEXweAC1cfGg3E+4wuqhGBmBYme6wNlfaDZlSjiWBTEcrDMRpRxaaZRKBa4xscRPnUPpzcsCwWkruXfDGO4j3KfpC0tIAY4w1h8wDIT2eMnAr1YroRmHI3O+CsbzCVRR4q4qVKlSpUAqVAzAqUrEplYwg4CN2p7E9CAmFZhFpPzNhRlxTNxFpYj7kHA0blSsohQC3KTNxLlZWVFuKskurpxvQgDWMQVjcECQ0KWekyTTG6PxDOof2ibv7ku8q/5+IdBVblnVQKgfZIhOvYYtKvtX9zFcF+kA6l4jF/fLUOfF1KOVG5+uZZ7olchUc8hUtfMuAblB5L47+hUoEMFcZ7lKsZqvEavEupXDmLCoEMrfvQmwnciU5p4vwN9fVv7SvtK+uC6iVwp35//AP/EACwRAQACAgECBAYDAQEBAQAAAAEAESExQRBRUGFxsSAwgZGh8EDB0eFw8YD/2gAIAQIBAT8Q/wDyYf8Att0xDX/jvPjdsOYbfRdcJxx0S83x6wYIghJ0yRlhInCpqYjW07Z04As6gLZhh8X0gKhnPWyR+7hsnTGuP1lmN7OuUvpSiTmJFsVXj/vaZjv/AOR7hCcQohyhSV/fOFQiPS9+D+2AkNd5keLOpsPNii5g3hf9mML+AW4IIOP3M0GnP05m4s0GnAgaHmXUfL7kwLLEOYIHaIF/SDlH97xlrUC+X7w2r4wn1EA0ajbv8yYgvpLaOPecCYewgznGfpMF2/SXbwFu0WGt3qKVpjStK6uJXZEI1ko2bj3aOgMwnjBoPOWTefv0n2SFlFbbEpg3tmizM21/XEdjzgm5r1jtHvNDAofOWK6IjDNes0PQ2O8Wh5niz3oB10wf0mJTYMAK7T2H9REO5mPn7sr+rF7XmWd/U3+szV5vX7RLnhv26Cuhp86OoDXijhdTDvIaD95Y/p9YLLECiCzystS8JFq3mWMs+fEt4faeSgqOGAgUP4gDUsTNE3TUBKysJFviCtuh2KqpeLOi4tyiOTMVlipbf77dLGmHMBx4hmPSI444j+TlAPOH+pmHrFnHSfImAjHNagJKyYi1XlqKqjLEsGu9ksSeU0x1M4/uYFMcEUxwv3/uWqdoeRfv594AWROIP1/yMU5NM1DTr/P3mBP93t9ZQp9f8+vtALHbOC8Q9v8AuJSbiecJVHJvpMZArG2oAQj9V6Q29009fWZx9kDRZQ3PT5iMPIjxsolbSJncvZgGdoyyNVc+8EVv++Znh9fX/sKxnGKGPENvp/cqVwIGJ+x+pMS85p+cqWcQzqY/DEAz3Z7ibITnqGaL8xNavzMY5j9JMX1RfPMDg5YLBojev7wChxcRQO39ytzggAUeI+0e5EMzc+WZAe/tMHNfznP6RKnj2gxuPabHZN/XPdTdLr7IkYjkbjzjj0o4D3Olif8A7AFv9eYsXGFYethUSjkzB+Ez8SEB3EStwGVGlWCehsqk5g1bvH4gYzLBg9oKUm784l+jBfoQz9k1z8Sf1zJzFV0TGVesV5ntLBp95YrZA7j8/wCTTZ+f8ilWbf3mDL4lTqfT9iZLQ+0PSFxnGggWABRC2gaQqHohBKmDRqCiollSt4xKhNkDWE/P+TQp+f8Aku5k7Rb1/k2t5RKzqXA4lgSnuR93xj0/MpKOvL4KrxjbNPyK+Ry6jfjO+a/j5qBVMyFa5lwDplNX8Ds8YWUjTLKlQwo1AwEf5jud/aFqmIghZECEcbftK/ZIWRUzAcOoHpsiDVFtq/D0ivC5gpTDLKICMr7ecRURQ1GalWqCeKUrzi1RlJcS8dkKMqfkh2Cqz/2ELW4+l3GyDBLORly4DWIzQQsxxHmYtcw1LpEKNROGItkIA1UsCHCWu6/pPSD9658owRqC34nUjysJhzxcdHSIsBKVeZSjiiCDov1lPMlP5XmYY595lUiTlNRLTscRhVqMMOeIh+iEpUlmUxRTsiFsTv7mbj+1DYV/3xPMI4bBF7y4MhKT+8+kv0YgKYgpEAhR4RxjiAN1Usk6v7wwyinGpVt2a9IP0Ma7dzCpEqGpylzvpQu6D/Y2sHaAUw7TPfmFbDMzWkG/EggiLcVL4ICgoefeFqoAoyqooNUDtQ+czoN1LMNjAbnVS6W6iCvEWi6uoBR5gO5cECK2xIC7jtavmAzsnNTJZVn6zJiJt2YD/ZnzOSQRosYN5IFeJbZukMHnzBFEEF5ijLxuVAil8IVk5z6RlTCE4LBzaOJgor+qiDniCVeziXZqOIYe8GQt5j07zhh2MyWIGGZMBkEJ5gXHoviBWG3zjjZ4S+DRCmsCJ9uOabYkyKxX1lDvyxpLYY7JBWd195YsNxlbcQ4YQr/1EiN6H6ZkVNgJVxL/AAllByRWiiLtsFgZgqW+JYXZYl2lXwhAIQVahMmpRUvMAsfSUu1hiLsllaxDnEJl8SqrL3ih7Y7Y9II5QdFxCF0SI7HW8SiEoOEavHiLKVFB76j+mU+BC2jSxgQdhESjUWSKqFdShhbiYFNxplMJphQolgzLDYYiU2a6U1DygWbecekqE78TQMMbNwGjKLOo1eNSolYiwhLcpxYkCB9F1mFyyrlSoZBErEYdGDjMoNsBVmZbfidQEJVZ6qC4ggypRMNdQxDYkLlFTCuerHKo418KruLziDAgLr5GRHwtVnqaWkemE8+mPgGtxqegSx84lHQF1NfBXPVt0kU30WmvgVvw157Me3UaltV018QpkiK34knLMMFaZfwbeJ4St6+EluJsMuv9+YKLUkIg/Bt4nr8R1r5y010Ftm3iesqVKlSofwUvrt8A34fp8Vy/kFXnXy95m+tdRv5Bf8e5cv5en8rf4Errhx/EuXLJZLlyyWS5ZLOmJjrUxKlSpiUSiGH+SRAWwjZLlr0xGBFz0tXZFl5r4D7CIjTL638KDD8Ssv4ly5cWogBQddLXi+qWVBRUuIpUTpX8dNQ1MaEM0RFRHDTHHQQbhqw6KmiZLmOgWcV0vrvpvqwIQfARM/IuXLlkGyWGsEGejt6RDpDTA8JVQFGEwuKlfBfWnfyNwTLlXGvnmnEJqAbgLglDHfC7phiwMroDUQIgbYWXDgSmoSPOUquglolpahKZCNWoHR4bN6NkK5mOl95hwYFHyr63M304gsFeZZBVxbcFL9JGmPkmBBzQld5UxUqiJFGopkiIXbeo5IYly3rcO659OgFDEVstqWwRN5hG/FTLzKHbMU6ZlXj0JhhitIXBL5pmY4UznoVCuZRf86y6+LNy3qXwMarz+Bh82up1GKuzHwHKNO+gRmoTDUflVX8O7iKiIqfiK+Wl9Ar+Jd+B3XQajnx//8QAKRABAAIBAwMDBAMBAQAAAAAAAQARIRAxQSBRYXGBkTChscFA0fHh8P/aAAgBAQABPxA1IdJD+Bz9Gv5zK0Yker36CEOg/hP06+lX8Fjq6Ojo6mp1Gh11K6q6jrqVq/x3VjoxjHU6zU+gddfNXRw/SxH+U6MdHVlaENDpIfWAINtLxXF39aut6n6z1OjL0NTpJz/Jr+a9Tqx6D6Jofwjpr+a6X0Ojq6n0SH1TqsXsGKWrv/Af4To/QfqkIdddB0VqfRr6r9Njq6Or0nQamhD6x11HYgljn6b0v13V6GMdTpIaGhDpwGCQqN8nbxcK4Whsmg/UCdKm6Hc94xDApKV2Th0VoucqbinLaAd2KAgLEbyIEDZg5E5NHqYkKu28le0eNzyQv+50Ho7/ADCwmxZhXZOGIOzCE7FqZi5fqiE7Gnc32fuYQRESxGx1pdtoXl7BzBm/3Boeo56X+O6Oj0Jo6mhqdJtDQjlIgJuZR50nCuSv6lgQKBiBTVK6T0jsb5dukBShYX7f9igKtBuxKNtZ4XD3W+8JyxEJaG/UBw/GgJxGXsC/yPiAXIcC2OHHMMtSNIL2RafDv3lgrMGFrmuB/cSrShwbruu2YN8LTcN+AGc+0G7OC7J65I6MsODRO2c37dpagy9gd1w/mBLJaJR2eHh+1R94V8ggp7tuKhCNrxK/lsY6Oro6mhoQ6K6CeKh90xEEoSBQx6v6iYb2g26ABTsXj1xBh9j8gjmlTY3pv4seqTC8rC6pMPSs+82RKZXqg+LLHzEE2CU7C7Pzj4lU1B5z41P3Ax6BEGdoplp2vtVwALa1yKR9z8wznpH/ALvLpAQCbbH4iFaTOxOHHZ9Yzy5rzhh57xgpHDZvf2+3psOd4OBaVCIQDYTBfdbX1m16XcNjb53+I5bfrsfouro9TqakOs6PCS+SIIbgfD/2WTeuGfYgAjOQz5SUkBad1+42iZ4gqlvff1jObbH3L97C/BAC54Tbte7R8y/2FChu1fk+Iz3EPNtQ/YYmCYLsMM/9F4/3HvJzPlhMmbkvdKHzkl0OFctTCgX2AoPibdDECwcV6JZMNn3gdtsRrIft8S7VVEunIOTuQillO7aL9lDXpUbEVWFprv8AN1AVoKD+U6uj0vQQ+kdG8yX+j/oiNJFwTG9V5jAgjfOd8sTCFqKAXgPc+JQxeS8iX7Xcr9QMvG4+7+IyZgLex7w6J02fzCaItBbN1qWkqC2EP2fuX28u+8CzN8F4zuJzHHZ9W+AyvN8by4v8r+oJ8V1YCpzSXCU3ulnyqyi4u7zEKph3Qo2Fi194+JT7hiZf4D0PU6MYxj0PQanUQ0IopA+WCFgp30Nez4hsfgg2TZ5cRaW7gE9psKpm+T8py+vurqljtMIDVgTL8fdi1C8lle77wPj9P6oqhIJnvQ2NmtmKh3XINifk9IH23yX+odruZ9tL2l1vD4IvZFB/stpJWqqMLx5Rf7IO3HXzAovL/CdHqdGMYx0Y6vSQ+gJ21NV7Jdg2c5lihcYiXeadGPfkQSsWjZcnnxEF8F2jdUd3FecxZWXDAaNeUPjo3KtYVXdu8ykcjnu9YM57RASWQYOHJV7P2nYSz8qgXRjO3FRd9gfuVbr0YPogOmBHHOGOYatgQNys03j5BuBoTfa+2P6lY1rlZbz8QowIhzQ7LuDmVgWjDsLBe9O0YWsYIf2Yp94p4AVFnLaYoi0WsyL02S1mtCQpgvNP9oDG0R5N/hGrLgMCtO4rvKSB6jFvA8MIZZD/ANvLm1sih3BbopWKhRAvwSet0et6mMSMdHR0Yx0NSHQakTZbl8H+os2PBdt4yPBFOtuzA7duMbMv+lePfn5hERf4T/aMutN7iv8AqOBukkwebkHBvKomMLQbyfgGHyzLSrkQNwab447RXeiHgJvZNHm9rmKTdkGaXc22lAuKqq/BWZhhWJm1tl9p5m3eJFNyv5RBIlAwSoKxdTBx2hg88iV8lgIK0mBfsDfpZCAyRxlI2Js/JBN6gttT+o1IFZOK7wm7fOG5Twp+XiBtyqBqzS9v6lqp9Y8/uZT3I1UcAmy8+34ucozmwf6YcrF6JQsv3XyspPSmDtn6L9ZjGMY6OjHU6CEIQhoTd1v+MZKdCRW1fMFsuIZFZl7uMSxRFu24fse8X/gYT+4Mzj7bZUQXej2kJvKwFU+aiHxRoOxyvo0eI35OQKv3V+Ivn5GPy/KKj7L8v6lWN1yyzj0puWJiICVKMHrKFMLhs2n72e0siNn8/wBTdN1/sxQ97hYzaFat4Dizx3IsNRXK3dHtSelRopQfsLq+6YmE93BkBgPTjzFRQkGHcTD/ANiZU5MX+ht7QzEvU5n4dzw+JjFgUSm08sP+8/ESld/4Kdbo6PQx1Og0IQhDQL/6MolwZS5nxZ2gwiA/DLbT4fmMXqOc0yJ/7mXtVCP3iu7jfKfqWLhXEnwoVWyUAPetyNqkLT7b4h1+IFTLwSHB5/JL2PCBoZW6KqOObf4jYg4XD2wYfWocPkATcr1jAduTvaH0Q/F/3ofgtB7JmWeW9d6aflma86O5ZT5qbRS7tw937EaEsx4UZrxTfshgocOWBsd73F9mE5Zwdyj4zFbxwdvrv02OjHR1dDUhCHV/7nfFMbAMsL2uYzb4Y72OP3EIlVinOn2ZU5c/vP6lXhPv/wAxkaAkuQCfC0fKX61K8QpKdmz6J9mACUsdo3ianb8pNj6vum87QEyAoWeXMwspdpvMr0NutUWq+9+0p25EPD5Pf9iCrrCH3JvDcihw5zwG3dqYDN3AXl5d31jygKHi9vsEoMrSgVsVW04T9is3c4v4i29kz5DMsJb5Hnditv8A0v8Ar+K9DoxjGOro6GpCEOg0ArrNmrEbX4ZZivxg/ESIPMba7DLGFN1bu/8AXr6Q1bihc2wfYTlqJNrtf5PmFjNYy2untlfiPcdATluPs0wydlG+1J359R8StlnYJQV994ueOHdWpaQbB6f6jEdm32yn7lBTvL6LT8zCvhK5Gj9GLZcYDzCkQWIdkS264C9PxAC112Nvtdwa2ZNu/neNRgVTzM16d/iECKh0F14b/uWpbv8A9BIo0NvdYRWCoCHhqYR2v0mWx3V/63j8CXez/f1XpdXpdGOjqxjoaEIaENCGg3TYaDxfp3gAlyYrD94wS7kT4cQoJAcE7a8I02R4axHOiAuB/YQXB9WC+L7RStj9FBZHbZ9fMvFbHYhxQIUwjdPx+YjxYOPgNo/PEm8DY/JFbdmDa7t7eJk+NoWyi03QifchRuEsKeedjeU5UotxtTtw+0KC7QE8CD8w8Cr29zZMB4fdtPdo/ELBKwFasdkHI7wQDJsboDB7fuW95bbGTlU+VPDZZ/yBwio2ly0H4/5HCdOSr/hsY9Loxj0upCHQQ6CHTg/b95Hd0H0DG3Q140HK5nMSub9NLXd+lf0Hoel0YxjpejL0IQ0NTqNSYP2/JHf6CFjIp40vpcECd3ph3l+haLoLY7V9wr+A/QdHRjGMehj0nSamprZQvLsQ1bivxIM9Oc32xoL89q8Es+LG8K34iOmjPKPsD5JTWGHmZwYbg51yH0iId3VYxYePqur9NjGOrqxj0kNCGpCExBexhteL7RdkGVlX4dozSKAqke1R8ibIwUN2AsYqwRC7Dll728RCXkCtk/K18EpawNlujvCSMBS7I8feIYzpBlL2TRZDws2/2ZxTGHIGz3gY+cNobZgmiKN5+DxUTOjkKDcsjfUL1QGreL3xiMJoL9mcq3CSnSd7eMJnJuS1lUpFLFzisfclSn0NjH4h2tCxtY7fiHKUb0a+blkcwIm/oQZkQyFyisL2iI046HrfoPS6MY6MZeY6MdDUhodJCLyLbFbMB7/iWNMuVintfnxKUq4eFe97RpkWV8Dx5iZwBEafWb2JMLCmDx+53Iit9KXsq8xAEFW3HyR8rSR2epMmi1qbDsDL8jlhitrfmIw0F7X9TO8AN028NRM7EJk5KmfhgI5PJzKyiYjFvxzEULq2zsXPibcKfLaXRxh1BfB2P7hsAOzuPaXIGBvT633jTVviiTds8wOQErApXwdvSCBuBF24H2Cx01RilMh2jJAoIWzvexKjqWgHHQ9Dq6v03RjoxjHR1NSGhqQhCUOFkFWvB53ivC9gFFa4lu9qUFLQrbSKEHkc7RKO4paDXqo/MTbVU4BSHoy5wF6q6feqjyoIUwxlzFEfAWhe75i+0QGxozSNCECOzxAb1Dc45G8+kRQKoeWCIhkDcDRYKxNoGsMoUuyr4hcAMl7+8KmFKIbq3GNOroTNa/v3hsBhZbTjDykSzT3dYOaf1CNoskaXnHVhwj8LyBwLwscKMjbFkLldERcjbKcgCzezHvACFZeHV+u9To6PQxjpcIampoQhCEpBc0nFB3pc8StEgj2l22ecwaAiHC4wcG0TLUCgKM97UYFRbo2N0UcObgpyZplH418R1WBDVKFWeH9S56q5p2bJbMoArUVErxvcpaB2qorKHOIaiYl7CjL7tEYLRKyFw58UsQxEEwAMP9ysFlklXeM758kuk5JlWlB7senWBA7Z+8Zv/c2TtcGqicDQbh0rWbdXMYZITXPtCCi2mV+M+KlSRexO0p9JU7OaRsZFVu8KPEmrvWG+C8QeSNCs7XyRx7KYcNqhdoj/AAXV1Y6MYy9GMYsZehCENSGhDTCUtVQur9YIqarFHG7vtctALFyhVjLzmKlpggIub7Zg5ALnBcLRFWxZayW2+xBkECUBfPEqaHAAGs187R8j+qVYjGOrRNKVbG2XH4I013/7EiAVSUFgEXp28NL2/EVaMOIjvntmO2ZB4bbxBaALvy94yaZJwgbhC6MCHMMUs7p4/wBjSLSyFRMZswkGFBba58k2CpvjeC19tRDsrIVnqi8/JYLE7SmBlWt3tLM4PHPt0uj9d6GMdHVjL05hDQ0uGpCXA8sMi65ZVBwGqwcpwdpx16eRgv1ZdKADMHD4u5ZLkFIi2r1g11Y3Zb9I94yq2JkXtQe8oS8of9moptIjZHL9wlqIGgq6/pmbzbmbPGecOfMwnBq2392C9hQWBwUypG9eMtgfD8wErmtdu2exMRhbPhjIge0FnZeJVw1T2HF+0CLATgg8S0oQV82Rw24O1o8VxtCiDBlcD3jbRhR2PT3i3ii7jATGNRvak9dmX5GK1Y/UsEC1yEW5cnBzoGNg+YKf4jL0YxjHR0dMQ0NDUhoQhC2J7IqykLwePBfkqZLPA5LgVbIWaL/qXo23jgp7b/Md5ugqNmU7OIDg2TKgYHr+/ESpIrK1gt3oPvA4ADvTLb1/cWKamW/mGqq2VTad4bkMsAd+YGKS9rsRiBRWtxcWRwO1u4MT7bBK2kurMFOE9d5b70QMfa72fMoyNIDFVfaOlohyxA5EvDbTzN37ZFV7+hBy6y/+ekwoJk4esIYB5eJXYUVUI/1MJUYJAb3uQaRQIHGNBqLero/RdXodGMd4xdFjo9BoOhCGhCEXIUR93+40kQtG7DVr5eI/fjh+XpxAQHcngNiBnMKShe529IhsCsi4ZtuBNl4gSbAoALC3HtMUPCwG/dg0QLVcP7iEK6MT5zaOwpGKJtsZ1V8QCU4aVdomjA24ibZTJk94UCZBoePSMcKSMLWPvF+8bsx4BxxxB9L12wJudU5oYHgI9hvKpoxUDUhWCt2WFgNkgvvUpeqW2PLvGgo0A0WUX6zdtgB6uNHqdLjHodHR0Y6OrLi6mh0EIbwhE8F2BORUfoGUWYbTYNWe8vgHkC+2JbDYx5HDbxG3Nu7tiXYEoC0WbnabAkVms0A8NfMqvFLjD2rvD+ZLRyxVhDY71Ke+Rp95mUNo78wsr7PoSnuIHXOWUSAwy1hz/wCJQ0Kcis0MaAebiIA3z0G7DYiUdWYYgsHJhQmYJS6o8iBuJS49IHp4LylX+ZWaCC23tKWra8fRdHVjpejq6sdHS46Oj0XBh0EIMISoiumzPevSZc4l4U7MqRuiKsTCJfX5fpGdEmza4HFkZD8kI1VNyuuNGtyb3Fr3AB9oR+Sj8koMVzpyQphsQKFmyGwpYl2yzuvvAr9QLtS+cfeKUfUETFu4FY82LQXViGlI2qZcDtMslNoKTgfuOwqWFW6YuG2MKS7I0Vd6u1wX8AszcWEQbCljhS7+o6MdLlx6LlxjHoZcY/RuGhvCEI37QHC9oEuNEHH4lgdtY7VAQA2DaCVBQcYY2CY29eY2Aw1hm7bWzdLBQcq4ltzik7wXQG2FnjyeJhiYKcL+vRgo6bJGKIHNl3FYveVNyIDDR3zvDlK2t1sxHMUi3d5mCIjQIgJT+j1gHdmKPvCQwnY7Qsl7im83PRehBXgeTW+hYvRejrerGXLl6MY6GpqaGhBgxh5cuHpTzBdybu7drhjEuBQKcTeK2ETMfQhI90R2YFQ0oh3IRiLaETZp+zBpltkIXMUq6u/U5mcVnLzjw/pzDMaAUHbwyqJU022uD2XolQo0mi5CXvV5hpaeFZlEA14mKHgCF3EqpTzCztto6YeC68y4uNXW5cvodL0vR0YsdXR6bhL0NDQYTcp2Yra/oVefeVCi1tRsZcIywGd3mCtDfeMBjF5lQtAt8TeN4VLCXW8NBuxAJNxMMMjLYILgtzYx9YVRDwaibmd6jljrsTcjAB0Fq3Y1rdBXqi5dbssX6dxjox1ZcuXLlxjo6seg1NTUhCCy72RLSo4EqEGGghtDYjJvFLF45gBgCXrHom9LsHGgMwLgaE5qBjWgDQ50EndTy6NqH6jLjq9T0ujqxnGpOdCXqaGr7lii1boi7uDmUTW0scp3TmUFlorMDEN+kQamqKKvgxZxc3hd2MG0/A1four1O0ehjo6PS6nWQjiQFVyHEIRV/wCu0o8xKi9o4ZxL1tKnaJHOlQM9Lu79b4KcSoGxtp+BqFtRsBvt50vRlx0dGOq6MY9Dox0dHRj1XB0NCBm4Qhy9j+GOPEceZaeUgxkSb5GybYTmGixiAYFMJxCAo0zUIfQ2vREpd3jtpdQQFWttaQU7x30Zcrg8XM1nfQpFjvVwsOKIp0dHpdF1Yx0dGOnlfE8r4nmfE8z4mDd8TwPxDsPxDuPiU9mA9oX2hfaE3NbJ+dB9OhiImVLApUQ8w2mRqmIQ+jbBDZun4mb20dmwWesz2me0Jcg2DYiFIjKe0b7TPaU9oj2lPZlPZiPaU9n4ngfieR8TyPiPcfEs4fieR8R/5k/zJ/mT/On+dP8AGn+FP8af40/wmf4U/wBJP9BP8Rj3H5iXL8x/7EYh/wClP9uP/RT/AGU/20/00P8AppX/AGof91AwHZdcUc2amyKZG7iW2VYx48TZq7kIfRFiu8GobEUBc3KdoWKC96N4rxEOye8qWVKktcsQhL5TmV6QADVb2E3BxxFQrRFeBVf39pUqJAHiws0d7hNh2jkmy6x3lSoPALjRpJUY2Ss437SpUrRUqVKlaPRFxk9qV2hfFx9ssBu8sxlm8ruMWZ9xT5K294C637xLfeWDBmLY1oAq3V/qBim0WzFlSDuwwkG7IfeJgBqOLRshgG+DKUODJ2myOr3g4+itTNFgB2DmNltrKO7MAKtd5ipbrlXYhWNA7ZlDVNztEgyUKvJIDAaLCs3oWH91TcVETKxYODj0gcEFIYSFpTYy4Jdzx6QGzZ2iAA52QzKEwAKoKhVrJ7Qakp3N6AUB5Sx3K5ghSS3niNorG80x22UOw8SzDtVFJRGxxtHkF+jCFFqXY9nrEpR4lSpXQntEdo9tQ+49VJu6RDPc2llDszB7wDeAuKFi/Ed4L3q4l5ZXgPOYr2lFO4RE89rlSbo3LSublW1lYy+YGW1UbDyd4zqbarOLCVy7A7fePWx2oMImRHmYLiPmUhgLmCy+NCgJuRRajcGbGWpSoU2ZhuQRm0t7wC/XGPhdPe/CICu5pNpbHHuJiKWzZcQJPqkdmFXkk4HvLirZ5HrUbwnhu2+IHVm1mbcTCwQLBlajwkF4BMR7pRWaiQQWdzU31lBN0igMUEVs+twFodsBQVvywqqlKC1PELEIsGmUZVyySphqzYgUMrNsxCgrUTBuwxTvWXvACsUz2SrC4XiVDNjapVMQxV0uHvo4B3CA8ysouSmna+0vw8apdvSBlse4RBLBy4wPrA0IQWzblHHaE1IzSrdalTEwlJlK69Ztm/XocSkDVe6b2I2+ULQq4Cgtuqa+IchnvF2maB8w+YEZQeGMxtUO3aUwNzYZdvKJGNCWwGY8Zx6kDCLFjh8rCEw0Ah5WsEpGIKN2GWKJI71ObiLU1tVOYuUA0VN+dsSk/udlc/bMtt80AFPQv7wQBKwgvxMbetzPMJw1ZPiEbhglPsEvpUKaRcUKV+/+4DWONmUEMX5uAeB2iDIX2mEPllT7bS/M3WlK8wsv/Ox8QcKHdXwGVBGNhhfrBZfMIr5QSrhXBghVF0puQ8mLt3vbaVkhj1psuiDiaLwPTv3ijYBtweuIJAJaAbb5940NDnMzAtOtbUKltpckcFgeOM8Zz2ZwseAfSmCnhG+ZUdIhkLeI5sa5LL/cbWoZBa+h9MBQo0qVrWlQjrUrovzERm0smtysDW/3hZBszvFN3PklKAB2JcOpdyRejzMjMnLm5awjfJMc59YtKc+stKCc0uclNBx30XLYQAzHrUZynuuvUlDnZlgekXtmXLly4syLl+ZcV4iy9ByJfJHrGXs9m0BhQAoA0M3QOyMfdJEmRmLQhRuA7YJVxVpWSf8AUaKKRk7SlikzeOYyXmXGAUZQ82V3gAG30agUVn30z9LnqQdyybkbBi/Eqztq3vCw5wOZQlJcMA2Cg7aDLImFJ7XFt7ekINbS5cuXLly42lDXmXLrEuXL0uPVcvrro3+lXS9NaV1bQzFDeCOC/SKVJTKwzsLhwwbAUfRvS5cuXrcuXL1v6nPR46c63t/A/9k="
                                      style={{ height: 100, width: 150 }}
                                      onClick={() =>
                                        openEmail(result.justName, result.id)
                                      }
                                    ></img>
                                  </DefaultButton> */}
                                  &nbsp;&nbsp;
                                  <DefaultButton
                                    style={{
                                      height: 100,
                                      width: 145,
                                      borderRadius: 0,
                                    }}
                                  >
                                    <img
                                      src={birthdayImgData}
                                      style={{ height: 100, width: 150 }}
                                      onClick={() =>
                                        openEmail(
                                          cardParam.context,
                                          result.justName,
                                          result.id,
                                          birthdayImgData
                                        )
                                      }
                                    ></img>
                                  </DefaultButton>
                                </div>
                              </Stack>
                            </Stack>
                          </Stack>

                          <div className="carouseldot_main">
                            <div className="carouseldot_container">
                              <div
                                className="carouseldot_activeCarousel"
                                style={{ marginLeft: 6 + 14 * i }}
                              ></div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ol>

                  <aside className="carousel__navigation">
                    <ol className="carousel__navigation-list">
                      {cardParam.birthDayArray.map((result) => {
                        return (
                          <li className="carousel__navigation-item">
                            <span className="carousel__navigation-button"></span>
                          </li>
                        );
                      })}
                    </ol>
                  </aside>
                </section>
                <Stack>
                  <div className="viewAllcontainer2">
                    <a
                      onClick={() => openViews(2, cardParam.birthdayView)}
                      style={{
                        fontSize: 12,
                        color: "#053c6d",
                        opacity: 1,
                        textDecoration: "none",
                        cursor: "pointer",
                        marginRight: 60,
                      }}
                    >
                      View all
                    </a>
                  </div>
                </Stack>
              </div>
            </PivotItem>
          </Pivot>
        </div>
        <br />
      </div>
    </div>
  );
};
