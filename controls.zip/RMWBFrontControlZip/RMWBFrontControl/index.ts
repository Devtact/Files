import { IInputs, IOutputs } from "./generated/ManifestTypes";
import DataSetInterfaces = ComponentFramework.PropertyHelper.DataSetApi;
type DataSet = ComponentFramework.PropertyTypes.DataSet;
import React = require("react");
import ReactDOM = require("react-dom");
import { ReactSampleTextBox, IState, cardParams } from "./indexHTML";
export class RMWBFrontControlTest
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _context: ComponentFramework.Context<IInputs>;
  private _container: HTMLDivElement;
  private props: cardParams;
  /**
   * Empty constructor.
   */
  constructor() {}

  /**
   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
   * Data-set values are not initialized here, use updateView.
   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
   */
  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    this._container = container;
    this._context = context;

    this.getActivity(this);

    // Add control initialization code
  }

  /**
   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
   */
  public updateView(context: ComponentFramework.Context<IInputs>): void {
    this._context = context;
    this.getActivity(this);
    // Add code to update control view
  }

  /**
   * It is called by the framework prior to a control receiving new data.
   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
   */
  public getOutputs(): IOutputs {
    return {};
  }

  /**
   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
   * i.e. cancelling any pending remote calls, removing listeners, etc.
   */
  public destroy(): void {
    // Add code to cleanup control if necessary
  }

  public getActivity(self: RMWBFrontControlTest) {
    var userID =
      this._context.userSettings.userId.replace("{", "").replace("}", "") ||
      "a";

    var userTimeZoneOffset =
      this._context.userSettings.getTimeZoneOffsetMinutes();

    var todayDate = new Date();

    var year = todayDate.getFullYear();
    if (todayDate.getMonth().toString().length + 1 > 1) {
      var month = (todayDate.getMonth() + 1).toString();
    } else {
      var month = "0" + (todayDate.getMonth() + 1).toString();
    }
    if (todayDate.getHours().toString().length > 1) {
      var hours = todayDate.getHours().toString();
    } else {
      var hours = "0" + todayDate.getHours().toString();
    }
    if (todayDate.getMinutes().toString().length > 1) {
      var minutes = todayDate.getMinutes().toString();
    } else {
      var minutes = "0" + todayDate.getMinutes().toString();
    }

    if (todayDate.getDate().toString().length > 1) {
      var date = todayDate.getDate().toString();
    } else {
      var date = "0" + todayDate.getDate().toString();
    }

    var newDate =
      year + "-" + month + "-" + date + "T" + hours + ":" + minutes + ":00Z";
    var newDateFilter = year + "-" + month + "-" + date + "T00:00:00Z";

    var nextDate = year + "-" + month + "-" + date + "T23:59:59Z";

    var arrayVar: {
      heading: string;
      startTime: string;
      endTime: string;
      accountName: string;
      joiningLink: string;
      id: string;
      modeOfMeeting: string;
      location: string;
      editLink: string;
      date: string;
      appointmentID: string;
    }[] = [];
    var birthDayVar: { name: string; id: string; justName: string }[] = [];
    var birthdaystatus: boolean = false;

    var guidA: { guid: string }[] = [];
    var queryString: string = "";
    self._context.webAPI
      .retrieveMultipleRecords(
        "icici_configuration",
        "?$select=icici_name,icici_value&$filter=icici_name eq 'RMWB_PCF_IndividualBirthday_ViewID' or  icici_name eq 'RMWB_PCF_MyAppointments_ViewID'"
      )
      .then(
        function success(results) {
          for (var i = 0; i < results.entities.length; i++) {
            var icici_name = results.entities[i]["icici_name"];
            if (icici_name == "RMWB_PCF_IndividualBirthday_ViewID") {
              var BirthdayView = results.entities[i]["icici_value"];
            } else {
              var AppointmentView = results.entities[i]["icici_value"];
            }
          }

          var queryforYearcondition = `<condition attribute="birthdate" operator="on" value=" ${
            new Date().getFullYear() +
            "-" +
            (new Date().getMonth() + 1) +
            "-" +
            new Date().getDate()
          }" />`;

          for (var i = new Date().getFullYear() - 1; i >= 1930; i--) {
            queryforYearcondition += `<condition attribute="birthdate" operator="on" value="${
              i + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate()
            }"/>`;
          }

          var fetchxml = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
          <entity name="contact">
            <attribute name="fullname" />
            <attribute name="telephone1" />
            <attribute name="contactid" />
            <attribute name="fullname" />
            <attribute name="icici_birthdayistoday" />
            <attribute name="birthdate" />
            <attribute name="icici_salutation" />
            <order attribute="fullname" descending="false" />
            <filter type="and">
              <filter type="or">
                ${queryforYearcondition}
              </filter>
            </filter>
            <link-entity name="account" from="accountid" to="parentcustomerid" link-type="inner" alias="al">
              <link-entity name="icici_organizationdetail" from="icici_organization" to="accountid" link-type="inner" alias="am">
                <filter type="and">
                  <condition attribute="icici_rmuser" operator="eq-userid" />
                </filter>
              </link-entity>
            </link-entity>
          </entity>
        </fetch>`;
          fetchxml = "?fetchXml=" + encodeURIComponent(fetchxml);

          // var queryforYear = "Microsoft.Dynamics.CRM.On(PropertyName = 'birthdate', PropertyValue = '" + new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate() + "')";
          // for (var i = (new Date().getFullYear() - 1); i >= 1930; i--) {
          //   queryforYear += " or Microsoft.Dynamics.CRM.On(PropertyName = 'birthdate', PropertyValue = '" + i + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate() + "')";
          // }
          // let currentUserID = self._context.userSettings.userId;
          self._context.webAPI
            .retrieveMultipleRecords("contact", fetchxml)
            .then(
              function success(results) {
                if (results.entities.length > 0) {
                  birthdaystatus = true;
                  for (var i = 0; i < results.entities.length; i++) {
                    var contactid = results.entities[i]["contactid"];
                    var fullname = results.entities[i]["fullname"];
                    var icici_birthdayistoday =
                      results.entities[i]["icici_birthdayistoday"];
                    var icici_birthdayistoday_formatted =
                      results.entities[i][
                        "icici_birthdayistoday@OData.Community.Display.V1.FormattedValue"
                      ];
                    var icici_salutation =
                      results.entities[i]["icici_salutation"];
                    if (
                      results.entities[i][
                        "icici_salutation@OData.Community.Display.V1.FormattedValue"
                      ]
                    ) {
                      var icici_salutation_formatted =
                        results.entities[i][
                          "icici_salutation@OData.Community.Display.V1.FormattedValue"
                        ];
                    } else {
                      icici_salutation_formatted = "";
                    }
                    birthDayVar.push({
                      name: icici_salutation_formatted + " " + fullname,
                      id: contactid,
                      justName: fullname,
                    });
                  }
                } else {
                  birthdaystatus = false;
                  birthDayVar.push({
                    name: "No birthdays today",
                    id: "",
                    justName: fullname,
                  });
                }

                Xrm.WebApi.retrieveRecord(
                  "systemuser",
                  userID,
                  "?$select=internalemailaddress"
                ).then(
                  function success(results) {
                    var email = results["internalemailaddress"];

                    Xrm.WebApi.retrieveMultipleRecords(
                      "activityparty",
                      "?$select=_activityid_value,activitypartyid,addressused,instancetypecode,participationtypemask&$filter= (participationtypemask eq 7 or  participationtypemask eq 6 or  participationtypemask eq 5) and  addressused eq '" +
                        email +
                        "' and scheduledstart ge " +
                        newDateFilter +
                        " and scheduledend le " +
                        nextDate +
                        " &$top=5&$orderby=scheduledstart asc"
                    ).then(
                      function success(results) {
                        if (results.entities.length > 0) {
                          for (var i = 0; i < results.entities.length; i++) {
                            var _activityid_value =
                              results.entities[i]["_activityid_value"];
                            var _activityid_value_formatted =
                              results.entities[i][
                                "_activityid_value@OData.Community.Display.V1.FormattedValue"
                              ];
                            var _activityid_value_lookuplogicalname =
                              results.entities[i][
                                "_activityid_value@Microsoft.Dynamics.CRM.lookuplogicalname"
                              ];
                            var activitypartyid =
                              results.entities[i]["activitypartyid"];
                            var addressused =
                              results.entities[i]["addressused"];
                            var instancetypecode =
                              results.entities[i]["instancetypecode"];
                            var instancetypecode_formatted =
                              results.entities[i][
                                "instancetypecode@OData.Community.Display.V1.FormattedValue"
                              ];
                            var participationtypemask =
                              results.entities[i]["participationtypemask"];
                            var participationtypemask_formatted =
                              results.entities[i][
                                "participationtypemask@OData.Community.Display.V1.FormattedValue"
                              ];
                            queryString +=
                              "activityid eq " + _activityid_value + " or ";
                          }
                          var newQuery = queryString.substring(
                            0,
                            queryString.length - 3
                          );

                          var appointmentfetchXml = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">

                        <entity name="appointment">
                        <attribute name="subject" />
                        <attribute name="statecode" />
                        <attribute name="scheduledstart" />
                        <attribute name="scheduledend" />
                        <attribute name="createdby" />
                        <attribute name="regardingobjectid" />
                        <attribute name="activityid" />
                        <attribute name="instancetypecode" />
                        <attribute name="subcategory" />
                        <attribute name="statuscode" />
                        <attribute name="sortdate" />
                        <attribute name="slaid" />
                        <attribute name="requiredattendees" />
                        <attribute name="icici_reminderforrm" />
                        <attribute name="icici_reminderformanger" />
                        <attribute name="overriddencreatedon" />
                        <attribute name="processid" />
                        <attribute name="prioritycode" />
                        <attribute name="owningbusinessunit" />
                        <attribute name="ownerid" />
                        <attribute name="organizer" />
                        <attribute name="optionalattendees" />
                        <attribute name="onlinemeetingtype" />
                        <attribute name="onlinemeetingjoinurl" />
                        <attribute name="onlinemeetingid" />
                        <attribute name="onlinemeetingchatid" />
                        <attribute name="onholdtime" />
                        <attribute name="modifiedon" />
                        <attribute name="modifiedonbehalfby" />
                        <attribute name="modifiedby" />
                        <attribute name="icici_modeofmeeting" />
                        <attribute name="icici_meetingresponse" />
                        <attribute name="icici_meeting" />
                        <attribute name="icici_longitude" />
                        <attribute name="location" />
                        <attribute name="icici_latitude" />
                        <attribute name="lastonholdtime" />
                        <attribute name="isonlinemeeting" />
                        <attribute name="formattedscheduledstart" />
                        <attribute name="formattedscheduledend" />
                        <attribute name="exchangerate" />
                        <attribute name="scheduleddurationminutes" />
                        <attribute name="description" />
                        <attribute name="transactioncurrencyid" />
                        <attribute name="createdon" />
                        <attribute name="createdonbehalfby" />
                        <attribute name="icici_checkinlongitude" />
                        <attribute name="icici_checkinlatitude" />
                        <attribute name="category" />
                        <attribute name="icici_businessarea" />
                        <attribute name="isalldayevent" />
                        <attribute name="icici_addresstypeappointment" />
                        <attribute name="activityadditionalparams" />
                        <attribute name="actualstart" />
                        <attribute name="actualend" />
                        <attribute name="actualdurationminutes" />
                        <attribute name="activitytypecode" />
                        <attribute name="stageid" />
                        <order attribute="subject" descending="false" />
                        <link-entity name="account" from="accountid" to="regardingobjectid" link-type="inner" alias="aa">
                        <link-entity name="icici_organizationdetail" from="icici_organizationdetailid" to="icici_organizationdetail" link-type="inner" alias="ab">
                        <filter type="and">
                        <condition attribute="icici_rmuser" operator="eq-userid" />
                        </filter>
                        </link-entity>
                        </link-entity>
                        </entity>
                        </fetch>`;
                          appointmentfetchXml =
                            "?fetchXml=" +
                            encodeURIComponent(appointmentfetchXml);

                          self._context.webAPI
                            .retrieveMultipleRecords(
                              "appointment",
                              appointmentfetchXml
                            )
                            .then(
                              function success(results) {
                                for (
                                  var i = 0;
                                  i < results.entities.length;
                                  i++
                                ) {
                                  var activityid =
                                    results.entities[i]["activityid"];
                                  var editLink =
                                    (<any>self._context).page
                                      .getClientUrl()
                                      .toString() +
                                    "/main.aspx?forceUCI=1&pagetype=entityrecord&etn=appointment&id=" +
                                    activityid;
                                  var icici_modeofmeeting =
                                    results.entities[i]["icici_modeofmeeting"];
                                  var icici_modeofmeeting_formatted =
                                    results.entities[i][
                                      "icici_modeofmeeting@OData.Community.Display.V1.FormattedValue"
                                    ];

                                  var location =
                                    results.entities[i]["location"];

                                  var actualend =
                                    results.entities[i]["actualend"];
                                  var actualstart =
                                    results.entities[i]["actualstart"];
                                  var createdon =
                                    results.entities[i]["createdon"];
                                  var _regardingobjectid_value =
                                    results.entities[i][
                                      "_regardingobjectid_value"
                                    ];
                                  var _regardingobjectid_value_formatted =
                                    results.entities[i][
                                      "_regardingobjectid_value@OData.Community.Display.V1.FormattedValue"
                                    ];
                                  var _regardingobjectid_value_lookuplogicalname =
                                    results.entities[i][
                                      "_regardingobjectid_value@Microsoft.Dynamics.CRM.lookuplogicalname"
                                    ];
                                  var scheduledend =
                                    results.entities[i]["scheduledend"];
                                  var scheduledstart =
                                    results.entities[i]["scheduledstart"];
                                  var subject = results.entities[i]["subject"];
                                  var scheduledstartTZ = new Date(
                                    scheduledstart
                                  );

                                  var scheduledendTZ = new Date(scheduledend);

                                  var currentDate = new Date(newDate);

                                  var utcSS =
                                    currentDate.getTime() +
                                    currentDate.getTimezoneOffset() * 60000;
                                  var finalSS = new Date(
                                    utcSS /*+ 60000 * -userTimeZoneOffset*/
                                  );

                                  var nextNewDate = new Date(nextDate);
                                  var utcSE =
                                    nextNewDate.getTime() +
                                    nextNewDate.getTimezoneOffset() * 60000;
                                  var finalSE = new Date(
                                    utcSE + 60000 * -userTimeZoneOffset
                                  );

                                  var Starthours = scheduledstartTZ.getHours();

                                  var Startminutes =
                                    scheduledstartTZ.getMinutes();

                                  var ampm = Starthours >= 12 ? "pm" : "am";
                                  Starthours = Starthours % 12;
                                  Starthours = Starthours ? Starthours : 12; // the hour '0' should be '12'
                                  var minutesNew =
                                    Startminutes < 10
                                      ? "0" + Startminutes
                                      : Startminutes;
                                  var strTime =
                                    Starthours + ":" + minutesNew + " " + ampm;

                                  var Endhours = scheduledendTZ.getHours();

                                  var Endminutes = scheduledendTZ.getMinutes();

                                  var ampm = Endhours >= 12 ? "pm" : "am";
                                  Endhours = Endhours % 12;
                                  Endhours = Endhours ? Endhours : 12; // the hour '0' should be '12'
                                  var minutesEndNew =
                                    Endminutes < 10
                                      ? "0" + Endminutes
                                      : Endminutes;
                                  var endTime =
                                    Endhours + ":" + minutesEndNew + " " + ampm;

                                  if (
                                    scheduledstartTZ >= finalSS &&
                                    scheduledendTZ <= nextNewDate
                                  ) {
                                    var arrCount =
                                      "appcarousel__slide" + arrayVar.length;
                                    arrayVar.push({
                                      heading: subject,
                                      startTime: strTime,
                                      endTime: endTime,
                                      accountName:
                                        _regardingobjectid_value_formatted,
                                      joiningLink: "a",
                                      id: arrCount,
                                      modeOfMeeting:
                                        icici_modeofmeeting_formatted,
                                      location: location,
                                      editLink: editLink,
                                      date: date + "/" + month + "/" + year,
                                      appointmentID: activityid,
                                    });
                                  }
                                }
                                if (arrayVar.length > 0) {
                                  self.props = {
                                    multiData: arrayVar,
                                    value: arrayVar.length,
                                    status: true,
                                    birthDayArray: birthDayVar,
                                    birthdayStatus: birthdaystatus,
                                    context: self._context,
                                    birthdayView: BirthdayView,
                                    appointmentView: AppointmentView,
                                  };
                                  ReactDOM.render(
                                    React.createElement(
                                      ReactSampleTextBox,
                                      self.props
                                    ),
                                    self._container
                                  );
                                } else {
                                  let arrayVar: {
                                    heading: string;
                                    startTime: string;
                                    endTime: string;
                                    accountName: string;
                                    joiningLink: string;
                                    id: string;
                                    modeOfMeeting: string;
                                    location: string;
                                    editLink: string;
                                    date: string;
                                    appointmentID: string;
                                  }[] = [];
                                  for (var i = 0; i < 1; i++) {
                                    let heading =
                                      "You have nothing scheduled for today";
                                    let id = "appcarousel__slide" + (i + 1);

                                    arrayVar.push({
                                      heading: heading,
                                      startTime: "",
                                      endTime: "",
                                      accountName: "",
                                      joiningLink: "",
                                      id: id,
                                      modeOfMeeting: "",
                                      location: "",
                                      editLink: "",
                                      date: date + "/" + month + "/" + year,
                                      appointmentID: "",
                                    });
                                  }
                                  self.props = {
                                    multiData: arrayVar,
                                    value: arrayVar.length,
                                    status: false,
                                    birthDayArray: birthDayVar,
                                    birthdayStatus: birthdaystatus,
                                    context: self._context,
                                    birthdayView: BirthdayView,
                                    appointmentView: AppointmentView,
                                  };

                                  ReactDOM.render(
                                    React.createElement(
                                      ReactSampleTextBox,
                                      self.props
                                    ),
                                    self._container
                                  );
                                }
                              },
                              function (error) {}
                            );
                        } else {
                          let arrayVar: {
                            heading: string;
                            startTime: string;
                            endTime: string;
                            accountName: string;
                            joiningLink: string;
                            id: string;
                            modeOfMeeting: string;
                            location: string;
                            editLink: string;
                            date: string;
                            appointmentID: string;
                          }[] = [];
                          for (var i = 0; i < 1; i++) {
                            let heading =
                              "You have nothing scheduled for today";
                            let id = "appcarousel__slide" + i + 1;

                            arrayVar.push({
                              heading: heading,
                              startTime: "",
                              endTime: "",
                              accountName: "",
                              joiningLink: "",
                              id: id,
                              modeOfMeeting: "",
                              location: "",
                              editLink: "",
                              date: date + "/" + month + "/" + year,
                              appointmentID: "",
                            });
                          }
                          self.props = {
                            multiData: arrayVar,
                            value: arrayVar.length,
                            status: false,
                            birthDayArray: birthDayVar,
                            birthdayStatus: birthdaystatus,
                            context: self._context,
                            birthdayView: BirthdayView,
                            appointmentView: AppointmentView,
                          };

                          ReactDOM.render(
                            React.createElement(ReactSampleTextBox, self.props),
                            self._container
                          );
                        }
                      },

                      function (error) {}
                    );
                  },
                  function (error) {}
                );
              },
              function (error) {}
            );
        },
        function (error) {}
      );
  }
}
